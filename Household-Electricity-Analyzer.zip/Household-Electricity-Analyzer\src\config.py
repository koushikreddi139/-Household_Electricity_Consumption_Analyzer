"""
Central configuration and assumptions for the Household Electricity Consumption
Analyzer.

Every illustrative assumption used by the application, the report and the
presentation is declared here so that results remain traceable and consistent.
"""

from __future__ import annotations

from pathlib import Path

# ---------------------------------------------------------------------------
# Project paths
# ---------------------------------------------------------------------------
ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
SRC_DIR = ROOT_DIR / "src"
VIS_DIR = ROOT_DIR / "visualizations"
REPORT_DIR = ROOT_DIR / "reports"
SCREENSHOT_DIR = ROOT_DIR / "screenshots"
DOCS_DIR = ROOT_DIR / "docs"
ASSETS_DIR = ROOT_DIR / "assets"

RAW_DATA_PATH = DATA_DIR / "project_dataset_raw.csv"
CLEANED_DATA_PATH = DATA_DIR / "project_dataset_cleaned.csv"
PRIMARY_TEMPLATE_PATH = DATA_DIR / "primary_observation_template.csv"
APPLIANCE_DB_PATH = DATA_DIR / "appliance_database.csv"

# ---------------------------------------------------------------------------
# Study window and modelling assumptions
# ---------------------------------------------------------------------------
START_DATE = "2026-01-05"          # Monday - winter season example household
OBSERVATION_DAYS = 21
PROJECTION_DAYS = 30               # utility billing month convention
FORECAST_DAYS = 30
RANDOM_SEED = 42

# Configurable assumptions (clearly illustrative, not official values)
DEFAULT_TARIFF_INR_PER_KWH = 8.50   # illustrative slab-mixed household tariff
DEFAULT_EMISSION_FACTOR = 0.71      # kg CO2e per kWh (CEA India grid, approx.)
DEFAULT_FIXED_CHARGE_INR = 0.0
CURRENCY = "INR"
CURRENCY_SYMBOL = "Rs."

# ---------------------------------------------------------------------------
# Appliance master database
# ---------------------------------------------------------------------------
# rated_power_w  : nameplate power while running
# standby_power_w: power drawn while plugged in but not performing its function
# units          : number of identical units in the household
# avg_daily_hours: design (typical) daily operating hours
# avg_standby_hours: design daily hours spent in standby
APPLIANCE_MASTER = [
    dict(appliance_id="A01", appliance_name="Ceiling Fan", category="Cooling",
         rated_power_w=75, standby_power_w=0.0, units=2, avg_daily_hours=6.2,
         avg_standby_hours=0.0, usage_note="Bedroom and living-room fans"),
    dict(appliance_id="A02", appliance_name="LED Bulb", category="Lighting",
         rated_power_w=9, standby_power_w=0.0, units=6, avg_daily_hours=5.8,
         avg_standby_hours=0.0, usage_note="Energy-efficient lighting"),
    dict(appliance_id="A03", appliance_name="CFL Bulb", category="Lighting",
         rated_power_w=15, standby_power_w=0.0, units=3, avg_daily_hours=4.2,
         avg_standby_hours=0.0, usage_note="Older lighting retained in utility areas"),
    dict(appliance_id="A04", appliance_name="Television", category="Entertainment",
         rated_power_w=80, standby_power_w=6.0, units=1, avg_daily_hours=4.0,
         avg_standby_hours=18.0, usage_note="LED TV left on standby overnight"),
    dict(appliance_id="A05", appliance_name="Refrigerator", category="Kitchen",
         rated_power_w=180, standby_power_w=0.0, units=1, avg_daily_hours=12.0,
         avg_standby_hours=0.0, usage_note="Compressor duty cycle modelled as 12 effective hours"),
    dict(appliance_id="A06", appliance_name="Laptop", category="Computing",
         rated_power_w=65, standby_power_w=1.5, units=1, avg_daily_hours=5.5,
         avg_standby_hours=3.0, usage_note="Charged and used for study/work"),
    dict(appliance_id="A07", appliance_name="Desktop Computer", category="Computing",
         rated_power_w=220, standby_power_w=5.0, units=1, avg_daily_hours=3.2,
         avg_standby_hours=18.0, usage_note="Desktop left plugged in"),
    dict(appliance_id="A08", appliance_name="Washing Machine", category="Laundry",
         rated_power_w=500, standby_power_w=2.0, units=1, avg_daily_hours=0.55,
         avg_standby_hours=22.0, usage_note="Three to four wash cycles per week"),
    dict(appliance_id="A09", appliance_name="Air Conditioner", category="Climate",
         rated_power_w=1500, standby_power_w=3.0, units=1, avg_daily_hours=0.8,
         avg_standby_hours=22.0, usage_note="Winter-season occasional use"),
    dict(appliance_id="A10", appliance_name="Electric Iron", category="Laundry",
         rated_power_w=1000, standby_power_w=0.0, units=1, avg_daily_hours=0.25,
         avg_standby_hours=0.0, usage_note="Used on alternate days"),
    dict(appliance_id="A11", appliance_name="Water Heater (Geyser)", category="Water Heating",
         rated_power_w=2000, standby_power_w=5.0, units=1, avg_daily_hours=1.75,
         avg_standby_hours=22.0, usage_note="Thermostat-controlled storage geyser"),
    dict(appliance_id="A12", appliance_name="Microwave Oven", category="Kitchen",
         rated_power_w=1200, standby_power_w=3.0, units=1, avg_daily_hours=0.45,
         avg_standby_hours=23.0, usage_note="Reheating and light cooking"),
    dict(appliance_id="A13", appliance_name="Wi-Fi Router", category="Computing",
         rated_power_w=12, standby_power_w=0.0, units=1, avg_daily_hours=24.0,
         avg_standby_hours=0.0, usage_note="Always-on broadband router"),
]

# ---------------------------------------------------------------------------
# Visual identity - green / neutral sustainability palette
# ---------------------------------------------------------------------------
PALETTE = {
    "deep": "#0B3B36",
    "primary": "#0F766E",
    "emerald": "#10B981",
    "mint": "#6EE7B7",
    "light": "#D1FAE5",
    "sand": "#F4F1E8",
    "ink": "#0F172A",
    "muted": "#64748B",
    "grid": "#E2E8F0",
    "amber": "#D97706",
    "red": "#DC2626",
    "blue": "#2563EB",
    "surface": "#FFFFFF",
    "bg": "#F5F8F6",
}

CHART_COLORS = [
    "#0F766E", "#10B981", "#34D399", "#6EE7B7", "#A7F3D0",
    "#D97706", "#F59E0B", "#2563EB", "#60A5FA", "#64748B",
    "#94A3B8", "#DC2626", "#F87171",
]

# ---------------------------------------------------------------------------
# Dataset schema
# ---------------------------------------------------------------------------
REQUIRED_DATA_COLUMNS = [
    "date", "appliance_id", "appliance_name", "rated_power_w", "standby_power_w",
    "units", "operating_hours", "standby_hours", "data_source",
]

NUMERIC_DATA_COLUMNS = [
    "rated_power_w", "standby_power_w", "units", "operating_hours",
    "standby_hours", "operating_kwh", "standby_kwh", "total_kwh",
]

VALID_DATA_SOURCES = {"Simulated", "Estimated", "Observed"}

# Illustrative recommendations assumptions (documented in the report)
RECOMMENDATION_ASSUMPTIONS = {
    "standby_elimination_fraction": 0.90,
    "cfl_to_led_replacement_fraction": 1.00,
    "led_replacement_watts": 9,
    "fan_hour_reduction": 1.0,
    "geyser_minutes_reduction": 20.0,
    "washing_energy_reduction_fraction": 0.25,
    "ac_energy_reduction_fraction": 0.25,
}


def appliance_design_day() -> list[dict]:
    """Return the master appliance table with design-day energy computed."""
    rows = []
    for item in APPLIANCE_MASTER:
        row = dict(item)
        row["design_operating_kwh"] = round(
            row["rated_power_w"] * row["units"] * row["avg_daily_hours"] / 1000, 4
        )
        row["design_standby_kwh"] = round(
            row["standby_power_w"] * row["units"] * row["avg_standby_hours"] / 1000, 4
        )
        row["design_daily_kwh"] = round(
            row["design_operating_kwh"] + row["design_standby_kwh"], 4
        )
        row["design_monthly_kwh"] = round(row["design_daily_kwh"] * PROJECTION_DAYS, 3)
        rows.append(row)
    return rows
