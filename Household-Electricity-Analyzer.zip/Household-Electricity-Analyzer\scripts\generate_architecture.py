"""
Generate the system architecture diagram used in the report and presentation.

Output: visualizations/system_architecture.png
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "visualizations"
OUT.mkdir(parents=True, exist_ok=True)

P = {
    "deep": "#0B3B36",
    "primary": "#0F766E",
    "emerald": "#10B981",
    "mint": "#D1FAE5",
    "light": "#ECFDF5",
    "sand": "#F8F5EC",
    "ink": "#0F172A",
    "muted": "#64748B",
    "border": "#CFE3DA",
}

plt.rcParams.update({"font.family": "Segoe UI"})


def rounded(ax, x, y, w, h, face, edge="none", lw=0.0, radius=1.2, alpha=1.0, z=2):
    patch = FancyBboxPatch(
        (x, y), w, h,
        boxstyle=f"round,pad=0,rounding_size={radius}",
        linewidth=lw, edgecolor=edge, facecolor=face, alpha=alpha, zorder=z,
    )
    ax.add_patch(patch)
    return patch


def box(ax, x, y, w, h, title, body="", face="white", edge=P["border"],
        title_color=P["ink"], body_color=P["muted"], title_size=10.2, body_size=8.0):
    rounded(ax, x, y, w, h, face, edge, 1.0)
    ax.text(x + 1.4, y + h - 1.9, title, fontsize=title_size, fontweight="bold",
            color=title_color, va="top", ha="left", zorder=4)
    if body:
        ax.text(x + 1.4, y + h - 4.6, body, fontsize=body_size, color=body_color,
                va="top", ha="left", linespacing=1.45, zorder=4)


fig, ax = plt.subplots(figsize=(13.4, 8.0))
ax.set_xlim(0, 100)
ax.set_ylim(0, 100)
ax.axis("off")
fig.patch.set_facecolor("white")

ax.text(2.0, 97.2, "Household Electricity Consumption Analyzer", fontsize=19,
        fontweight="bold", color=P["ink"], ha="left")
ax.text(2.0, 94.2, "System architecture · software-only analytical pipeline",
        fontsize=10.5, color=P["muted"], ha="left")
ax.text(98.0, 96.0, "Python 3 · Pandas · Scikit-learn · Plotly · Streamlit",
        fontsize=8.8, color=P["primary"], ha="right", fontweight="bold")

# Layer labels
layers = [
    (78.0, 14.0, "PRESENTATION", "Streamlit UI"),
    (57.0, 14.0, "ANALYTICS", "Models & metrics"),
    (36.0, 14.0, "PROCESSING", "Validation & calculation"),
    (15.0, 11.5, "DATA", "Provenance-aware"),
]
for y, h, label, sub in layers:
    rounded(ax, 2.0, y, 7.3, h, P["deep"], radius=0.9, z=1)
    ax.text(5.65, y + h / 2, label, fontsize=7.4, fontweight="bold", color="white",
            rotation=90, ha="center", va="center", zorder=3)

# Presentation layer
rounded(ax, 11.5, 78.0, 86.0, 14.0, P["light"], P["border"], 1.0)
ax.text(13.2, 89.8, "Interactive dashboard — six analytical workspaces",
        fontsize=10.6, fontweight="bold", color=P["deep"])
modules = ["Home", "Consumption", "Appliances", "Prediction", "Sustainability", "Data management"]
widths = [12.9] * 6
x = 12.8
for label, w in zip(modules, widths):
    rounded(ax, x, 81.2, w, 4.2, "white", "#BFDCD0", lw=0.8, radius=0.8)
    ax.text(x + w / 2, 83.3, label, fontsize=7.9, color=P["deep"], ha="center", va="center",
            fontweight="bold")
    x += w + 1.0
ax.text(64.8, 79.6, "Plotly charts · CSV exports · downloadable report & slides", fontsize=7.8,
        color=P["muted"], ha="left")

# Analytics layer
analytics = [
    ("Cost analysis", "tariff × energy\nmonthly & annual bills", P["sand"], P["deep"]),
    ("Sustainability", "kWh × grid factor\nCO2e & equivalences", P["light"], P["deep"]),
    ("Prediction", "Ridge regression\ntrend + weekly cycle", "white", P["ink"]),
    ("Recommendations", "quantified actions\nkWh · Rs. · CO2e", P["light"], P["deep"]),
]
xs = [12.5, 33.8, 55.1, 76.4]
for (title, body, face, tc), x in zip(analytics, xs):
    box(ax, x, 57.6, 19.9, 12.4, title, body, face=face, title_color=tc)

# Processing layer
processing = [
    ("Data processing", "schema validation · cleaning\nmedian imputation · aggregation\nquality flags", 30.0),
    ("Energy calculator", "P(W) × h × units ÷ 1000\noperating + standby\nrecomputed from source", 19.9),
    ("Scenario engine", "appliance parameter edits\nproportional scaling\nfull-pipeline refresh", 20.0),
]
px = [12.5, 46.0, 70.4]
for (title, body, w), x in zip(processing, px):
    box(ax, x, 36.6, w, 12.4, title, body, face="white")

# Data layer
data = [
    ("Appliance database", "13 appliances\nrated & standby power\nunits · typical hours", P["light"]),
    ("Project Dataset (21 days)", "273 appliance-day records\nweekday / weekend variation\nsupplied dataset", P["sand"]),
    ("Primary observations", "blank 21-day template\nmanual / CSV observation log\nlabel: OBSERVED", "white"),
]
dx = [12.5, 40.3, 68.1]
for (title, body, face), x in zip(data, dx):
    box(ax, x, 16.0, 25.7, 11.5, title, body, face=face, title_size=9.8)
    if title.startswith("Project"):
        ax.text(x + 24.2, 25.8, "PROJECT DATA", fontsize=6.6, fontweight="bold", color=P["primary"],
                ha="right", va="top", bbox=dict(boxstyle="round,pad=0.28", fc="#ECFDF5", ec="#A7F3D0", lw=0.6))
    if title.startswith("Primary"):
        ax.text(x + 24.2, 25.8, "PRIMARY DATA", fontsize=6.6, fontweight="bold", color=P["primary"],
                ha="right", va="top", bbox=dict(boxstyle="round,pad=0.28", fc="#ECFDF5", ec="#A7F3D0", lw=0.6))

# Arrows between layers
for x in [30.0, 50.0, 70.0, 86.0]:
    ax.add_patch(FancyArrowPatch((x, 27.8), (x, 35.3), arrowstyle="-|>", mutation_scale=14,
                                 color=P["primary"], linewidth=1.3, zorder=5))
for x in [30.0, 50.0, 70.0, 86.0]:
    ax.add_patch(FancyArrowPatch((x, 49.3), (x, 56.3), arrowstyle="-|>", mutation_scale=14,
                                 color=P["primary"], linewidth=1.3, zorder=5))
for x in [30.0, 50.0, 70.0, 86.0]:
    ax.add_patch(FancyArrowPatch((x, 70.2), (x, 77.3), arrowstyle="-|>", mutation_scale=14,
                                 color=P["primary"], linewidth=1.3, zorder=5))

# Provenance note
rounded(ax, 11.5, 3.2, 86.0, 8.4, "#F0F7F3", P["border"], 0.8, radius=0.9)
ax.text(13.0, 10.4, "Data integrity by design", fontsize=9.2, fontweight="bold", color=P["deep"],
        va="top")
ax.text(13.0, 8.4,
        "Every record carries a source label used by the cleaning stage.\n"
        "Cleaning flags imputations; primary observations remain separate from the supplied dataset.",
        fontsize=7.4, color=P["muted"], linespacing=1.5, va="top")

fig.savefig(OUT / "system_architecture.png", dpi=220, bbox_inches="tight", facecolor="white")
plt.close(fig)
print("wrote system_architecture.png")
