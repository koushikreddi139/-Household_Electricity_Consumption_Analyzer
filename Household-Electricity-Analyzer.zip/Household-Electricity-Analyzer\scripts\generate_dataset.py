"""
Generate the 21-day appliance-level Project Dataset, the cleaned dataset,
the appliance database and the blank primary-observation template.

The generator provides a reproducible 21-day dataset for the analysis pipeline.
A small number of data-quality anomalies are included so that the cleaning
pipeline can be demonstrated and tested; they are corrected and flagged in the
cleaned dataset.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import config  # noqa: E402
from src.data_processing import clean_energy_data, prepare_appliance_database  # noqa: E402

RNG = np.random.default_rng(config.RANDOM_SEED)
DATES = pd.date_range(config.START_DATE, periods=config.OBSERVATION_DAYS, freq="D")

# Typical operating hours: (weekday, weekend), plus noise standard deviation.
PROFILES = {
    "A01": {"weekday": 5.8, "weekend": 7.2, "sigma": 0.18},
    "A02": {"weekday": 5.2, "weekend": 6.8, "sigma": 0.15},
    "A03": {"weekday": 3.8, "weekend": 5.0, "sigma": 0.18},
    "A04": {"weekday": 3.2, "weekend": 5.8, "sigma": 0.22},
    "A05": {"weekday": 12.0, "weekend": 12.1, "sigma": 0.05},
    "A06": {"weekday": 5.8, "weekend": 3.0, "sigma": 0.18},
    "A07": {"weekday": 2.8, "weekend": 4.2, "sigma": 0.20},
    "A08": {"weekday": 0.8, "weekend": 0.8, "sigma": 0.20, "schedule": [0, 2, 5]},
    "A09": {"weekday": 0.6, "weekend": 1.1, "sigma": 0.35},
    "A10": {"weekday": 0.4, "weekend": 0.4, "sigma": 0.25, "schedule": [1, 3, 6]},
    "A11": {"weekday": 1.7, "weekend": 2.0, "sigma": 0.12},
    "A12": {"weekday": 0.4, "weekend": 0.6, "sigma": 0.30},
    "A13": {"weekday": 24.0, "weekend": 24.0, "sigma": 0.0},
}

# Standby hours are derived from the remaining plugged-in time for appliances
# that are left connected; fixed values are used for the laptop.
STANDBY_OFFSET = {"A04": 1.5, "A07": 3.0, "A08": 1.0, "A09": 1.0, "A11": 1.5, "A12": 0.5}
FIXED_STANDBY = {"A06": 3.0}

ANOMALIES = [
    ("2026-01-09", "A05", None, "injected_missing_value", "Deliberate missing value for cleaning test"),
    ("2026-01-14", "A04", None, "injected_missing_value", "Deliberate missing value for cleaning test"),
    ("2026-01-20", "A11", None, "injected_missing_value", "Deliberate missing value for cleaning test"),
    ("2026-01-16", "A01", -0.5, "injected_invalid_value", "Deliberate negative value for validation test"),
    ("2026-01-23", "A12", 26.0, "injected_invalid_value", "Deliberate out-of-range value for validation test"),
]


def build_raw_rows() -> pd.DataFrame:
    rows = []
    for date in DATES:
        dow = date.day_of_week
        weekend = dow >= 5
        week_number = int((date - DATES[0]).days // 7 + 1)
        for appliance in config.APPLIANCE_MASTER:
            app_id = appliance["appliance_id"]
            profile = PROFILES[app_id]
            base = profile["weekend"] if weekend else profile["weekday"]

            if "schedule" in profile and dow not in profile["schedule"]:
                hours = 0.0
            elif app_id == "A13":  # router is always on
                hours = 24.0
            else:
                noise = 1.0 if profile["sigma"] == 0 else RNG.normal(1.0, profile["sigma"])
                hours = max(0.0, base * noise)
                # Occasional AC off-day in mild winter weather.
                if app_id == "A09" and RNG.random() < 0.18:
                    hours = 0.0
                # A short cold spell increases geyser use.
                if app_id == "A11" and pd.Timestamp("2026-01-12") <= date <= pd.Timestamp("2026-01-16"):
                    hours *= 1.15
                # Inactive appliances do not run fractional hours.
                if base == 0:
                    hours = 0.0
            hours = round(min(hours, 24.0), 2)

            if app_id in FIXED_STANDBY:
                standby_hours = FIXED_STANDBY[app_id]
            elif app_id in STANDBY_OFFSET:
                standby_hours = round(max(0.0, 24.0 - hours - STANDBY_OFFSET[app_id]), 2)
            else:
                standby_hours = 0.0

            operating_kwh = appliance["rated_power_w"] * hours * appliance["units"] / 1000
            standby_kwh = appliance["standby_power_w"] * standby_hours * appliance["units"] / 1000
            rows.append(
                {
                    "date": date,
                    "day_of_week": date.day_name(),
                    "week_number": week_number,
                    "appliance_id": app_id,
                    "appliance_name": appliance["appliance_name"],
                    "rated_power_w": appliance["rated_power_w"],
                    "standby_power_w": appliance["standby_power_w"],
                    "units": appliance["units"],
                    "operating_hours": hours,
                    "standby_hours": standby_hours,
                    "operating_kwh": round(operating_kwh, 4),
                    "standby_kwh": round(standby_kwh, 4),
                    "total_kwh": round(operating_kwh + standby_kwh, 4),
                    "data_source": "Simulated",
                    "quality_flag": "validated",
                    "notes": "Project Dataset record; source label retained for schema compatibility.",
                }
            )
    df = pd.DataFrame(rows)

    # Inject deliberate anomalies for the cleaning demonstration.
    for date_str, app_id, value, flag, note in ANOMALIES:
        mask = (df["date"] == pd.Timestamp(date_str)) & (df["appliance_id"] == app_id)
        df.loc[mask, "operating_hours"] = value
        df.loc[mask, "operating_kwh"] = np.nan
        df.loc[mask, "total_kwh"] = np.nan
        df.loc[mask, "quality_flag"] = flag
        df.loc[mask, "notes"] = note
    return df


def build_primary_template() -> pd.DataFrame:
    rows = []
    for date in DATES:
        for appliance in config.APPLIANCE_MASTER:
            rows.append(
                {
                    "date": date.strftime("%Y-%m-%d"),
                    "day_of_week": date.day_name(),
                    "week_number": int((date - DATES[0]).days // 7 + 1),
                    "appliance_id": appliance["appliance_id"],
                    "appliance_name": appliance["appliance_name"],
                    "rated_power_w": appliance["rated_power_w"],
                    "standby_power_w": appliance["standby_power_w"],
                    "units": appliance["units"],
                    "operating_hours": "",
                    "standby_hours": "",
                    "operating_kwh": "",
                    "standby_kwh": "",
                    "total_kwh": "",
                    "data_source": "Observed",
                    "quality_flag": "awaiting_primary_observation",
                    "notes": "Enter genuine measured or nameplate-estimated hours; delete rows that do not apply.",
                }
            )
    return pd.DataFrame(rows)


def main() -> None:
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    raw = build_raw_rows()
    raw.to_csv(config.RAW_DATA_PATH, index=False)

    cleaned, report = clean_energy_data(raw)
    export_cols = [
        "date", "day_of_week", "week_number", "appliance_id", "appliance_name",
        "rated_power_w", "standby_power_w", "units", "operating_hours", "standby_hours",
        "operating_kwh", "standby_kwh", "total_kwh", "data_source", "quality_flag", "notes",
        "is_weekend",
    ]
    cleaned_export = cleaned.copy()
    cleaned_export["date"] = cleaned_export["date"].dt.strftime("%Y-%m-%d")
    cleaned_export[export_cols].to_csv(config.CLEANED_DATA_PATH, index=False)

    db = prepare_appliance_database(pd.DataFrame(config.APPLIANCE_MASTER))
    db.to_csv(config.APPLIANCE_DB_PATH, index=False)

    build_primary_template().to_csv(config.PRIMARY_TEMPLATE_PATH, index=False)

    daily = cleaned.groupby("date", as_index=False)["total_kwh"].sum()
    print("Dataset generation complete")
    print(f"  Raw rows           : {len(raw)}")
    print(f"  Clean rows         : {len(cleaned)}")
    print(f"  Days               : {report['days']}")
    print(f"  Appliances         : {report['appliances']}")
    print(f"  Imputed/estimated  : {report['estimated_records']}")
    print(f"  Total energy (kWh) : {daily['total_kwh'].sum():.3f}")
    print(f"  Mean daily (kWh)   : {daily['total_kwh'].mean():.3f}")
    print(f"  Peak day           : {daily.loc[daily['total_kwh'].idxmax(), 'date'].date()} "
          f"({daily['total_kwh'].max():.3f} kWh)")
    print(f"  Standby (kWh)      : {cleaned['standby_kwh'].sum():.3f}")


if __name__ == "__main__":
    main()
