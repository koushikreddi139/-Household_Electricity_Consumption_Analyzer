"""
Generate the academic PDF report for the Household Electricity Consumption
Analyzer.

The report is built with ReportLab Platypus. Every number is computed from the
project modules at build time so that the document can never drift away from the
dashboard or the cleaned dataset.

Output: reports/Project_Report.pdf (maximum 10 pages)
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
from PIL import Image as PILImage
from pypdf import PdfReader
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import (
    BaseDocTemplate, Frame, HRFlowable, Image, KeepTogether, NextPageTemplate,
    PageBreak, PageTemplate, Paragraph, Spacer, Table, TableStyle,
)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import config
from src.team import (
    ACADEMIC_YEAR, DEPARTMENT, GUIDE, TEAM_MEMBERS, TEAM_NUMBER,
)
from src.cost_analysis import cost_summary
from src.data_processing import (
    appliance_summary, build_quality_table, clean_energy_data, daily_summary,
    load_energy_csv, lowest_consumption_day, peak_consumption_day,
    prepare_appliance_database, weekly_summary,
)
from src.prediction import fit_and_forecast, model_comparison_table
from src.recommendations import (
    combined_savings, generate_recommendations, recommendations_table,
)
from src.sustainability import sustainability_summary

# ---------------------------------------------------------------------------
# Editable report metadata (replace the placeholder fields before submission)
# ---------------------------------------------------------------------------
REPORT_META = {
    "team_number": TEAM_NUMBER,
    "members": TEAM_MEMBERS,
    "guide": GUIDE,
    "department": DEPARTMENT,
    "academic_year": ACADEMIC_YEAR,
}

OUTPUT_PATH = config.REPORT_DIR / "Project_Report.pdf"
TARIFF = config.DEFAULT_TARIFF_INR_PER_KWH
EMISSION_FACTOR = config.DEFAULT_EMISSION_FACTOR

PALETTE = config.PALETTE
INK = colors.HexColor(PALETTE["ink"])
MUTED = colors.HexColor(PALETTE["muted"])
DEEP = colors.HexColor(PALETTE["deep"])
PRIMARY = colors.HexColor(PALETTE["primary"])
EMERALD = colors.HexColor(PALETTE["emerald"])
MINT = colors.HexColor(PALETTE["mint"])
LIGHT = colors.HexColor(PALETTE["light"])
SAND = colors.HexColor(PALETTE["sand"])
GRID = colors.HexColor(PALETTE["grid"])
SURFACE = colors.HexColor(PALETTE["surface"])
BG = colors.HexColor(PALETTE["bg"])
AMBER = colors.HexColor(PALETTE["amber"])
RED = colors.HexColor(PALETTE["red"])

# ---------------------------------------------------------------------------
# Fonts
# ---------------------------------------------------------------------------
FONT_DIR = Path("C:/Windows/Fonts")
pdfmetrics.registerFont(TTFont("SegoeUI", str(FONT_DIR / "segoeui.ttf")))
pdfmetrics.registerFont(TTFont("SegoeUI-Bold", str(FONT_DIR / "segoeuib.ttf")))
pdfmetrics.registerFont(TTFont("SegoeUI-Italic", str(FONT_DIR / "segoeuii.ttf")))
pdfmetrics.registerFont(TTFont("SegoeUI-BoldItalic", str(FONT_DIR / "segoeuiz.ttf")))
pdfmetrics.registerFontFamily(
    "SegoeUI", normal="SegoeUI", bold="SegoeUI-Bold",
    italic="SegoeUI-Italic", boldItalic="SegoeUI-BoldItalic",
)

# ---------------------------------------------------------------------------
# Metrics (computed, never hard-coded)
# ---------------------------------------------------------------------------
raw = load_energy_csv(config.RAW_DATA_PATH)
clean, quality = clean_energy_data(raw)
clean.to_csv(config.CLEANED_DATA_PATH, index=False)
db = load_energy_csv(config.APPLIANCE_DB_PATH)
daily = daily_summary(clean)
weekly = weekly_summary(daily)
appl = appliance_summary(clean, db)
design_db = prepare_appliance_database(db)
cost = cost_summary(daily, TARIFF)
sust = sustainability_summary(daily, EMISSION_FACTOR, TARIFF)
pred = fit_and_forecast(daily)
quality_table = build_quality_table(clean)
peak = peak_consumption_day(daily)
low = lowest_consumption_day(daily)
recs = generate_recommendations(appl, db, TARIFF, EMISSION_FACTOR)
combined = combined_savings(recs, [r["id"] for r in recs], cost["monthly_kwh"])

weekday_mean = float(daily.loc[~daily["is_weekend"], "total_kwh"].mean())
weekend_mean = float(daily.loc[daily["is_weekend"], "total_kwh"].mean())
weekend_delta = (weekend_mean - weekday_mean) / weekday_mean * 100
standby_share = quality["standby_kwh"] / quality["total_kwh"] * 100
top_three = appl.head(3)
top_three_share = float(top_three["share_pct"].sum())
top_name = appl.iloc[0]["appliance_name"]
forecast_cost = pred["monthly_forecast_kwh"] * TARIFF

# ---------------------------------------------------------------------------
# Styles
# ---------------------------------------------------------------------------
styles = getSampleStyleSheet()

body = ParagraphStyle(
    "Body", fontName="SegoeUI", fontSize=9.2, leading=13.2, textColor=INK,
    alignment=TA_JUSTIFY, spaceAfter=4.5,
)
body_tight = ParagraphStyle("BodyTight", parent=body, fontSize=8.7, leading=12.2, spaceAfter=3)
small = ParagraphStyle(
    "Small", parent=body, fontSize=8.0, leading=11.0, textColor=MUTED, alignment=TA_LEFT,
)
caption = ParagraphStyle(
    "Caption", fontName="SegoeUI-Italic", fontSize=7.6, leading=9.6,
    textColor=MUTED, alignment=TA_CENTER, spaceBefore=2, spaceAfter=6,
)
h1 = ParagraphStyle(
    "H1", fontName="SegoeUI-Bold", fontSize=14.5, leading=17.5, textColor=DEEP,
    spaceBefore=2, spaceAfter=1,
)
h2 = ParagraphStyle(
    "H2", fontName="SegoeUI-Bold", fontSize=10.4, leading=13.0, textColor=PRIMARY,
    spaceBefore=7, spaceAfter=3,
)
bullet = ParagraphStyle(
    "Bullet", parent=body, leftIndent=11, bulletIndent=1, spaceAfter=3.2,
)
cell = ParagraphStyle(
    "Cell", fontName="SegoeUI", fontSize=7.6, leading=9.5, textColor=INK,
)
cell_small = ParagraphStyle("CellSmall", parent=cell, fontSize=7.0, leading=8.8)
cell_num = ParagraphStyle("CellNum", parent=cell, alignment=TA_RIGHT)
head = ParagraphStyle(
    "Head", fontName="SegoeUI-Bold", fontSize=7.6, leading=9.4,
    textColor=colors.white,
)
head_right = ParagraphStyle("HeadRight", parent=head, alignment=TA_RIGHT)
kpi_value = ParagraphStyle(
    "KpiValue", fontName="SegoeUI-Bold", fontSize=17, leading=20, textColor=PRIMARY,
    alignment=TA_LEFT,
)
kpi_label = ParagraphStyle(
    "KpiLabel", fontName="SegoeUI", fontSize=7.2, leading=9, textColor=MUTED,
)
box_body = ParagraphStyle(
    "BoxBody", fontName="SegoeUI", fontSize=8.8, leading=12.4, textColor=INK,
    alignment=TA_JUSTIFY,
)
ref = ParagraphStyle(
    "Ref", fontName="SegoeUI", fontSize=7.5, leading=10.2, textColor=INK,
    leftIndent=12, firstLineIndent=-12, spaceAfter=2.2,
)

# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def esc(text: str) -> str:
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def P(text: str, style=body) -> Paragraph:
    return Paragraph(text, style)


def rule(color=EMERALD, thickness=0.9, space_after=5) -> HRFlowable:
    return HRFlowable(width="100%", thickness=thickness, color=color,
                      spaceBefore=1, spaceAfter=space_after)


def section(title: str) -> list:
    return [P(title, h1), rule()]


def figure(path: Path, width_cm: float, cap: str, optional: bool = False) -> list:
    if not path.exists():
        if optional:
            print(f"  note: optional figure not found, skipped: {path.name}")
            return []
        raise FileNotFoundError(path)
    w, h = PILImage.open(path).size
    img = Image(str(path), width=width_cm * cm, height=width_cm * cm * h / w)
    return [KeepTogether([img, P(cap, caption)])]


def make_table(
    data: list[list],
    widths: list[float],
    font_size: float = 7.6,
    header: bool = True,
    right_cols: list[int] | None = None,
    row_padding: float = 3.2,
) -> Table:
    """Build a styled table; cell content may be str or flowable."""
    right_set = set(right_cols or [])
    rendered = []
    for r_idx, row in enumerate(data):
        out_row = []
        for c_idx, value in enumerate(row):
            if isinstance(value, (Paragraph, Image)):
                out_row.append(value)
                continue
            if header and r_idx == 0:
                st = head_right if c_idx in right_set else head
            else:
                st = cell_num if c_idx in right_set else cell
            if font_size != 7.6 and st is cell:
                st = ParagraphStyle("tmp", parent=cell, fontSize=font_size, leading=font_size + 2)
            elif font_size != 7.6 and st is cell_num:
                st = ParagraphStyle("tmpn", parent=cell_num, fontSize=font_size, leading=font_size + 2)
            out_row.append(Paragraph(esc(value), st))
        rendered.append(out_row)

    table = Table(rendered, colWidths=[w * cm for w in widths], repeatRows=1 if header else 0,
                  hAlign="LEFT")
    commands = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), row_padding),
        ("BOTTOMPADDING", (0, 0), (-1, -1), row_padding),
        ("LINEBELOW", (0, 0), (-1, -1), 0.35, GRID),
    ]
    if header:
        commands += [
            ("BACKGROUND", (0, 0), (-1, 0), DEEP),
            ("TOPPADDING", (0, 0), (-1, 0), 4.6),
            ("BOTTOMPADDING", (0, 0), (-1, 0), 4.6),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [SURFACE, BG]),
        ]
    table.setStyle(TableStyle(commands))
    return table


def callout(title: str, text: str, fill=SAND, bar=AMBER) -> Table:
    """Single-cell callout box with a coloured left bar."""
    inner = [
        Paragraph(f'<font color="#{bar.hexval()[2:]}"><b>{esc(title)}</b></font>',
                  ParagraphStyle("ct", fontName="SegoeUI-Bold", fontSize=8.8,
                                 leading=11.5, textColor=INK, spaceAfter=2)),
        P(text, box_body),
    ]
    t = Table([[inner]], colWidths=[17.0 * cm], hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), fill),
        ("LINEBEFORE", (0, 0), (0, -1), 3, bar),
        ("BOX", (0, 0), (-1, -1), 0.4, GRID),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return t


def kpi_strip(items: list[tuple[str, str]]) -> Table:
    cells = []
    for value, label in items:
        cells.append([
            Paragraph(value, kpi_value),
            Paragraph(label, kpi_label),
        ])
    row = [[Table([[c[0]], [c[1]]], colWidths=[4.0 * cm], style=TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
    ])) for c in cells]]
    t = Table(row, colWidths=[4.25 * cm] * len(items), hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), SURFACE),
        ("BOX", (0, 0), (-1, -1), 0.5, GRID),
        ("INNERGRID", (0, 0), (-1, -1), 0.4, GRID),
        ("LEFTPADDING", (0, 0), (-1, -1), 9),
        ("RIGHTPADDING", (0, 0), (-1, -1), 9),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return t


# ---------------------------------------------------------------------------
# Page decorations
# ---------------------------------------------------------------------------
class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            if self._pageNumber > 1:
                self.setFont("SegoeUI", 7.2)
                self.setFillColor(MUTED)
                self.drawRightString(
                    A4[0] - 1.9 * cm, 1.02 * cm,
                    f"Page {self._pageNumber - 1} of {total - 1}",
                )
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)


def draw_cover(c: canvas.Canvas, doc):
    W, H = A4
    c.saveState()
    c.setFillColor(BG)
    c.rect(0, 0, W, H, stroke=0, fill=1)

    # Top band
    c.setFillColor(DEEP)
    c.rect(0, H - 282, W, 282, stroke=0, fill=1)
    c.setFillColor(colors.HexColor("#12524A"))
    c.circle(W - 40, H - 35, 150, stroke=0, fill=1)
    c.setFillColor(colors.HexColor("#0E4A43"))
    c.circle(W - 170, H - 210, 95, stroke=0, fill=1)

    # Eyebrow pill
    c.setFillColor(colors.HexColor("#145C53"))
    c.roundRect(56, H - 70, 286, 21, 10, stroke=0, fill=1)
    c.setFillColor(MINT)
    c.setFont("SegoeUI-Bold", 7.4)
    c.drawString(67, H - 63, "SUSTAINABLE ENERGY ENGINEERING  ·  B.TECH CSE")

    # Title
    c.setFillColor(colors.white)
    c.setFont("SegoeUI-Bold", 27)
    c.drawString(56, H - 132, "Household Electricity")
    c.drawString(56, H - 168, "Consumption Analyzer")
    c.setFillColor(colors.HexColor("#A7F3D0"))
    c.setFont("SegoeUI-Bold", 10.5)
    c.drawString(56, H - 195, "Appliance-level energy, cost, forecast and carbon analysis")

    subtitle = Paragraph(
        "A software-only dashboard that turns 21 days of appliance operating-hour records "
        "into transparent estimates of electricity use, monthly cost, next-month demand and "
        "avoidable CO<sub>2</sub>e &mdash; with every data source explicitly labelled.",
        ParagraphStyle("coversub", fontName="SegoeUI", fontSize=9.4, leading=14,
                       textColor=colors.HexColor("#D1FAE5")),
    )
    subtitle.wrapOn(c, 470, 80)
    subtitle.drawOn(c, 56, H - 258)

    # Project report label
    c.setFillColor(PRIMARY)
    c.setFont("SegoeUI-Bold", 8.2)
    c.drawString(56, H - 322, "PROJECT REPORT  ·  ACADEMIC YEAR 2025 - 26")

    abstract = Paragraph(
        "This report documents the design, implementation and evaluation of a software-only "
        "analyzer for household electricity consumption. The system computes appliance-level "
        "energy from nameplate power and operating hours, aggregates daily, weekly and monthly "
        "totals, applies an editable tariff and grid emission factor, forecasts the next 30 days "
        "with an interpretable regression model, and quantifies practical savings. The analysis "
        "uses the project's 21-day, 13-appliance Project Dataset (273 appliance-day records). "
        "A blank primary-observation template is provided for additional data collection.",
        ParagraphStyle("coverabs", fontName="SegoeUI", fontSize=9.0, leading=13.6,
                       textColor=INK, alignment=TA_JUSTIFY),
    )
    abstract.wrapOn(c, 483, 130)
    abstract.drawOn(c, 56, H - 440)

    # Stat cards
    stats = [
        ("21 days", "observation window"),
        ("13", "appliances modelled"),
        ("273", "appliance-day records"),
        ("6", "dashboard modules"),
    ]
    x = 56
    for value, label in stats:
        c.setFillColor(colors.white)
        c.setStrokeColor(GRID)
        c.setLineWidth(0.6)
        c.roundRect(x, 300, 112, 64, 5, stroke=1, fill=1)
        c.setFillColor(PRIMARY)
        c.setFont("SegoeUI-Bold", 18)
        c.drawString(x + 11, 334, value)
        c.setFillColor(MUTED)
        c.setFont("SegoeUI", 6.9)
        c.drawString(x + 11, 316, label)
        x += 120

    # Team No. 1
    c.setFillColor(colors.white)
    c.setStrokeColor(GRID)
    c.setLineWidth(0.6)
    c.roundRect(56, 176, W - 112, 112, 5, stroke=1, fill=1)

    c.setFillColor(PRIMARY)
    c.setFont("SegoeUI-Bold", 7.6)
    c.drawString(68, 270, "TEAM NO. 1")
    c.setFillColor(MUTED)
    c.setFont("SegoeUI-Bold", 7.0)
    c.drawRightString(W - 68, 270, "TEAM MEMBERS")

    c.setFillColor(INK)
    c.setFont("SegoeUI", 8.7)
    member_positions = [(68, 248), (68, 229), (310, 248), (310, 229)]
    for (name, roll), (x, y) in zip(REPORT_META["members"], member_positions):
        c.drawString(x, y, name)
        c.setFillColor(MUTED)
        c.setFont("SegoeUI", 8.2)
        c.drawString(x + 92, y, roll)
        c.setFillColor(INK)
        c.setFont("SegoeUI", 8.7)

    c.setFillColor(MUTED)
    c.setFont("SegoeUI-Bold", 7.0)
    c.drawString(68, 208, "UNDER THE GUIDANCE OF")
    c.setFillColor(INK)
    c.setFont("SegoeUI-Bold", 9.4)
    c.drawString(68, 193, REPORT_META["guide"])

    c.setFillColor(INK)
    c.setFont("SegoeUI-Bold", 9.2)
    c.drawString(56, 158, REPORT_META["department"])
    c.setFillColor(MUTED)
    c.setFont("SegoeUI", 8.4)
    c.drawString(56, 142, f"Academic year {REPORT_META['academic_year']}")

    # Bottom rule and provenance
    c.setStrokeColor(PRIMARY)
    c.setLineWidth(1.2)
    c.line(56, 104, W - 56, 104)
    c.setFillColor(MUTED)
    c.setFont("SegoeUI-Italic", 7.4)
    c.drawString(56, 86, "Project Dataset: 21 days, 13 appliances and 273 appliance-day records supplied with the project.")
    c.drawString(56, 73, "All tariffs, emission factors and savings are editable, illustrative engineering assumptions.")
    c.setFillColor(PRIMARY)
    c.setFont("SegoeUI-Bold", 7.4)
    c.drawString(56, 52, "Built with Python · Pandas · Scikit-learn · Plotly · Streamlit")
    c.restoreState()


def draw_body(c: canvas.Canvas, doc):
    W, H = A4
    c.saveState()
    c.setStrokeColor(GRID)
    c.setLineWidth(0.5)
    c.line(1.9 * cm, H - 1.55 * cm, W - 1.9 * cm, H - 1.55 * cm)
    c.setFont("SegoeUI", 7.1)
    c.setFillColor(MUTED)
    c.drawString(1.9 * cm, H - 1.36 * cm, "Household Electricity Consumption Analyzer")
    c.drawRightString(W - 1.9 * cm, H - 1.36 * cm,
                      "B.Tech CSE  ·  Sustainable Energy Engineering")
    c.line(1.9 * cm, 1.45 * cm, W - 1.9 * cm, 1.45 * cm)
    c.setFont("SegoeUI-Italic", 6.8)
    c.drawString(1.9 * cm, 1.02 * cm,
                 "Software-only project  ·  Project Dataset  ·  21-day appliance-level analysis")
    c.restoreState()


# ---------------------------------------------------------------------------
# Story
# ---------------------------------------------------------------------------
story: list = [NextPageTemplate("body"), PageBreak()]

# ---- Page 2: Abstract, problem statement, objectives, scope -----------------
story += section("1.  Abstract")
story.append(P(
    "Residential electricity is usually visible only as a single monthly bill, so a household "
    "cannot tell which appliance drives consumption, how much is wasted in standby, or whether a "
    "proposed saving is worthwhile. This project develops a software-only Household Electricity "
    "Consumption Analyzer that converts 21 days of appliance-level operating-hour records into "
    "energy, cost and CO<sub>2</sub>e estimates, forecasts the following month, and quantifies "
    "practical savings. It is implemented in Python with Pandas and NumPy, Scikit-learn, "
    "Plotly/Matplotlib and Streamlit. The project's 21-day, 13-appliance winter Project Dataset "
    "of 273 records is analysed end to end. The window totals "
    f"<b>{quality['total_kwh']:.1f} kWh</b> ({cost['avg_daily_kwh']:.2f} kWh/day), projecting "
    f"<b>{cost['monthly_kwh']:.1f} kWh and Rs. {cost['monthly_cost_inr']:,.0f}</b> per 30-day month "
    f"at an illustrative Rs. {TARIFF:.2f}/kWh. The geyser, refrigerator and air conditioner account "
    f"for <b>{top_three_share:.1f}%</b> of use, standby for {standby_share:.1f}%, and six actions "
    f"could save <b>{combined['monthly_kwh']:.1f} kWh, Rs. {combined['monthly_inr']:,.0f} and "
    f"{combined['monthly_co2_kg']:.1f} kg CO<sub>2</sub>e</b> per month. A seven-day holdout gives "
    f"the forecast an MAE of {pred['metrics']['mae']:.2f} kWh/day against a "
    f"{pred['baseline_metrics']['mae']:.2f} kWh/day naive baseline."
))
story.append(Spacer(1, 5))
story.append(callout(
    "Problem statement",
    "A monthly bill aggregates every end use into one number. Without appliance-level visibility, "
    "households cannot prioritise efficiency actions, detect standby waste, validate a saving, or "
    "relate electricity use to carbon emissions. Manual meter reading is slow, error-prone and "
    "rarely recorded in a structured form. The problem is therefore to design a transparent, "
    "reproducible software workflow that converts modest manual observations into defensible "
    "energy, cost, forecast and sustainability estimates &mdash; without hardware and without "
    "presenting estimated values as measured data.",
))
story.append(Spacer(1, 8))

story.append(P("1.1  Objectives", h2))
objectives = [
    "Define a normalised 21-day, appliance-level data schema and a transparent cleaning pipeline that preserves provenance.",
    "Compute energy from nameplate power and operating hours, then aggregate daily, weekly and monthly consumption.",
    "Apply an editable electricity tariff and grid emission factor to produce cost and CO<sub>2</sub>e estimates.",
    "Forecast the next 30 days with an interpretable regression model and benchmark it against a naive baseline.",
    "Quantify practical saving actions and expose all results through an interactive six-module dashboard.",
    "Preserve record-level provenance (provided, estimated and observed) and supply a blank primary-observation template.",
]
for item in objectives:
    story.append(Paragraph(item, bullet, bulletText="•"))

story.append(P("1.2  Scope", h2))
story.append(P(
    "The deliverable is a single-household, software-only prototype covering 13 common appliances "
    "over a 21-day winter window. It includes data generation, cleaning, analysis, prediction, "
    "recommendation, visualisation, reporting and automated tests. Hardware sensors, real-time "
    "metering, tariff optimisation, weather modelling, multi-household benchmarking and personal "
    "data collection are outside the scope. The Project Dataset supplies the working analysis, and "
    "the provided template supports additional primary readings."
))

story.append(P("1.3  Key contributions", h2))
for text in [
    "<b>One tested calculation core.</b> A single implementation of the energy, cost, carbon and forecasting formulas serves the dashboard, the static figures and the automated tests, eliminating copy-paste drift between views.",
    "<b>Provenance by construction.</b> Every record carries a source label, and the cleaning stage can only ever mark a repaired record as Estimated &mdash; never as observed.",
    "<b>Editable assumptions.</b> Tariff, fixed charge, grid emission factor and appliance parameters are inputs with sensible defaults, not buried constants.",
    "<b>Honest dual projection.</b> The mean-based monthly bill and the trend-based model forecast are reported side by side, so the household can see both the conventional estimate and the model's view.",
]:
    story.append(Paragraph(text, bullet, bulletText="•"))

story.append(P("1.4  Report organisation", h2))
story.append(P(
    "Section 2 describes the architecture, energy model and dataset design. Section 3 covers data "
    "quality, provenance and configurable assumptions. Sections 4 to 6 present consumption, "
    "appliance-level findings and the forecast. Section 7 quantifies environmental impact and "
    "saving actions, Section 8 walks through the dashboard, and Section 9 discusses limitations, "
    "conclusions and future work."
))

# ---- Page 3: Methodology and architecture ----------------------------------
story.append(PageBreak())
story += section("2.  Methodology")
story.append(P(
    "The system follows a linear, auditable pipeline. Raw appliance-day records enter a validation "
    "and cleaning stage; cleaned records feed an energy calculator and four analytical services "
    "(cost, sustainability, prediction and recommendations); results are rendered by a Streamlit "
    "dashboard and by static report figures. Configuration, assumptions and appliance metadata are "
    "centralised so that a single change propagates consistently to every output."
))
story.append(P("2.1  System architecture", h2))
story += figure(
    config.VIS_DIR / "system_architecture.png", 16.6,
    "Figure 1. End-to-end system architecture. Data flows from the Project Dataset or an uploaded "
    "CSV through cleaning and energy calculation to analysis, prediction, presentation and reporting.",
)

story.append(P("2.2  Energy model", h2))
story.append(P(
    "Energy is recomputed from first principles for every appliance <i>i</i> on every day <i>d</i>, "
    "rather than trusting a pre-computed column:"
))
eq = Table([[
    Paragraph(
        "<b>E_op</b>      =  P_rated  ×  N_units  ×  t_op  /  1000<br/>"
        "<b>E_standby</b> =  P_stdby  ×  N_units  ×  t_standby  /  1000<br/>"
        "<b>E_total</b>   =  E_op  +  E_standby<br/>"
        "<font size=7.6 color='#64748B'>P in watts · N = number of identical units · t in hours per day · E in kWh</font>",
        ParagraphStyle("eq", fontName="SegoeUI", fontSize=9.4, leading=16.5, textColor=INK),
    )
]], colWidths=[17.0 * cm])
eq.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, -1), SURFACE),
    ("BOX", (0, 0), (-1, -1), 0.5, GRID),
    ("LINEBEFORE", (0, 0), (0, -1), 3, EMERALD),
    ("LEFTPADDING", (0, 0), (-1, -1), 12),
    ("TOPPADDING", (0, 0), (-1, -1), 7),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
]))
story.append(eq)
story.append(Spacer(1, 4))
story.append(P(
    "Power is in watts, time in hours and energy in kilowatt-hours. The same formula drives the "
    "dashboard, the report and the tests, so a unit error cannot silently diverge between views. "
    "Daily totals are summed to weekly and 21-day totals; the headline monthly projection uses "
    "<i>mean daily consumption × 30</i>, a transparent convention that is kept separate from the "
    "model-based 30-day forecast."
))

story.append(P("2.3  Dataset design", h2))
story.append(P(
    f"The Project Dataset spans {quality['date_start']} to {quality['date_end']} "
    f"({quality['days']} consecutive days) and contains {quality['rows_out']} records "
    f"({quality['appliances']} appliances × 21 days). A winter profile is used deliberately: the "
    "storage geyser and refrigerator dominate, while the air conditioner runs only occasionally. "
    "Weekend multipliers increase daytime occupancy loads, and small day-to-day noise prevents the "
    "data from looking artificially smooth. Appliance nameplate power, standby power, unit counts "
    "and design hours are stored in <i>appliance_database.csv</i>; observations are stored in "
    "<i>project_dataset_raw.csv</i>. Five anomalies are present in the supplied file &mdash; three "
    "missing values, one negative operating duration and one duration above 24 hours &mdash; and "
    "they exercise cleaning and provenance marking."
))

# ---- Page 4: Data quality, assumptions -------------------------------------
story.append(PageBreak())
story += section("3.  Data Quality and Assumptions")
story.append(P(
    "Cleaning is deliberately explicit. The pipeline parses dates, coerces numeric fields, removes "
    "unusable identity rows and duplicates, treats negative or over-24-hour durations as missing, "
    "imputes with the appliance median (falling back to the global median), recomputes energy from "
    "the fundamental formula, and marks every affected record as <b>Estimated</b>. The original "
    "file is never overwritten by the cleaning step."
))

quality_rows = [
    ["Quality indicator", "Value", "Interpretation"],
    ["Rows read / retained", f"{quality['rows_in']} / {quality['rows_out']}", "No identity rows or duplicates lost"],
    ["Invalid durations corrected", str(quality["invalid_hours_corrected"]), "Negative and >24 h values reset to missing"],
    ["Records imputed", str(quality["missing_values_imputed"]), "Appliance-median imputation"],
    ["Estimated records", str(quality["estimated_records"]), f"{quality['estimated_records'] / quality['rows_out'] * 100:.1f}% of the dataset"],
    ["Project Dataset / Observed", f"{quality['simulated_records']} / {quality['observed_records']}", "Bundled records / genuine observations"],
    ["Study window", f"{quality['days']} days", f"{quality['date_start']} to {quality['date_end']}"],
]
story.append(make_table(quality_rows, [5.2, 3.3, 8.3], right_cols=[1]))
story.append(Spacer(1, 8))

story.append(P("3.1  Provenance rules", h2))
story.append(P(
    "<b>Project Dataset</b> records are the appliance-day observations supplied with the project. "
    "<b>Estimated</b> records are computed or imputed rather than directly observed; they include "
    "appliance-median imputations and scenario adjustments. <b>Observed</b> records must originate "
    "from a completed primary-observation template. The dashboard displays the record counts by "
    "source on every page and never describes estimated values as measured. A schema validator "
    "checks required columns, date continuity, numeric ranges and the 21-day requirement before an "
    "uploaded file can replace the working dataset."
))

story.append(P("3.2  Configurable assumptions", h2))
assumption_rows = [
    ["Assumption", "Default", "Status"],
    ["Electricity tariff", f"Rs. {TARIFF:.2f} / kWh", "Editable illustrative slab-mixed value"],
    ["Fixed monthly charge", f"Rs. {cost['fixed_charge_inr']:.2f}", "Editable; excluded from headline"],
    ["Grid emission factor", f"{EMISSION_FACTOR:.2f} kg CO2e / kWh", "Editable; rounded CEA-style approximation"],
    ["Projection period", f"{config.PROJECTION_DAYS} days", "Utility billing-month convention"],
    ["Forecast horizon", f"{config.FORECAST_DAYS} days", "Model-based cross-check, shown separately"],
    ["Car equivalence", "0.171 kg CO2e / km", "Illustrative passenger-car factor"],
    ["Tree absorption", "21 kg CO2 / tree / year", "Illustrative mature-tree average"],
]
story.append(make_table(assumption_rows, [5.0, 4.5, 7.3], right_cols=[1]))
story.append(Spacer(1, 5))
story.append(P(
    "No official utility tariff or verified emission factor is claimed. Both are inputs, not "
    "results; changing either recalculates every cost and carbon figure in the dashboard and the "
    "report build.", small,
))

story.append(P("3.3  Appliance master data", h2))
story.append(P(
    "Nameplate ratings, standby draw, unit counts and design hours live in a single editable table. "
    "The values below are typical domestic ratings, not measurements taken in the study household.", small,
))
master_rows = [["ID", "Appliance", "Rated W", "Standby W", "Units", "Design h/day", "kWh/day"]]
for row in design_db.sort_values("appliance_id").itertuples():
    master_rows.append([
        row.appliance_id, row.appliance_name, f"{row.rated_power_w:.0f}",
        f"{row.standby_power_w:.1f}", str(row.units),
        f"{row.avg_daily_hours:.2f}", f"{row.design_daily_kwh:.2f}",
    ])
story.append(make_table(master_rows, [1.2, 5.2, 1.8, 2.0, 1.3, 2.7, 2.2], font_size=6.9,
                        right_cols=[2, 3, 4, 5, 6], row_padding=2.1))

# ---- Page 5: Consumption results ------------------------------------------
story.append(PageBreak())
story += section("4.  Consumption Results")
story.append(kpi_strip([
    (f"{quality['total_kwh']:.1f} kWh", "21-day energy"),
    (f"{cost['avg_daily_kwh']:.2f} kWh", "average per day"),
    (f"{cost['monthly_kwh']:.1f} kWh", "projected month"),
    (f"Rs. {cost['monthly_cost_inr']:,.0f}", "projected monthly bill"),
]))
story.append(Spacer(1, 7))
story.append(P(
    f"Daily consumption averaged {cost['avg_daily_kwh']:.2f} kWh and remained between "
    f"{low['total_kwh']:.2f} kWh on {low['date'].strftime('%d %B')} and {peak['total_kwh']:.2f} kWh "
    f"on {peak['date'].strftime('%d %B')}. Weekends averaged {weekend_mean:.2f} kWh/day against "
    f"{weekday_mean:.2f} kWh/day on weekdays, an increase of {weekend_delta:.1f}%, consistent with "
    "more daytime occupancy and additional washing, cooking and entertainment loads. The peak day "
    "combines a cold-weather geyser cycle with weekend use; it is a demand-management target rather "
    "than a data error."
))
story += figure(
    config.VIS_DIR / "daily_consumption.png", 16.8,
    "Figure 2. Daily household electricity consumption over 21 days, with a seven-day moving "
    "average and weekend markers. The final Sunday is the study peak.",
)
weekly_rows = [["Week", "Period", "Total (kWh)", "Avg/day (kWh)", "Standby (kWh)", "Peak day (kWh)"]]
for row in weekly.itertuples():
    weekly_rows.append([
        f"W{row.week_number}",
        f"{row.start_date.strftime('%d %b')} - {row.end_date.strftime('%d %b')}",
        f"{row.total_kwh:.2f}", f"{row.avg_daily_kwh:.2f}",
        f"{row.standby_kwh:.2f}", f"{row.peak_day_kwh:.2f}",
    ])
story.append(make_table(weekly_rows, [1.4, 4.4, 3.0, 3.0, 2.8, 2.8], right_cols=[2, 3, 4, 5]))
story.append(Spacer(1, 4))
story.append(P(
    "Weekly totals are stable at roughly 79-81 kWh, so the 21-day mean is a defensible basis for "
    "projection. The third week carries the peak and the largest standby total; both are driven by "
    "heating and entertainment appliances rather than by a structural change in the household.",
    small,
))

story.append(P("4.1  Day-type and cost summary", h2))
daytype_rows = [
    ["Indicator", "Value", "Basis"],
    ["Weekday mean", f"{weekday_mean:.2f} kWh/day", f"{int((~daily['is_weekend']).sum())} weekdays in the window"],
    ["Weekend mean", f"{weekend_mean:.2f} kWh/day", f"{int(daily['is_weekend'].sum())} weekend days"],
    ["Weekend uplift", f"+{weekend_delta:.1f}%", "Difference relative to the weekday mean"],
    ["Window energy cost", f"Rs. {cost['window_cost_inr']:,.2f}", f"{quality['total_kwh']:.1f} kWh at Rs. {TARIFF:.2f}/kWh"],
    ["Projected monthly bill", f"Rs. {cost['monthly_cost_inr']:,.2f}", f"{cost['monthly_kwh']:.1f} kWh at the same tariff"],
]
story.append(make_table(daytype_rows, [4.6, 3.6, 8.6], right_cols=[1]))
story.append(Spacer(1, 3))
story.append(P(
    "The uplift is behavioural rather than weather-driven: the household is occupied for more hours "
    "at the weekend, so lighting, entertainment, cooking and laundry overlap. Shifting deferrable "
    "loads such as washing and ironing to weekday evenings would flatten the profile without "
    "reducing service.", small,
))

# ---- Page 6: Appliance analysis -------------------------------------------
story.append(PageBreak())
story += section("5.  Appliance-Level Analysis")
story += figure(
    config.VIS_DIR / "appliance_consumption.png", 16.8,
    "Figure 3. Twenty-one-day energy consumption by appliance, split into operating and standby "
    "components. The water heater is the dominant end use.",
)
story.append(P(
    f"{top_name} alone accounts for {appl.iloc[0]['share_pct']:.1f}% of consumption, followed by "
    f"{appl.iloc[1]['appliance_name']} ({appl.iloc[1]['share_pct']:.1f}%) and "
    f"{appl.iloc[2]['appliance_name']} ({appl.iloc[2]['share_pct']:.1f}%). Together the top three "
    f"represent {top_three_share:.1f}% of the total, so interventions should start there. Standby "
    f"draws {quality['standby_kwh']:.2f} kWh over the window ({standby_share:.1f}% of all energy); "
    "the television spends the largest share of its own energy in standby, while the desktop, "
    "microwave and washing machine also contribute materially."
))
appliance_rows = [["Appliance", "Category", "21-day kWh", "Share %", "Monthly kWh", "Standby kWh"]]
for row in appl.itertuples():
    appliance_rows.append([
        row.appliance_name, row.category, f"{row.total_kwh:.2f}", f"{row.share_pct:.1f}",
        f"{row.projected_monthly_kwh:.1f}", f"{row.standby_kwh:.2f}",
    ])
story.append(make_table(appliance_rows, [5.3, 3.1, 2.3, 1.9, 2.5, 2.3], font_size=7.1,
                        right_cols=[2, 3, 4, 5], row_padding=2.6))
story.append(Spacer(1, 4))
story.append(P(
    "Monthly values apply the mean daily appliance consumption over 30 days. The refrigerator's "
    "12 effective compressor hours are a modelling convention, not a continuous 180 W draw; the "
    "geyser's thermostat cycling is represented through effective operating hours. These "
    "conventions are stated so that the numbers are not over-interpreted as submetered data.", small,
))

# ---- Page 7: Prediction ----------------------------------------------------
story.append(PageBreak())
story += section("6.  Consumption Forecasting")
story.append(P(
    "A Ridge regression is used because it is interpretable, robust on short series and cheap to "
    "refit. Four features capture the structure that a 21-day record can support: a linear trend, a "
    "weekend indicator, and sine/cosine terms for the weekly cycle. The last seven days are held "
    "out chronologically, and a naive seven-day moving average is evaluated on exactly the same "
    "holdout. The final model is then refitted on all 21 observations to produce a 30-day forecast "
    "with an approximate 95% interval derived from holdout RMSE."
))
metric_rows = [["Model", "MAE (kWh/day)", "RMSE (kWh/day)", "MAPE (%)", "R2"]]
for row in model_comparison_table(pred).itertuples(index=False):
    metric_rows.append([row[0], f"{row[1]:.2f}", f"{row[2]:.2f}", f"{row[3]:.2f}", f"{row[4]:.3f}"])
story.append(make_table(metric_rows, [8.4, 2.4, 2.5, 1.9, 1.8], right_cols=[1, 2, 3, 4]))
story.append(Spacer(1, 6))
story += figure(
    config.VIS_DIR / "consumption_prediction.png", 16.7,
    "Figure 4. Observed daily consumption, the seven-day holdout comparison and the 30-day forecast "
    "with an approximate 95% interval.",
)
story.append(P(
    f"The model achieves an MAE of {pred['metrics']['mae']:.2f} kWh/day and an RMSE of "
    f"{pred['metrics']['rmse']:.2f} kWh/day on the holdout, compared with "
    f"{pred['baseline_metrics']['mae']:.2f} and {pred['baseline_metrics']['rmse']:.2f} for the "
    f"naive baseline. The improvement is real but modest: the holdout has only seven points, the "
    f"coefficient of determination is {pred['metrics']['r2']:.2f}, and the series is short. "
    f"The fitted weekend effect is +{pred['coefficients']['is_weekend']:.2f} kWh/day, which matches "
    "the observed weekday-weekend gap. The 30-day model forecast totals "
    f"<b>{pred['monthly_forecast_kwh']:.1f} kWh</b> (about Rs. {forecast_cost:,.0f}), higher than "
    f"the headline {cost['monthly_kwh']:.1f} kWh because the regression extrapolates the positive "
    "trend, whereas the headline uses the 21-day mean. The two figures answer different questions "
    "and are reported separately rather than blended."
))

story.append(P("6.1  Interpreting the coefficients", h2))
coef_rows = [
    ["Term", "Coefficient (kWh/day)", "Reading"],
    ["Intercept", f"{pred['model_equation_terms']['intercept']:.3f}", "Fitted weekday baseline at the start of the window"],
    ["Trend", f"{pred['coefficients']['trend']:+.4f}", "Small daily drift; drives the higher 30-day forecast"],
    ["Weekend", f"{pred['coefficients']['is_weekend']:+.3f}", "Extra energy on Saturday and Sunday"],
    ["sin(week)", f"{pred['coefficients']['sin_week']:+.3f}", "Weekly shape term"],
    ["cos(week)", f"{pred['coefficients']['cos_week']:+.3f}", "Weekly shape term"],
]
story.append(make_table(coef_rows, [3.4, 4.4, 9.0], font_size=7.2, right_cols=[1], row_padding=2.8))
story.append(Spacer(1, 3))
story.append(P(
    "The weekend coefficient is the clearest signal and agrees with the descriptive comparison. The "
    "trend is small per day but compounds across a 30-day horizon, which explains most of the gap "
    "between the model forecast and the mean-based projection. The sine and cosine terms let the "
    "fitted curve bend within the week without adding calendar-specific rules.", small,
))

# ---- Page 8: Sustainability and recommendations ----------------------------
story.append(PageBreak())
story += section("7.  Sustainability and Saving Actions")
story.append(P(
    f"At {EMISSION_FACTOR:.2f} kg CO<sub>2</sub>e/kWh, the 21-day window corresponds to "
    f"{sust['window_co2_kg']:.1f} kg CO<sub>2</sub>e. The projected month is "
    f"<b>{sust['monthly_co2_kg']:.1f} kg</b> and the annualised footprint is "
    f"<b>{sust['annual_co2_kg']:,.0f} kg ({sust['annual_co2_tonnes']:.2f} t)</b>, equivalent to the "
    f"illustrative annual absorption of {sust['equivalent_tree_years']:.0f} mature tree-years or "
    f"{sust['equivalent_car_km']:,.0f} car-kilometres. These equivalences communicate scale only; "
    "they are not offsets."
))
story += figure(
    config.VIS_DIR / "co2_emissions.png", 15.8,
    "Figure 5. Estimated monthly CO2e contribution by appliance at the default grid emission factor.",
)
story.append(P("7.1  Quantified actions", h2))
rec_rows = [["Action", "kWh/mo", "Rs./mo", "kg CO2e/mo", "Assumption"]]
for rec in recs:
    rec_rows.append([
        rec["title"], f"{rec['monthly_kwh']:.1f}", f"{rec['monthly_inr']:.0f}",
        f"{rec['monthly_co2_kg']:.1f}", rec["assumption"],
    ])
story.append(make_table(rec_rows, [4.5, 1.5, 1.6, 2.1, 7.3], font_size=6.9,
                        right_cols=[1, 2, 3], row_padding=2.7))
story.append(Spacer(1, 5))
story.append(callout(
    "Combined package",
    f"Implementing all six actions saves <b>{combined['monthly_kwh']:.1f} kWh</b>, "
    f"<b>Rs. {combined['monthly_inr']:,.0f}</b> and <b>{combined['monthly_co2_kg']:.1f} kg "
    f"CO<sub>2</sub>e</b> per month &mdash; {combined['pct_of_monthly']:.1f}% of projected "
    f"consumption, or about Rs. {combined['annual_inr']:,.0f} and "
    f"{combined['annual_co2_kg']:.1f} kg CO<sub>2</sub>e per year. Savings are additive because "
    "each action targets a distinct end use. They are engineering estimates, not guaranteed outcomes.",
    fill=LIGHT, bar=PRIMARY,
))
story.append(Spacer(1, 6))
story.append(P("7.2  Prioritisation", h2))
story.append(P(
    f"The geyser action is the largest single saving ({recs[0]['monthly_kwh']:.1f} kWh/month) and "
    f"costs nothing to try. Standby switching is second ({recs[1]['monthly_kwh']:.1f} kWh/month) and "
    "requires only a habit change, while the CFL replacement is the smallest but most permanent. The "
    "air-conditioner action is modest in winter yet becomes far more valuable in summer, so it should "
    "be retained as a seasonal measure. In practice a household should start with the two zero-cost "
    "behavioural actions, verify the change against the next bill, then invest in equipment."
))

# ---- Page 9: Dashboard walkthrough ----------------------------------------
story.append(PageBreak())
story += section("8.  Interactive Dashboard")
story.append(P(
    "The Streamlit application exposes six modules: <b>Home</b> (headline metrics, daily chart, "
    "appliance donut and insights), <b>Consumption Analysis</b> (daily, weekly, cost and "
    "distribution views), <b>Appliance Analysis</b> (ranked bars, standby comparison, editable "
    "scenario), <b>Prediction</b> (holdout metrics, forecast table and chart), <b>Sustainability "
    "Insights</b> (emissions, equivalences and an action planner) and <b>Data Management</b> "
    "(upload, validation, manual observation entry and provenance log). Tariff and grid factor are "
    "editable in the sidebar and propagate to every page."
))
story += figure(
    config.SCREENSHOT_DIR / "report_home.png", 14.2,
    "Figure 6. Home dashboard: headline KPIs, provenance notice, daily consumption chart and "
    "appliance distribution drawn from the cleaned dataset.",
    optional=True,
)
story += figure(
    config.SCREENSHOT_DIR / "report_sustainability.png", 14.2,
    "Figure 7. Sustainability Insights: monthly emissions by appliance and the interactive action "
    "planner used to build the combined saving package.",
    optional=True,
)

# ---- Page 10: Discussion, limitations, conclusion, references --------------
story.append(PageBreak())
story += section("9.  Discussion, Limitations and Conclusion")
story.append(P("9.1  Discussion", h2))
story.append(P(
    "The project demonstrates that a small, well-structured software system can turn modest manual "
    "records into a coherent efficiency assessment. The dominant loads are physically plausible: "
    "water heating and refrigeration dominate a winter household, the air conditioner is secondary, "
    "and standby is a persistent low-grade waste. The forecast improves on a naive baseline, but the "
    "honest conclusion is that 21 days is a short modelling window and that the value lies in the "
    "transparent pipeline rather than in a high R<super>2</super>. Separating the mean-based monthly "
    "projection from the trend-based forecast prevents a single number from being over-claimed.", body_tight,
))
story.append(P("9.2  Limitations", h2))
for text in [
    "The Project Dataset is used as supplied; its measurement provenance is not independently verified, so reported metrics demonstrate the pipeline rather than field accuracy.",
    "Nameplate power differs from real draw, which varies with load, temperature, age and duty cycle; effective hours are an approximation.",
    "Operating hours are self-reported and rounded; the 21-day window is too short to capture seasonal transition or annual behaviour.",
    "The regression uses only trend and weekly structure; it omits weather, occupancy, holidays and tariff changes.",
    "The tariff is a flat illustrative value, and the emission factor is a static approximation rather than a live grid value.",
    "Savings assume independent actions and conservative behavioural adherence; rebound effects and overlapping measures are not modelled.",
]:
    story.append(Paragraph(text, bullet, bulletText="•"))

story.append(P("9.3  Conclusion", h2))
story.append(P(
    f"The analyzer meets its objective: it computes {quality['total_kwh']:.1f} kWh over 21 days, "
    f"projects {cost['monthly_kwh']:.1f} kWh and Rs. {cost['monthly_cost_inr']:,.0f} per month, "
    f"estimates {sust['monthly_co2_kg']:.1f} kg CO<sub>2</sub>e monthly, forecasts "
    f"{pred['monthly_forecast_kwh']:.1f} kWh over 30 days, and identifies "
    f"{combined['monthly_kwh']:.1f} kWh of monthly savings. All calculations are reproducible, all "
    "assumptions are editable, and every record carries a provenance label. The software is ready "
    "to accept genuine 21-day observations through the provided template; doing so is the necessary "
    "next step before any claim about a real household is made.", body_tight,
))

story.append(P("9.4  Future scope", h2))
story.append(P(
    "Natural extensions include smart-plug or IoT ingestion, weather-aware features, time-of-use "
    "tariffs, multi-household comparison, anomaly alerts, a mobile layout, and a longer seasonal "
    "study. Persisting observations in a database and adding authenticated multi-user access would "
    "turn the prototype into a deployable tool.", body_tight,
))

story.append(P("9.5  Declaration and availability", h2))
story.append(P(
    "The source code, datasets, blank observation template, automated tests, screenshots and "
    "presentation are included in the project archive. The software is reproduced by installing the "
    "pinned dependencies and running the commands in Appendix A. No physical sensors, proprietary "
    "services or personal household data are required.", body_tight,
))

story.append(P("References", h2))
references = [
    "Central Electricity Authority (India). <i>CO2 Baseline Database for the Indian Power Sector</i>. User guide, latest edition.",
    "International Energy Agency. <i>Energy Efficiency 2024</i>. IEA, Paris.",
    "Bureau of Energy Efficiency (India). <i>Standards and Labelling Programme</i>: appliance star-rating methodology.",
    "Streamlit. <i>Streamlit Documentation</i>. https://docs.streamlit.io",
    "Pedregosa, F. et al. (2011). Scikit-learn: Machine Learning in Python. <i>Journal of Machine Learning Research</i>, 12, 2825-2830.",
    "McKinney, W. (2010). Data Structures for Statistical Computing in Python. <i>Proceedings of the 9th Python in Science Conference</i>, 56-61.",
]
for ref_text in references:
    story.append(Paragraph(ref_text, ref))

# ---------------------------------------------------------------------------
# Appendix: reproducibility
# ---------------------------------------------------------------------------
story.append(P("Appendix A.  Reproducibility", h2))
cmd_style = ParagraphStyle("cmd", fontName="SegoeUI", fontSize=7.7, leading=11.4,
                           textColor=INK, leftIndent=2)
commands = [
    ("1", "py -m pip install -r requirements.txt", "install pinned dependencies"),
    ("2", "py scripts/generate_dataset.py", "regenerate the 21-day Project Dataset"),
    ("3", "py -m streamlit run app.py", "launch the dashboard at localhost:8501"),
    ("4", "py scripts/generate_report.py", "rebuild this report from computed metrics"),
    ("5", "py -m unittest discover -s tests -v", "run the automated test suite"),
]
cmd_rows = []
for number, command, note in commands:
    cmd_rows.append([
        Paragraph(f"<b>{number}</b>", cmd_style),
        Paragraph(f"<font face='Courier'>{esc(command)}</font>", cmd_style),
        Paragraph(note, ParagraphStyle("note", parent=cmd_style, textColor=MUTED)),
    ])
cmd_table = Table(cmd_rows, colWidths=[0.7 * cm, 8.3 * cm, 8.0 * cm])
cmd_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, -1), SURFACE),
    ("BOX", (0, 0), (-1, -1), 0.5, GRID),
    ("LINEBELOW", (0, 0), (-1, -2), 0.35, GRID),
    ("LEFTPADDING", (0, 0), (-1, -1), 6),
    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ("TOPPADDING", (0, 0), (-1, -1), 2.8),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 2.8),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
]))
story.append(cmd_table)

# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------
config.REPORT_DIR.mkdir(parents=True, exist_ok=True)

doc = BaseDocTemplate(
    str(OUTPUT_PATH), pagesize=A4,
    leftMargin=1.9 * cm, rightMargin=1.9 * cm,
    topMargin=1.85 * cm, bottomMargin=1.85 * cm,
    title="Household Electricity Consumption Analyzer - Project Report",
    author="B.Tech CSE (Sustainable Energy Engineering)",
    subject="Appliance-level energy, cost, forecast and carbon analysis",
)
cover_frame = Frame(0, 0, A4[0], A4[1], id="cover", showBoundary=0,
                    leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
body_frame = Frame(1.9 * cm, 1.85 * cm, A4[0] - 3.8 * cm, A4[1] - 3.7 * cm, id="body")
doc.addPageTemplates([
    PageTemplate(id="cover", frames=[cover_frame], onPage=draw_cover),
    PageTemplate(id="body", frames=[body_frame], onPage=draw_body),
])
doc.build(story, canvasmaker=NumberedCanvas)

pages = len(PdfReader(str(OUTPUT_PATH)).pages)
print(f"Report written: {OUTPUT_PATH}")
print(f"Pages: {pages}")
if pages > 10:
    print("WARNING: report exceeds the 10-page limit.")
else:
    print("Page limit satisfied (<= 10).")
