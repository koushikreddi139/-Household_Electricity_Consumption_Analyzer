"""
Plotly chart builders for the Streamlit dashboard.

Every chart includes a title, labelled axes with units, a legend where needed
and a consistent green/neutral visual identity.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from . import config

FONT_FAMILY = "Manrope, Inter, Segoe UI, sans-serif"
GRID = "#E6ECEA"
INK = "#0F172A"
MUTED = "#64748B"


def _base(fig: go.Figure, title: str, height: int = 380) -> go.Figure:
    fig.update_layout(
        title=dict(text=title, x=0.01, xanchor="left", font=dict(size=16, color=INK, family=FONT_FAMILY)),
        height=height,
        margin=dict(l=10, r=18, t=58, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family=FONT_FAMILY, size=12, color="#334155"),
        hoverlabel=dict(bgcolor="#0B3B36", font=dict(color="white", family=FONT_FAMILY)),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1,
                    font=dict(size=11), bgcolor="rgba(0,0,0,0)"),
    )
    fig.update_xaxes(showgrid=False, linecolor=GRID, tickfont=dict(size=11), title_font=dict(size=11))
    fig.update_yaxes(gridcolor=GRID, zeroline=False, tickfont=dict(size=11), title_font=dict(size=11))
    return fig


def daily_consumption_chart(daily_df: pd.DataFrame, height: int = 400) -> go.Figure:
    data = daily_df.sort_values("date").copy()
    data["moving_avg"] = data["total_kwh"].rolling(7, min_periods=3).mean()
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=data["date"], y=data["total_kwh"], mode="lines+markers", name="Daily consumption",
            line=dict(color=config.PALETTE["primary"], width=3, shape="spline", smoothing=0.5),
            marker=dict(size=6, color=config.PALETTE["primary"], line=dict(width=1.5, color="white")),
            fill="tozeroy", fillcolor="rgba(15,118,110,0.10)",
            hovertemplate="<b>%{x|%d %b %Y}</b><br>%{y:.2f} kWh<extra></extra>",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=data["date"], y=data["moving_avg"], mode="lines", name="7-day moving average",
            line=dict(color=config.PALETTE["amber"], width=2, dash="dash"),
            hovertemplate="<b>%{x|%d %b}</b><br>7-day avg: %{y:.2f} kWh<extra></extra>",
        )
    )
    weekends = data[data["is_weekend"]]
    if not weekends.empty:
        fig.add_trace(
            go.Scatter(
                x=weekends["date"], y=weekends["total_kwh"], mode="markers", name="Weekend day",
                marker=dict(size=11, color="rgba(217,119,6,0.18)", line=dict(width=0)),
                hoverinfo="skip", showlegend=True,
            )
        )
    if not data.empty:
        peak = data.loc[data["total_kwh"].idxmax()]
        fig.add_annotation(
            x=peak["date"], y=peak["total_kwh"], text=f"Peak {peak['total_kwh']:.1f} kWh",
            showarrow=True, arrowhead=2, arrowcolor=config.PALETTE["red"], ax=0, ay=-38,
            font=dict(size=11, color=config.PALETTE["red"]),
            bgcolor="rgba(255,255,255,0.9)", bordercolor="#FECACA", borderpad=4,
        )
    fig = _base(fig, "Daily household electricity consumption", height)
    fig.update_yaxes(title_text="Energy consumption (kWh/day)", rangemode="tozero")
    fig.update_xaxes(title_text="Date", tickformat="%d %b")
    return fig


def appliance_consumption_chart(appliance_df: pd.DataFrame, height: int = 430) -> go.Figure:
    data = appliance_df.sort_values("total_kwh", ascending=True).copy()
    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            y=data["appliance_name"], x=data["operating_kwh"], orientation="h", name="Operating energy",
            marker=dict(color=config.PALETTE["primary"], cornerradius=4),
            hovertemplate="<b>%{y}</b><br>Operating: %{x:.2f} kWh<extra></extra>",
        )
    )
    fig.add_trace(
        go.Bar(
            y=data["appliance_name"], x=data["standby_kwh"], orientation="h", name="Standby energy",
            marker=dict(color=config.PALETTE["amber"], cornerradius=4),
            hovertemplate="<b>%{y}</b><br>Standby: %{x:.2f} kWh<extra></extra>",
        )
    )
    fig = _base(fig, "Appliance-wise energy consumption (21-day total)", height)
    fig.update_layout(barmode="stack", bargap=0.28)
    fig.update_xaxes(title_text="Energy consumption (kWh)")
    fig.update_yaxes(title_text="Appliance")
    return fig


def consumption_donut(appliance_df: pd.DataFrame, height: int = 400) -> go.Figure:
    data = appliance_df.sort_values("total_kwh", ascending=False).copy()
    if len(data) > 8:
        top = data.head(7)
        other = data.iloc[7:]
        data = pd.concat(
            [
                top,
                pd.DataFrame(
                    [{
                        "appliance_name": f"Other ({len(other)} appliances)",
                        "total_kwh": other["total_kwh"].sum(),
                    }]
                ),
            ],
            ignore_index=True,
        )
    fig = go.Figure(
        go.Pie(
            labels=data["appliance_name"], values=data["total_kwh"], hole=0.58,
            marker=dict(colors=config.CHART_COLORS[: len(data)], line=dict(color="white", width=2)),
            textinfo="none", textposition="outside", textfont=dict(size=11),
            hovertemplate="<b>%{label}</b><br>%{value:.2f} kWh<br>%{percent}<extra></extra>",
            sort=False,
        )
    )
    total = data["total_kwh"].sum()
    fig.add_annotation(
        text=f"<b>{total:,.0f} kWh</b><br><span style='font-size:11px;color:{MUTED}'>21-day total</span>",
        x=0.5, y=0.5, showarrow=False, font=dict(size=20, color=INK),
    )
    fig = _base(fig, "Consumption distribution by appliance", height)
    fig.update_layout(showlegend=True, legend=dict(orientation="v", y=0.5, x=1.02,
                                                   xanchor="left", yanchor="middle", font=dict(size=10)))
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    return fig


def weekly_consumption_chart(weekly_df: pd.DataFrame, height: int = 360) -> go.Figure:
    labels = [f"Week {int(w)}" for w in weekly_df["week_number"]]
    fig = go.Figure(
        go.Bar(
            x=labels, y=weekly_df["total_kwh"], name="Weekly energy",
            marker=dict(color=[config.PALETTE["primary"], config.PALETTE["emerald"], config.PALETTE["mint"]],
                        cornerradius=6),
            text=[f"{v:.1f} kWh" for v in weekly_df["total_kwh"]], textposition="outside",
            customdata=np.stack([weekly_df["avg_daily_kwh"], weekly_df["days"]], axis=-1),
            hovertemplate=(
                "<b>%{x}</b><br>Total: %{y:.2f} kWh<br>Average: %{customdata[0]:.2f} kWh/day"
                "<br>Days: %{customdata[1]}<extra></extra>"
            ),
        )
    )
    fig = _base(fig, "Weekly electricity consumption comparison", height)
    fig.update_yaxes(title_text="Energy consumption (kWh/week)", rangemode="tozero")
    fig.update_xaxes(title_text="Study week")
    fig.update_layout(showlegend=False)
    return fig


def operating_vs_standby_chart(appliance_df: pd.DataFrame, height: int = 420) -> go.Figure:
    data = appliance_df.sort_values("total_kwh", ascending=True).copy()
    fig = go.Figure()
    fig.add_trace(go.Bar(y=data["appliance_name"], x=data["avg_operating_hours"], orientation="h",
                         name="Average operating hours", marker=dict(color=config.PALETTE["primary"]),
                         hovertemplate="<b>%{y}</b><br>Operating: %{x:.2f} h/day<extra></extra>"))
    fig.add_trace(go.Bar(y=data["appliance_name"], x=data["avg_standby_hours"], orientation="h",
                         name="Average standby hours", marker=dict(color=config.PALETTE["amber"]),
                         hovertemplate="<b>%{y}</b><br>Standby: %{x:.2f} h/day<extra></extra>"))
    fig = _base(fig, "Daily operating versus standby hours", height)
    fig.update_layout(barmode="group", bargap=0.25)
    fig.update_xaxes(title_text="Hours per day (h)")
    fig.update_yaxes(title_text="Appliance")
    return fig


def daily_cost_chart(daily_df: pd.DataFrame, tariff: float, height: int = 340) -> go.Figure:
    data = daily_df.sort_values("date").copy()
    data["cost"] = data["total_kwh"] * tariff
    avg = data["cost"].mean()
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=data["date"], y=data["cost"], mode="lines+markers", name="Daily cost",
            line=dict(color=config.PALETTE["emerald"], width=2.5),
            marker=dict(size=5, color=config.PALETTE["emerald"]),
            fill="tozeroy", fillcolor="rgba(16,185,129,0.12)",
            hovertemplate="<b>%{x|%d %b}</b><br>Rs. %{y:.2f}<extra></extra>",
        )
    )
    fig.add_hline(y=avg, line_dash="dot", line_color=config.PALETTE["muted"],
                  annotation_text=f"Average Rs. {avg:.0f}/day", annotation_position="top left")
    fig = _base(fig, f"Daily electricity cost at Rs. {tariff:.2f}/kWh", height)
    fig.update_yaxes(title_text="Cost (Rs.)", rangemode="tozero")
    fig.update_xaxes(title_text="Date", tickformat="%d %b")
    return fig


def co2_chart(appliance_df: pd.DataFrame, emission_factor: float, height: int = 420) -> go.Figure:
    data = appliance_df.sort_values("projected_monthly_kwh", ascending=True).copy()
    data["co2_month"] = data["projected_monthly_kwh"] * emission_factor
    colors = [config.PALETTE["mint"] if v < data["co2_month"].median() else config.PALETTE["primary"]
              for v in data["co2_month"]]
    fig = go.Figure(
        go.Bar(
            y=data["appliance_name"], x=data["co2_month"], orientation="h", name="Monthly CO2e",
            marker=dict(color=colors, cornerradius=5),
            text=[f"{v:.1f}" for v in data["co2_month"]], textposition="outside",
            hovertemplate="<b>%{y}</b><br>%{x:.2f} kg CO2e/month<extra></extra>",
        )
    )
    fig = _base(fig, "Estimated monthly CO2e contribution by appliance", height)
    fig.update_xaxes(title_text="Emissions (kg CO2e/month)")
    fig.update_yaxes(title_text="Appliance")
    fig.update_layout(showlegend=False)
    return fig


def prediction_chart(result: dict, height: int = 460) -> go.Figure:
    """Actual, holdout prediction and 30-day forecast with uncertainty band."""
    actual = result["fit_frame"]
    test = result["test_frame"]
    forecast = result["forecast_frame"]

    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=forecast["date"], y=forecast["upper_kwh"], mode="lines", line=dict(width=0),
            showlegend=False, hoverinfo="skip",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=forecast["date"], y=forecast["lower_kwh"], mode="lines", line=dict(width=0),
            fill="tonexty", fillcolor="rgba(16,185,129,0.13)", name="Approx. 95% interval",
            hoverinfo="skip",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=actual["date"], y=actual["actual_kwh"], mode="lines+markers", name="Actual consumption",
            line=dict(color=INK, width=2.5), marker=dict(size=4),
            hovertemplate="<b>%{x|%d %b}</b><br>Actual: %{y:.2f} kWh<extra></extra>",
        )
    )
    train = result["train_frame"]
    fig.add_trace(
        go.Scatter(
            x=train["date"], y=train["fitted_kwh"], mode="lines", name="Model fit (training)",
            line=dict(color=config.PALETTE["blue"], width=2, dash="dot"),
            hovertemplate="<b>%{x|%d %b}</b><br>Fitted: %{y:.2f} kWh<extra></extra>",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=test["date"], y=test["predicted_kwh"], mode="lines+markers", name="Holdout prediction",
            line=dict(color=config.PALETTE["amber"], width=2, dash="dash"), marker=dict(size=7, symbol="diamond"),
            hovertemplate="<b>%{x|%d %b}</b><br>Predicted: %{y:.2f} kWh<extra></extra>",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=forecast["date"], y=forecast["predicted_kwh"], mode="lines", name="30-day forecast",
            line=dict(color=config.PALETTE["emerald"], width=3),
            hovertemplate="<b>%{x|%d %b}</b><br>Forecast: %{y:.2f} kWh<extra></extra>",
        )
    )
    fig.add_vline(
        x=result["last_observed_date"].timestamp() * 1000, line_dash="dash", line_color="#94A3B8",
        annotation_text="Forecast starts", annotation_position="top right",
    )
    fig = _base(fig, "Actual versus predicted daily consumption", height)
    fig.update_yaxes(title_text="Energy consumption (kWh/day)", rangemode="tozero")
    fig.update_xaxes(title_text="Date", tickformat="%d %b")
    return fig


def forecast_bar_chart(result: dict, height: int = 340) -> go.Figure:
    data = result["forecast_frame"].copy()
    fig = go.Figure(
        go.Bar(
            x=data["date"], y=data["predicted_kwh"], name="Forecast",
            marker=dict(color=np.where(data["is_weekend"], config.PALETTE["amber"], config.PALETTE["emerald"])),
            hovertemplate="<b>%{x|%d %b}</b><br>%{y:.2f} kWh<extra></extra>",
        )
    )
    fig = _base(fig, "30-day forecast by day (amber = weekend)", height)
    fig.update_yaxes(title_text="Predicted energy (kWh/day)", rangemode="tozero")
    fig.update_xaxes(title_text="Date", tickformat="%d %b")
    fig.update_layout(showlegend=False, bargap=0.25)
    return fig


def savings_waterfall(baseline_kwh: float, selected_kwh: float, height: int = 320) -> go.Figure:
    remaining = max(baseline_kwh - selected_kwh, 0)
    fig = go.Figure(
        go.Bar(
            x=["Current monthly use", "Selected savings", "Remaining use"],
            y=[baseline_kwh, selected_kwh, remaining],
            marker=dict(color=[config.PALETTE["primary"], config.PALETTE["amber"], config.PALETTE["mint"]]),
            text=[f"{v:.1f} kWh" for v in [baseline_kwh, selected_kwh, remaining]],
            textposition="outside",
            hovertemplate="%{x}<br>%{y:.1f} kWh<extra></extra>",
        )
    )
    fig = _base(fig, "Impact of selected actions on monthly consumption", height)
    fig.update_yaxes(title_text="Energy (kWh/month)", rangemode="tozero")
    fig.update_layout(showlegend=False)
    return fig
