"""
Predictive analytics for daily household electricity consumption.

Model
-----
A regularised linear regression (Ridge) is used with four interpretable
features:

* a linear time trend,
* a weekend indicator,
* sine and cosine terms representing the weekly cycle.

The last seven days are held out for a chronological test, and a naive
seven-day moving-average baseline is evaluated on the same holdout. The final
model is refitted on all observations to produce a 30-day forecast with an
approximate 95% interval based on holdout RMSE.

The reported metrics demonstrate that the pipeline works and must not be
presented as verified real-world predictive accuracy.
"""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from . import config


class PredictionError(ValueError):
    """Raised when there are insufficient data to fit the model."""


FEATURES = ["trend", "is_weekend", "sin_week", "cos_week"]


def _feature_frame(dates: pd.Series, origin: pd.Timestamp) -> pd.DataFrame:
    dates = pd.to_datetime(dates)
    day_index = (dates - origin).dt.days.astype(float)
    dow = dates.dt.day_of_week
    return pd.DataFrame(
        {
            "trend": day_index,
            "is_weekend": (dow >= 5).astype(float),
            "sin_week": np.sin(2 * np.pi * day_index / 7.0),
            "cos_week": np.cos(2 * np.pi * day_index / 7.0),
        }
    )


def _metrics(actual: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    mae = mean_absolute_error(actual, predicted)
    rmse = math.sqrt(mean_squared_error(actual, predicted))
    nonzero = actual != 0
    mape = float(np.mean(np.abs((actual[nonzero] - predicted[nonzero]) / actual[nonzero])) * 100) if nonzero.any() else float("nan")
    r2 = float(r2_score(actual, predicted)) if len(actual) > 1 else float("nan")
    return {
        "mae": round(float(mae), 3),
        "rmse": round(float(rmse), 3),
        "mape": round(mape, 2),
        "r2": round(r2, 3),
    }


def fit_and_forecast(
    daily_df: pd.DataFrame,
    horizon: int = config.FORECAST_DAYS,
    test_days: int = 7,
    alpha: float = 2.0,
) -> dict:
    """Fit, evaluate and forecast daily consumption.

    Parameters
    ----------
    daily_df : DataFrame with ``date`` and ``total_kwh`` columns.
    horizon  : number of future days to forecast.
    test_days: size of the chronological holdout.
    alpha    : Ridge regularisation strength.

    Returns
    -------
    dict containing the model, metrics, fitted/test/forecast frames and a
    plain-language summary.
    """
    if not {"date", "total_kwh"}.issubset(daily_df.columns):
        raise PredictionError("daily_df must contain 'date' and 'total_kwh' columns.")
    data = daily_df[["date", "total_kwh"]].copy().sort_values("date").reset_index(drop=True)
    data["date"] = pd.to_datetime(data["date"])
    data["total_kwh"] = pd.to_numeric(data["total_kwh"], errors="coerce")
    data = data.dropna(subset=["total_kwh"])
    if len(data) < test_days + 7:
        raise PredictionError(
            f"At least {test_days + 7} daily observations are required; received {len(data)}."
        )

    origin = data["date"].min()
    X = _feature_frame(data["date"], origin)
    y = data["total_kwh"].to_numpy(dtype=float)

    split = len(data) - test_days
    X_train, X_test = X.iloc[:split], X.iloc[split:]
    y_train, y_test = y[:split], y[split:]

    holdout_model = Ridge(alpha=alpha)
    holdout_model.fit(X_train, y_train)
    y_test_pred = np.clip(holdout_model.predict(X_test), 0, None)
    y_train_pred = np.clip(holdout_model.predict(X_train), 0, None)

    # Naive seven-day moving-average baseline evaluated on the same holdout.
    baseline_pred = []
    for idx in range(split, len(data)):
        history = y[max(0, idx - 7):idx]
        baseline_pred.append(float(np.mean(history)) if len(history) else float(y_train.mean()))
    baseline_pred = np.asarray(baseline_pred)

    metrics_model = _metrics(y_test, y_test_pred)
    metrics_baseline = _metrics(y_test, baseline_pred)

    # Refit on every observation for the future forecast.
    final_model = Ridge(alpha=alpha)
    final_model.fit(X, y)
    fitted_all = np.clip(final_model.predict(X), 0, None)

    future_dates = pd.date_range(data["date"].max() + pd.Timedelta(days=1), periods=horizon, freq="D")
    X_future = _feature_frame(pd.Series(future_dates), origin)
    future_pred = np.clip(final_model.predict(X_future), 0, None)
    interval = 1.96 * max(metrics_model["rmse"], 1e-6)
    future_lower = np.clip(future_pred - interval, 0, None)
    future_upper = future_pred + interval

    test_frame = pd.DataFrame(
        {
            "date": data["date"].iloc[split:].to_numpy(),
            "actual_kwh": y_test,
            "predicted_kwh": y_test_pred.round(3),
            "baseline_kwh": baseline_pred.round(3),
            "residual_kwh": (y_test - y_test_pred).round(3),
        }
    )
    fit_frame = pd.DataFrame(
        {
            "date": data["date"],
            "actual_kwh": y,
            "fitted_kwh": fitted_all.round(3),
        }
    )
    forecast_frame = pd.DataFrame(
        {
            "date": future_dates,
            "predicted_kwh": future_pred.round(3),
            "lower_kwh": future_lower.round(3),
            "upper_kwh": future_upper.round(3),
            "day_of_week": future_dates.day_name(),
            "is_weekend": future_dates.day_of_week >= 5,
        }
    )

    coefficients = dict(zip(FEATURES, final_model.coef_.round(4).tolist()))
    monthly_forecast = float(forecast_frame["predicted_kwh"].sum())
    residual_std = float(np.std(y_test - y_test_pred, ddof=1)) if len(y_test) > 1 else float("nan")

    return {
        "model": final_model,
        "holdout_model": holdout_model,
        "origin": origin,
        "train_size": int(split),
        "test_size": int(test_days),
        "features": FEATURES,
        "alpha": alpha,
        "metrics": metrics_model,
        "baseline_metrics": metrics_baseline,
        "coefficients": coefficients,
        "train_frame": fit_frame.iloc[:split].copy(),
        "fit_frame": fit_frame,
        "test_frame": test_frame,
        "forecast_frame": forecast_frame,
        "forecast_days": int(horizon),
        "monthly_forecast_kwh": round(monthly_forecast, 3),
        "avg_forecast_kwh": round(float(forecast_frame["predicted_kwh"].mean()), 3),
        "residual_std": round(residual_std, 3) if not math.isnan(residual_std) else None,
        "interval_half_width": round(float(interval), 3),
        "mean_observed_kwh": round(float(y.mean()), 3),
        "last_observed_date": data["date"].max(),
        "model_equation_terms": {
            "intercept": round(float(final_model.intercept_), 4),
            **coefficients,
        },
    }


def model_comparison_table(result: dict) -> pd.DataFrame:
    """Readable comparison of the regression model and naive baseline."""
    m = result["metrics"]
    b = result["baseline_metrics"]
    return pd.DataFrame(
        [
            {
                "Model": "Ridge linear regression (trend + weekly cycle)",
                "MAE (kWh/day)": m["mae"],
                "RMSE (kWh/day)": m["rmse"],
                "MAPE (%)": m["mape"],
                "R2": m["r2"],
            },
            {
                "Model": "Naive 7-day moving average baseline",
                "MAE (kWh/day)": b["mae"],
                "RMSE (kWh/day)": b["rmse"],
                "MAPE (%)": b["mape"],
                "R2": b["r2"],
            },
        ]
    )


def prediction_insight(result: dict, tariff: float) -> str:
    """Plain-language summary of the forecast for display."""
    forecast_month = result["monthly_forecast_kwh"]
    avg = result["avg_forecast_kwh"]
    cost = forecast_month * tariff
    direction = "higher than" if avg > result["mean_observed_kwh"] else "lower than"
    return (
        f"The model projects an average of {avg:.2f} kWh/day over the next "
        f"{result['forecast_days']} days, {direction} the 21-day observed mean of "
        f"{result['mean_observed_kwh']:.2f} kWh/day. That is approximately "
        f"{forecast_month:.1f} kWh and Rs. {cost:,.0f} at the selected tariff."
    )
