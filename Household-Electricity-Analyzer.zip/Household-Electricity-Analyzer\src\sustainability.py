"""
Sustainability calculations: grid emissions and annual environmental impact.

The grid emission factor is an editable, illustrative assumption. The default
value (0.71 kg CO2e/kWh) is a rounded approximation of India's grid emission
factor reported in CEA CO2 Baseline Database publications. It is not a live
measurement and should be replaced by the latest verified value if required.
"""

from __future__ import annotations

import pandas as pd

from . import config


def co2_kg(kwh: float, emission_factor_kg_per_kwh: float) -> float:
    """Convert electricity (kWh) to estimated CO2 emissions (kg)."""
    if kwh < 0:
        raise ValueError("kwh must be non-negative.")
    if emission_factor_kg_per_kwh < 0:
        raise ValueError("emission factor must be non-negative.")
    return float(kwh) * float(emission_factor_kg_per_kwh)


def add_emissions(daily_df: pd.DataFrame, emission_factor: float) -> pd.DataFrame:
    """Add daily CO2 estimates to a daily summary."""
    out = daily_df.copy()
    out["co2_kg"] = (out["total_kwh"] * emission_factor).round(3)
    return out


def emissions_by_appliance(appliance_df: pd.DataFrame, emission_factor: float) -> pd.DataFrame:
    """Add window, monthly and annual emission estimates per appliance."""
    out = appliance_df.copy()
    out["co2_window_kg"] = (out["total_kwh"] * emission_factor).round(3)
    out["co2_monthly_kg"] = (out["projected_monthly_kwh"] * emission_factor).round(3)
    out["co2_annual_kg"] = (out["co2_monthly_kg"] * 12).round(3)
    return out


def sustainability_summary(
    daily_df: pd.DataFrame,
    emission_factor: float,
    tariff_inr_per_kwh: float,
) -> dict[str, float]:
    """Headline emissions and equivalence values.

    The car equivalence uses 0.171 kg CO2 per kilometre for an average
    passenger car (illustrative, UK DEFRA/BEIS conversion factor rounded).
    Tree equivalence uses 21 kg CO2 absorbed per mature tree per year
    (widely cited illustrative average).
    """
    total_kwh = float(daily_df["total_kwh"].sum())
    days = max(len(daily_df), 1)
    avg_daily = total_kwh / days
    monthly_kwh = avg_daily * config.PROJECTION_DAYS
    annual_kwh = avg_daily * 365
    monthly_co2 = co2_kg(monthly_kwh, emission_factor)
    annual_co2 = co2_kg(annual_kwh, emission_factor)
    annual_cost = annual_kwh * tariff_inr_per_kwh
    return {
        "window_co2_kg": round(co2_kg(total_kwh, emission_factor), 2),
        "monthly_kwh": round(monthly_kwh, 2),
        "monthly_co2_kg": round(monthly_co2, 2),
        "annual_kwh": round(annual_kwh, 2),
        "annual_co2_kg": round(annual_co2, 2),
        "annual_co2_tonnes": round(annual_co2 / 1000, 3),
        "annual_cost_inr": round(annual_cost, 2),
        "equivalent_tree_years": round(annual_co2 / 21.0, 1),
        "equivalent_car_km": round(annual_co2 / 0.171, 0),
        "emission_factor": float(emission_factor),
    }


def savings_impact(kwh_per_month: float, emission_factor: float, tariff: float) -> dict[str, float]:
    """Environmental and financial impact of a monthly energy saving."""
    monthly_kwh = float(kwh_per_month)
    return {
        "monthly_kwh": round(monthly_kwh, 3),
        "annual_kwh": round(monthly_kwh / 30.0 * 365.0, 3),
        "monthly_co2_kg": round(co2_kg(monthly_kwh, emission_factor), 2),
        "annual_co2_kg": round(co2_kg(monthly_kwh / 30.0 * 365.0, emission_factor), 2),
        "monthly_inr": round(monthly_kwh * tariff, 2),
        "annual_inr": round(monthly_kwh / 30.0 * 365.0 * tariff, 2),
        "equivalent_tree_years": round(
            co2_kg(monthly_kwh / 30.0 * 365.0, emission_factor) / 21.0, 2
        ),
    }
