"""
Transparent, quantified energy-saving recommendations.

Each recommendation states its assumption and computes savings from the
appliance database or the observed consumption profile. Savings from separate
actions are additive because they target distinct end uses (except where an
action is explicitly scaled to remaining usage).

The figures are indicative engineering estimates for a single household, not
guaranteed savings.
"""

from __future__ import annotations

import pandas as pd

from . import config
from .cost_analysis import savings_value
from .sustainability import savings_impact

RECOMMENDATION_LIBRARY = [
    {
        "id": "standby",
        "title": "Switch off idle appliances at the plug",
        "category": "Behavioural",
        "effort": "Low",
        "description": (
            "Televisions, desktop computers, microwave ovens, washing machines and "
            "geysers continue drawing power in standby. Switching them off at the "
            "socket when unused removes most of this waste."
        ),
        "assumption": "90% of measured standby energy is avoidable through plug-point switching.",
    },
    {
        "id": "fan",
        "title": "Trim ceiling-fan runtime by one hour per day",
        "category": "Behavioural",
        "effort": "Low",
        "description": (
            "Switching off fans in unoccupied rooms and using natural ventilation in "
            "winter reduces unnecessary fan operation without reducing comfort."
        ),
        "assumption": "1.0 operating hour/day is avoided for all fan units.",
    },
    {
        "id": "cfl",
        "title": "Replace remaining CFL bulbs with 9 W LEDs",
        "category": "Equipment",
        "effort": "Medium",
        "description": (
            "Older compact fluorescent lamps in utility areas can be replaced with "
            "9 W LED lamps of equivalent light output."
        ),
        "assumption": "Each 9 W LED replaces one CFL and keeps the same operating hours.",
    },
    {
        "id": "geyser",
        "title": "Cut geyser runtime by 20 minutes per day",
        "category": "Operational",
        "effort": "Low",
        "description": (
            "Schedule geyser operation shortly before use, use a timer, and avoid "
            "keeping the thermostat set unnecessarily high. A 20-minute reduction is "
            "a conservative behavioural change."
        ),
        "assumption": "20 minutes/day less heating at the rated geyser power.",
    },
    {
        "id": "washing",
        "title": "Run the washing machine only with full loads",
        "category": "Operational",
        "effort": "Low",
        "description": (
            "Consolidating small washes into full-load cycles reduces the number of "
            "heating and motor cycles per week."
        ),
        "assumption": "25% reduction in washing-machine operating energy.",
    },
    {
        "id": "ac",
        "title": "Optimise air-conditioner schedule and set-point",
        "category": "Operational",
        "effort": "Medium",
        "description": (
            "Use a timer, avoid cooling empty rooms, and set the thermostat to about "
            "26 degrees C. This recommendation is modest in the winter dataset but "
            "becomes significant in summer."
        ),
        "assumption": "25% reduction in air-conditioner operating energy.",
    },
]


def _row(db: pd.DataFrame, appliance_id: str) -> pd.Series | None:
    match = db[db["appliance_id"] == appliance_id]
    return match.iloc[0] if not match.empty else None


def _enrich(rec: dict, monthly_kwh: float, tariff: float, emission_factor: float,
            affected: str, priority: int) -> dict:
    money = savings_value(monthly_kwh, tariff)
    impact = savings_impact(monthly_kwh, emission_factor, tariff)
    rec = dict(rec)
    rec.update(
        {
            "affected_appliances": affected,
            "monthly_kwh": round(monthly_kwh, 3),
            "monthly_inr": money["monthly_inr"],
            "monthly_co2_kg": impact["monthly_co2_kg"],
            "annual_kwh": money["annual_kwh"],
            "annual_inr": money["annual_inr"],
            "annual_co2_kg": impact["annual_co2_kg"],
            "priority": priority,
        }
    )
    return rec


def generate_recommendations(
    appliance_df: pd.DataFrame,
    db: pd.DataFrame,
    tariff: float,
    emission_factor: float,
    days: int = config.OBSERVATION_DAYS,
) -> list[dict]:
    """Build the recommendation list with quantified impacts."""
    days = max(int(days), 1)
    recs: list[dict] = []
    assumptions = config.RECOMMENDATION_ASSUMPTIONS
    standby_total = float(appliance_df["standby_kwh"].sum()) if not appliance_df.empty else 0.0
    standby_daily = standby_total / days

    standby_monthly = (
        standby_daily * config.PROJECTION_DAYS * assumptions["standby_elimination_fraction"]
    )
    recs.append(
        _enrich(
            RECOMMENDATION_LIBRARY[0], standby_monthly, tariff, emission_factor,
            "TV, desktop, microwave, washing machine, AC, geyser", 1,
        )
    )

    fan = _row(db, "A01")
    fan_monthly = 0.0
    if fan is not None:
        fan_monthly = (
            float(fan["rated_power_w"]) * float(fan["units"])
            * assumptions["fan_hour_reduction"] * config.PROJECTION_DAYS / 1000
        )
    recs.append(
        _enrich(RECOMMENDATION_LIBRARY[1], fan_monthly, tariff, emission_factor,
                str(fan["appliance_name"]) if fan is not None else "Ceiling fans", 2)
    )

    cfl = _row(db, "A03")
    cfl_monthly = 0.0
    if cfl is not None:
        saving_per_bulb = max(float(cfl["rated_power_w"]) - assumptions["led_replacement_watts"], 0)
        cfl_monthly = (
            saving_per_bulb * float(cfl["units"]) * float(cfl["avg_daily_hours"])
            * config.PROJECTION_DAYS / 1000
        )
    recs.append(
        _enrich(RECOMMENDATION_LIBRARY[2], cfl_monthly, tariff, emission_factor,
                str(cfl["appliance_name"]) if cfl is not None else "CFL bulbs", 4)
    )

    geyser = _row(db, "A11")
    geyser_monthly = 0.0
    if geyser is not None:
        geyser_monthly = (
            float(geyser["rated_power_w"]) * float(geyser["units"])
            * (assumptions["geyser_minutes_reduction"] / 60.0)
            * config.PROJECTION_DAYS / 1000
        )
    recs.append(
        _enrich(RECOMMENDATION_LIBRARY[3], geyser_monthly, tariff, emission_factor,
                str(geyser["appliance_name"]) if geyser is not None else "Water heater", 3)
    )

    wash = appliance_df[appliance_df["appliance_id"] == "A08"]
    wash_monthly = 0.0
    if not wash.empty:
        wash_daily = float(wash["total_kwh"].iloc[0]) / days
        wash_monthly = (
            wash_daily * config.PROJECTION_DAYS
            * assumptions["washing_energy_reduction_fraction"]
        )
    recs.append(
        _enrich(RECOMMENDATION_LIBRARY[4], wash_monthly, tariff, emission_factor,
                "Washing machine", 5)
    )

    ac = appliance_df[appliance_df["appliance_id"] == "A09"]
    ac_monthly = 0.0
    if not ac.empty:
        ac_daily = float(ac["total_kwh"].iloc[0]) / days
        ac_monthly = (
            ac_daily * config.PROJECTION_DAYS
            * assumptions["ac_energy_reduction_fraction"]
        )
    recs.append(
        _enrich(RECOMMENDATION_LIBRARY[5], ac_monthly, tariff, emission_factor,
                "Air conditioner", 6)
    )

    recs = [r for r in recs if r["monthly_kwh"] > 0.001]
    recs.sort(key=lambda r: r["monthly_kwh"], reverse=True)
    for rank, rec in enumerate(recs, start=1):
        rec["rank"] = rank
    return recs


def recommendations_table(recs: list[dict]) -> pd.DataFrame:
    """Format recommendations for display and download."""
    rows = []
    for rec in recs:
        rows.append(
            {
                "Priority": rec["rank"],
                "Action": rec["title"],
                "Category": rec["category"],
                "Effort": rec["effort"],
                "Affected appliances": rec["affected_appliances"],
                "Saving (kWh/month)": rec["monthly_kwh"],
                "Saving (Rs./month)": rec["monthly_inr"],
                "CO2 avoided (kg/month)": rec["monthly_co2_kg"],
                "Annual saving (Rs.)": rec["annual_inr"],
                "Assumption": rec["assumption"],
            }
        )
    return pd.DataFrame(rows)


def combined_savings(
    recs: list[dict],
    selected_ids: list[str],
    monthly_baseline_kwh: float,
) -> dict[str, float]:
    """Aggregate the impact of the selected actions."""
    selected = [r for r in recs if r["id"] in set(selected_ids)]
    monthly_kwh = sum(r["monthly_kwh"] for r in selected)
    monthly_inr = sum(r["monthly_inr"] for r in selected)
    monthly_co2 = sum(r["monthly_co2_kg"] for r in selected)
    return {
        "actions": len(selected),
        "monthly_kwh": round(monthly_kwh, 3),
        "monthly_inr": round(monthly_inr, 2),
        "monthly_co2_kg": round(monthly_co2, 2),
        "annual_kwh": round(monthly_kwh / 30.0 * 365.0, 3),
        "annual_inr": round(monthly_inr / 30.0 * 365.0, 2),
        "annual_co2_kg": round(monthly_co2 / 30.0 * 365.0, 2),
        "pct_of_monthly": round(
            100 * monthly_kwh / monthly_baseline_kwh, 2
        ) if monthly_baseline_kwh > 0 else 0.0,
    }


def household_insights(
    appliance_df: pd.DataFrame,
    daily_df: pd.DataFrame,
    tariff: float,
    emission_factor: float,
) -> list[dict[str, str]]:
    """Short, data-backed insights for the home dashboard."""
    insights: list[dict[str, str]] = []
    if not appliance_df.empty:
        top = appliance_df.iloc[0]
        insights.append(
            {
                "title": f"{top['appliance_name']} is the largest consumer",
                "body": (
                    f"It accounts for {top['share_pct']:.1f}% of observed electricity "
                    f"({top['total_kwh']:.1f} kWh over {len(daily_df)} days), costing about "
                    f"Rs. {top['projected_monthly_kwh'] * tariff:,.0f} per month."
                ),
                "tag": "Consumption hotspot",
            }
        )
    if not appliance_df.empty and "standby_kwh" in appliance_df:
        standby = float(appliance_df["standby_kwh"].sum())
        total = float(appliance_df["total_kwh"].sum())
        if total > 0:
            share = standby / total * 100
            insights.append(
                {
                    "title": f"Standby power is {share:.1f}% of consumption",
                    "body": (
                        f"Idle appliances draw {standby:.1f} kWh over the study window, or about "
                        f"{standby / max(len(daily_df), 1) * 30:.1f} kWh per month. Plug-point "
                        "switching is a zero-cost intervention."
                    ),
                    "tag": "Hidden waste",
                }
            )
    if len(daily_df) >= 7:
        weekend = daily_df[daily_df["is_weekend"]]["total_kwh"]
        weekday = daily_df[~daily_df["is_weekend"]]["total_kwh"]
        if not weekend.empty and not weekday.empty:
            diff = (weekend.mean() - weekday.mean()) / weekday.mean() * 100
            insights.append(
                {
                    "title": f"Weekends use {abs(diff):.1f}% {'more' if diff >= 0 else 'less'} energy",
                    "body": (
                        f"Average weekend use is {weekend.mean():.2f} kWh/day versus "
                        f"{weekday.mean():.2f} kWh/day on weekdays. Shifting high-power tasks "
                        "to off-peak hours can reduce peak demand."
                    ),
                    "tag": "Usage pattern",
                }
            )
    if not daily_df.empty:
        peak = daily_df.loc[daily_df["total_kwh"].idxmax()]
        insights.append(
            {
                "title": f"Peak day: {peak['date'].strftime('%d %b %Y')}",
                "body": (
                    f"Consumption reached {peak['total_kwh']:.2f} kWh, about "
                    f"{peak['total_kwh'] * tariff:,.0f} rupees at the selected tariff and "
                    f"{peak['total_kwh'] * emission_factor:.1f} kg CO2e."
                ),
                "tag": "Peak demand",
            }
        )
    return insights
