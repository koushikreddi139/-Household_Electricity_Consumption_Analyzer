"""
Generate the report/presentation figures from the actual project dataset.

Run from the project root:
    python scripts/generate_visualizations.py

Outputs (200 dpi PNG):
    visualizations/daily_consumption.png
    visualizations/appliance_consumption.png
    visualizations/consumption_distribution.png
    visualizations/consumption_prediction.png
    visualizations/weekly_consumption.png
    visualizations/daily_cost.png
    visualizations/co2_emissions.png
    visualizations/operating_vs_standby.png
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import config  # noqa: E402
from src.cost_analysis import cost_summary  # noqa: E402
from src.data_processing import (  # noqa: E402
    appliance_summary,
    clean_energy_data,
    daily_summary,
    load_energy_csv,
    weekly_summary,
)
from src.prediction import fit_and_forecast  # noqa: E402
from src.sustainability import emissions_by_appliance  # noqa: E402

OUT = ROOT / "visualizations"
OUT.mkdir(parents=True, exist_ok=True)

P = config.PALETTE
COLORS = config.CHART_COLORS
TARIFF = config.DEFAULT_TARIFF_INR_PER_KWH
EF = config.DEFAULT_EMISSION_FACTOR

plt.rcParams.update(
    {
        "font.family": "Segoe UI",
        "font.size": 10,
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.titlecolor": P["ink"],
        "axes.labelsize": 10,
        "axes.labelcolor": "#475569",
        "axes.edgecolor": "#D8E3DE",
        "axes.linewidth": 0.8,
        "axes.grid": True,
        "axes.axisbelow": True,
        "grid.color": "#E6ECEA",
        "grid.linewidth": 0.8,
        "xtick.color": "#64748B",
        "ytick.color": "#64748B",
        "legend.frameon": False,
        "legend.fontsize": 9,
        "figure.facecolor": "white",
        "savefig.facecolor": "white",
        "savefig.bbox": "tight",
        "savefig.dpi": 200,
    }
)


def finish(ax, title, xlabel, ylabel):
    ax.set_title(title, loc="left", pad=14)
    ax.set_xlabel(xlabel, labelpad=8)
    ax.set_ylabel(ylabel, labelpad=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="x", visible=False)


def save(fig, name):
    path = OUT / name
    fig.savefig(path, dpi=200)
    plt.close(fig)
    print(f"  wrote {path.name}")


def main():
    clean, report = clean_energy_data(load_energy_csv(config.RAW_DATA_PATH))
    db = pd.read_csv(config.APPLIANCE_DB_PATH)
    daily = daily_summary(clean)
    weekly = weekly_summary(daily)
    apps = appliance_summary(clean, db)
    apps_em = emissions_by_appliance(apps, EF)
    stats = cost_summary(daily, TARIFF)
    pred = fit_and_forecast(daily, horizon=30)

    # 1. Daily consumption -------------------------------------------------
    fig, ax = plt.subplots(figsize=(11.2, 5.1))
    ax.plot(daily["date"], daily["total_kwh"], color=P["primary"], linewidth=2.4,
            marker="o", markersize=4.5, markerfacecolor="white", markeredgewidth=1.4,
            label="Daily consumption", zorder=3)
    ax.fill_between(daily["date"], daily["total_kwh"], color=P["primary"], alpha=0.09, zorder=1)
    moving = daily["total_kwh"].rolling(7, min_periods=3).mean()
    ax.plot(daily["date"], moving, color=P["amber"], linewidth=1.8, linestyle="--",
            label="7-day moving average", zorder=4)
    weekends = daily[daily["is_weekend"]]
    ax.scatter(weekends["date"], weekends["total_kwh"], s=120, color=P["amber"],
               alpha=0.18, zorder=2, label="Weekend day")
    peak = daily.loc[daily["total_kwh"].idxmax()]
    ax.annotate(f"Peak {peak['total_kwh']:.1f} kWh\n{peak['date']:%d %b}",
                xy=(peak["date"], peak["total_kwh"]),
                xytext=(-78, -38), textcoords="offset points",
                fontsize=9, color=P["red"],
                arrowprops=dict(arrowstyle="-|>", color=P["red"], lw=1.0,
                                connectionstyle="arc3,rad=-0.2"),
                bbox=dict(boxstyle="round,pad=0.35", fc="#FFF7F7", ec="#FECACA", lw=0.8))
    ax.xaxis.set_major_locator(mdates.DayLocator(interval=3))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.set_ylim(0, daily["total_kwh"].max() * 1.22)
    finish(ax, "Daily household electricity consumption", "Date", "Energy consumption (kWh/day)")
    ax.legend(loc="upper left", ncol=3)
    fig.text(0.01, -0.02,
             f"21-day Project Dataset · mean {stats['avg_daily_kwh']:.2f} kWh/day · "
             f"total {stats['total_kwh']:.1f} kWh",
             fontsize=8.5, color="#64748B")
    save(fig, "daily_consumption.png")

    # 2. Appliance consumption --------------------------------------------
    fig, ax = plt.subplots(figsize=(11.2, 6.0))
    data = apps.sort_values("total_kwh", ascending=True)
    ax.barh(data["appliance_name"], data["operating_kwh"], color=P["primary"],
            label="Operating energy", height=0.62)
    ax.barh(data["appliance_name"], data["standby_kwh"], left=data["operating_kwh"],
            color=P["amber"], label="Standby energy", height=0.62)
    for y, (_, row) in enumerate(data.iterrows()):
        ax.text(row["total_kwh"] + 2.0, y, f"{row['total_kwh']:.1f} kWh · {row['share_pct']:.0f}%",
                va="center", fontsize=8.4, color="#475569")
    ax.set_xlim(0, data["total_kwh"].max() * 1.28)
    finish(ax, "Appliance-wise energy consumption (21-day total)", "Energy consumption (kWh)", "Appliance")
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x", visible=True)
    ax.legend(loc="lower right")
    fig.text(0.01, -0.02,
             "Total includes both operating and standby energy. The geyser and refrigerator dominate this winter profile.",
             fontsize=8.5, color="#64748B")
    save(fig, "appliance_consumption.png")

    # 3. Distribution donut ------------------------------------------------
    fig, ax = plt.subplots(figsize=(8.6, 6.1))
    data = apps.sort_values("total_kwh", ascending=False)
    top = data.head(7).copy()
    other = data.iloc[7:]
    if not other.empty:
        top = pd.concat([
            top,
            pd.DataFrame([{"appliance_name": f"Other ({len(other)} appliances)",
                           "total_kwh": other["total_kwh"].sum(),
                           "share_pct": other["share_pct"].sum()}]),
        ], ignore_index=True)
    labels = [f"{r['appliance_name']} ({r['share_pct']:.1f}%)" for _, r in top.iterrows()]
    wedges, _ = ax.pie(top["total_kwh"], colors=COLORS[: len(top)], startangle=90,
                       counterclock=False, wedgeprops=dict(width=0.36, edgecolor="white", linewidth=2))
    ax.text(0, 0.08, f"{apps['total_kwh'].sum():,.0f} kWh", ha="center", va="center",
            fontsize=20, fontweight="bold", color=P["ink"])
    ax.text(0, -0.13, "21-day total", ha="center", va="center", fontsize=9, color="#64748B")
    ax.legend(wedges, labels, loc="center left", bbox_to_anchor=(1.0, 0.5), fontsize=8.8)
    ax.set_title("Consumption distribution by appliance", loc="left", pad=14)
    ax.set_aspect("equal")
    fig.text(0.01, 0.02,
             "Share of total electricity consumption over the 21-day observation window.",
             fontsize=8.5, color="#64748B")
    save(fig, "consumption_distribution.png")

    # 4. Prediction --------------------------------------------------------
    fig, ax = plt.subplots(figsize=(11.4, 5.5))
    fit = pred["fit_frame"]
    train = pred["train_frame"]
    test = pred["test_frame"]
    fc = pred["forecast_frame"]
    ax.fill_between(fc["date"], fc["lower_kwh"], fc["upper_kwh"], color=P["emerald"],
                    alpha=0.13, label="Approx. 95% interval", linewidth=0)
    ax.plot(fit["date"], fit["actual_kwh"], color=P["ink"], linewidth=2.0,
            marker="o", markersize=3.2, label="Actual", zorder=4)
    ax.plot(train["date"], train["fitted_kwh"], color=P["blue"], linewidth=1.6,
            linestyle=":", label="Model fit (training)", zorder=3)
    ax.plot(test["date"], test["predicted_kwh"], color=P["amber"], linewidth=1.8,
            linestyle="--", marker="D", markersize=4.5, label="Holdout prediction", zorder=5)
    ax.plot(fc["date"], fc["predicted_kwh"], color=P["emerald"], linewidth=2.2,
            label="30-day forecast", zorder=5)
    ax.axvline(pred["last_observed_date"], color="#94A3B8", linestyle="--", linewidth=1.1)
    ax.text(pred["last_observed_date"], ax.get_ylim()[1] * 0.96,
            " Forecast start", fontsize=8.5, color="#64748B", va="top")
    ax.axvspan(fc["date"].iloc[0], fc["date"].iloc[-1], color=P["emerald"], alpha=0.035)
    ax.xaxis.set_major_locator(mdates.DayLocator(interval=7))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.set_ylim(0, max(fc["upper_kwh"].max(), fit["actual_kwh"].max()) * 1.15)
    finish(ax, "Actual versus predicted daily electricity consumption", "Date", "Energy consumption (kWh/day)")
    ax.legend(loc="upper left", ncol=3, fontsize=8.6)
    m = pred["metrics"]
    fig.text(0.01, -0.02,
             f"Ridge regression · holdout MAE {m['mae']:.2f} kWh/day · RMSE {m['rmse']:.2f} · "
             f"MAPE {m['mape']:.1f}% · R² {m['r2']:.2f} (Project Dataset; analysis pipeline)",
             fontsize=8.5, color="#64748B")
    save(fig, "consumption_prediction.png")

    # 5. Weekly comparison -------------------------------------------------
    fig, ax = plt.subplots(figsize=(9.6, 4.9))
    labels = [f"Week {int(r['week_number'])}\n{r['start_date']:%d %b}–{r['end_date']:%d %b}"
              for _, r in weekly.iterrows()]
    bars = ax.bar(labels, weekly["total_kwh"], color=[P["primary"], P["emerald"], P["mint"]],
                  width=0.55)
    for bar, (_, row) in zip(bars, weekly.iterrows()):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1.2,
                f"{row['total_kwh']:.1f} kWh\n({row['avg_daily_kwh']:.2f}/day)",
                ha="center", fontsize=8.8, color="#334155")
    ax.set_ylim(0, weekly["total_kwh"].max() * 1.22)
    finish(ax, "Weekly electricity consumption comparison", "Study week", "Energy consumption (kWh/week)")
    ax.grid(axis="x", visible=False)
    save(fig, "weekly_consumption.png")

    # 6. Daily cost --------------------------------------------------------
    fig, ax = plt.subplots(figsize=(11.2, 4.6))
    ax.plot(daily["date"], daily["total_kwh"] * TARIFF, color=P["emerald"], linewidth=2.2,
            marker="o", markersize=3.8)
    ax.fill_between(daily["date"], daily["total_kwh"] * TARIFF, color=P["emerald"], alpha=0.12)
    avg = daily["total_kwh"].mean() * TARIFF
    ax.axhline(avg, color="#64748B", linestyle=":", linewidth=1.2)
    ax.text(daily["date"].iloc[0], avg + 2, f"Average Rs. {avg:.0f}/day", fontsize=8.5, color="#64748B")
    ax.xaxis.set_major_locator(mdates.DayLocator(interval=3))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.set_ylim(0, (daily["total_kwh"] * TARIFF).max() * 1.18)
    finish(ax, f"Daily electricity cost at Rs. {TARIFF:.2f}/kWh", "Date", "Cost (Rs./day)")
    save(fig, "daily_cost.png")

    # 7. CO2 by appliance --------------------------------------------------
    fig, ax = plt.subplots(figsize=(11.2, 6.0))
    data = apps_em.sort_values("co2_monthly_kg", ascending=True)
    colors = [P["mint"] if v < data["co2_monthly_kg"].median() else P["primary"]
              for v in data["co2_monthly_kg"]]
    ax.barh(data["appliance_name"], data["co2_monthly_kg"], color=colors, height=0.62)
    for y, (_, row) in enumerate(data.iterrows()):
        ax.text(row["co2_monthly_kg"] + 0.9, y, f"{row['co2_monthly_kg']:.1f} kg",
                va="center", fontsize=8.4, color="#475569")
    ax.set_xlim(0, data["co2_monthly_kg"].max() * 1.22)
    finish(ax, "Estimated monthly CO2e contribution by appliance",
           "Emissions (kg CO2e/month)", "Appliance")
    ax.grid(axis="y", visible=False)
    fig.text(0.01, -0.02,
             f"Grid emission factor {EF:.2f} kg CO2e/kWh (illustrative, editable assumption).",
             fontsize=8.5, color="#64748B")
    save(fig, "co2_emissions.png")

    # 8. Operating vs standby hours ---------------------------------------
    fig, ax = plt.subplots(figsize=(11.2, 6.0))
    data = apps.sort_values("total_kwh", ascending=True)
    y = np.arange(len(data))
    ax.barh(y + 0.18, data["avg_operating_hours"], height=0.34, color=P["primary"],
            label="Operating hours")
    ax.barh(y - 0.18, data["avg_standby_hours"], height=0.34, color=P["amber"],
            label="Standby hours")
    ax.set_yticks(y)
    ax.set_yticklabels(data["appliance_name"])
    ax.set_xlim(0, 25.5)
    finish(ax, "Daily operating versus standby hours", "Hours per day (h)", "Appliance")
    ax.legend(loc="lower right")
    ax.grid(axis="y", visible=False)
    save(fig, "operating_vs_standby.png")

    print("Visualization generation complete.")


if __name__ == "__main__":
    main()
