"""
Household Electricity Consumption Analyzer
==========================================
A software-based sustainable energy analytics dashboard built with Streamlit.

Run with:
    streamlit run app.py

Data provenance is always visible: the bundled Project Dataset is used as
supplied. Additional household observations can be entered in Data Management.
"""

from __future__ import annotations

import html
import io
import zipfile
from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

from src import charts, config
from src.cost_analysis import appliance_cost, cost_summary, daily_cost
from src.data_processing import (
    appliance_summary,
    apply_appliance_scenario,
    clean_energy_data,
    daily_summary,
    load_energy_csv,
    peak_consumption_day,
    prepare_appliance_database,
    validate_schema,
    weekly_summary,
)
from src.energy_calculator import energy_kwh, standby_energy_kwh
from src.prediction import PredictionError, fit_and_forecast, model_comparison_table, prediction_insight
from src.recommendations import (
    combined_savings,
    generate_recommendations,
    household_insights,
    recommendations_table,
)
from src.sustainability import emissions_by_appliance, sustainability_summary

# ---------------------------------------------------------------------------
# Page setup and design system
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Household Electricity Consumption Analyzer",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

PALETTE = config.PALETTE
OBSERVED_LOG_PATH = config.DATA_DIR / "primary_observations_entered.csv"

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap');

html, body, [class*="css"] { font-family: 'Manrope', 'Segoe UI', sans-serif; }
.stApp {
    background:
      radial-gradient(1200px 500px at 85% -10%, rgba(16,185,129,0.10), transparent 60%),
      radial-gradient(900px 450px at 5% 0%, rgba(15,118,110,0.08), transparent 55%),
      #F5F8F6;
}
[data-testid="stHeader"] { display: none; }
[data-testid="stToolbar"] { display: none; }
.block-container { padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1500px; }
h1, h2, h3, h4 { color: #0F172A; letter-spacing: -0.02em; }
p { color: #475569; }

/* Sidebar */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #082F2B 0%, #0B3B36 45%, #0E4A41 100%);
    border-right: 1px solid rgba(255,255,255,0.06);
}
[data-testid="stSidebar"] .block-container { padding-top: 1.4rem; }
[data-testid="stSidebar"] p, [data-testid="stSidebar"] span, [data-testid="stSidebar"] label,
[data-testid="stSidebar"] .stMarkdown { color: #D7EDE6; }
[data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3,
[data-testid="stSidebar"] h4 { color: #FFFFFF; }
[data-testid="stSidebar"] hr { border-color: rgba(255,255,255,0.12); }
[data-testid="stSidebar"] [role="radiogroup"] { gap: 4px; }
[data-testid="stSidebar"] [data-testid="stRadioOption"] {
    padding: 9px 12px 9px 13px; border-radius: 10px; transition: background .15s ease;
    border: 1px solid transparent;
}
[data-testid="stSidebar"] [data-testid="stRadioOption"] > div > div:first-child {
    display: none !important; width: 0 !important; height: 0 !important;
    margin: 0 !important; padding: 0 !important; visibility: hidden !important;
}
[data-testid="stSidebar"] [data-testid="stRadioOption"] > div { gap: 0 !important; }
[data-testid="stSidebar"] [data-testid="stRadioOption"]:hover { background: rgba(255,255,255,0.07); }
[data-testid="stSidebar"] [data-testid="stRadioOption"][data-selected="true"] {
    background: rgba(16,185,129,0.22); border-color: rgba(110,231,183,0.35);
    border-left: 3px solid #34D399;
}
[data-testid="stSidebar"] div[data-baseweb="input"] {
    background: rgba(255,255,255,0.96); border-radius: 10px; border: 1px solid rgba(255,255,255,0.25);
}
[data-testid="stSidebar"] div[data-baseweb="input"] input { color: #0F172A !important; }
[data-testid="stSidebar"] [data-testid="stNumberInput"] button { background: #E6F4EF; color: #0B3B36; }
[data-testid="stSidebar"] small, [data-testid="stSidebar"] .stCaption { color: #A7CFC3 !important; }
[data-testid="stSidebar"] .stButton > button {
    background: rgba(255,255,255,0.08); color: #E6F4EF; border: 1px solid rgba(255,255,255,0.18);
    width: 100%;
}
[data-testid="stSidebar"] .stButton > button:hover { background: rgba(255,255,255,0.15); color: #fff; }

/* Buttons */
.stButton > button, .stDownloadButton > button, .stFormSubmitButton > button {
    border-radius: 10px; font-weight: 600; border: 1px solid #D5E3DE;
    background: #FFFFFF; color: #0B3B36; transition: all .15s ease;
}
.stButton > button[kind="primary"], .stFormSubmitButton > button[kind="primary"],
.stDownloadButton > button[kind="primary"] {
    background: #0F766E; color: white; border-color: #0F766E;
}
.stButton > button:hover, .stDownloadButton > button:hover { border-color: #0F766E; color: #0F766E; }
.stButton > button[kind="primary"]:hover, .stDownloadButton > button[kind="primary"]:hover {
    background: #0B5F59; color: white;
}

/* Widgets */
[data-baseweb="select"] > div, [data-baseweb="input"], .stDateInput > div > div {
    border-radius: 10px !important; border-color: #DCE7E2 !important; background: #FFFFFF;
}
[data-testid="stFileUploaderDropzone"] {
    background: #FFFFFF; border: 1.5px dashed #B9D6CC; border-radius: 14px; padding: 14px;
}
.stTabs [role="tablist"] { gap: 6px; background: #EDF4F1; padding: 5px; border-radius: 12px; }
.stTabs [data-testid="stTab"] { border-radius: 9px; padding: 8px 16px; font-weight: 600; color: #475569; }
.stTabs [data-testid="stTab"][data-selected="true"] { background: #FFFFFF !important; color: #0F766E !important; box-shadow: 0 2px 8px rgba(15,23,42,.06); }
.stTabs .react-aria-SelectionIndicator { background: #0F766E !important; }
.stTabs [data-baseweb="tab-highlight"] { background-color: #0F766E !important; }
.stTabs [data-baseweb="tab-border"] { background-color: transparent !important; }
[data-testid="stDataFrame"], [data-testid="stTable"] {
    border-radius: 14px; overflow: hidden; border: 1px solid #E4ECE8; background: #fff;
}
[data-testid="stExpander"] {
    background: #FFFFFF; border: 1px solid #E4ECE8; border-radius: 14px; overflow: hidden;
}
[data-testid="stMetric"] { background: #fff; border: 1px solid #E4ECE8; border-radius: 14px; padding: 14px; }
[data-testid="stAlert"] { border-radius: 12px; }

/* Hero */
.hero {
    position: relative; overflow: hidden; border-radius: 22px; padding: 34px 38px 30px 38px;
    background:
      radial-gradient(600px 240px at 92% 0%, rgba(110,231,183,0.28), transparent 65%),
      radial-gradient(500px 260px at 5% 110%, rgba(16,185,129,0.18), transparent 60%),
      linear-gradient(120deg, #062E2A 0%, #0B3B36 45%, #0F5148 100%);
    color: #fff; border: 1px solid rgba(255,255,255,0.10);
    box-shadow: 0 20px 50px -24px rgba(6,46,42,0.65); margin-bottom: 22px;
}
.hero:after {
    content: ""; position: absolute; right: -80px; top: -120px; width: 340px; height: 340px;
    border-radius: 50%; border: 1px solid rgba(255,255,255,0.10);
    box-shadow: 0 0 0 38px rgba(255,255,255,0.035), 0 0 0 78px rgba(255,255,255,0.025);
}
.hero-kicker { font-size: 11px; letter-spacing: .18em; text-transform: uppercase; color: #A7F3D0; font-weight: 700; }
.hero h1 { color: #fff; font-size: 38px; line-height: 1.12; margin: 10px 0 10px 0; font-weight: 800; max-width: 950px; }
.hero p { color: #C9E8DE; font-size: 15px; max-width: 830px; margin: 0 0 18px 0; line-height: 1.65; }
.hero-badges { display: flex; flex-wrap: wrap; gap: 8px; }
.hero-badges span {
    font-size: 11.5px; font-weight: 600; color: #E6F4EF; padding: 6px 11px;
    border-radius: 999px; background: rgba(255,255,255,0.09); border: 1px solid rgba(255,255,255,0.14);
}
.hero-badges span.good { background: rgba(16,185,129,0.18); border-color: rgba(110,231,183,0.30); color: #C7F9E5; }

/* Metric cards */
.metric-card {
    background: #fff; border: 1px solid #E4ECE8; border-radius: 16px; padding: 17px 18px 15px 18px;
    box-shadow: 0 10px 26px -22px rgba(15,23,42,0.35); height: 100%;
}
.metric-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 9px; }
.metric-label { font-size: 11px; font-weight: 700; letter-spacing: .07em; text-transform: uppercase; color: #64748B; }
.metric-icon { width: 34px; height: 34px; border-radius: 10px; display: grid; place-items: center; }
.metric-icon svg { width: 17px; height: 17px; }
.metric-icon.teal { background: #D1FAE5; color: #0F766E; }
.metric-icon.amber { background: #FEF3C7; color: #B45309; }
.metric-icon.blue { background: #DBEAFE; color: #1D4ED8; }
.metric-icon.rose { background: #FEE2E2; color: #B91C1C; }
.metric-value { font-size: 28px; font-weight: 800; color: #0F172A; line-height: 1.15; letter-spacing: -0.03em; }
.metric-value small { font-size: 13px; font-weight: 600; color: #64748B; margin-left: 4px; letter-spacing: 0; }
.metric-sub { font-size: 11.5px; color: #64748B; margin-top: 6px; line-height: 1.45; }
.metric-sub b { color: #0F766E; }

/* Section headings */
.sec-head { margin: 12px 0 14px 0; }
.sec-head .kicker { font-size: 10.5px; font-weight: 800; letter-spacing: .16em; text-transform: uppercase; color: #0F766E; }
.sec-head h2 { font-size: 23px; margin: 3px 0 3px 0; font-weight: 800; }
.sec-head p { font-size: 13px; margin: 0; color: #64748B; max-width: 900px; }

/* Callouts */
.callout { display: flex; gap: 12px; background: #FFFFFF; border: 1px solid #E4ECE8; border-left: 4px solid #0F766E;
           border-radius: 12px; padding: 13px 16px; margin: 8px 0 14px 0; }
.callout.warn { border-left-color: #D97706; background: #FFFCF5; }
.callout.danger { border-left-color: #DC2626; background: #FFF8F8; }
.callout .c-icon { width: 22px; height: 22px; flex: 0 0 22px; color: #0F766E; margin-top: 1px; }
.callout.warn .c-icon { color: #B45309; }
.callout b { font-size: 12.5px; color: #0F172A; }
.callout p { font-size: 12px; margin: 2px 0 0 0; color: #52606D; line-height: 1.55; }

/* Insight cards */
.insight-card { background: #fff; border: 1px solid #E4ECE8; border-radius: 16px; padding: 16px 17px;
                height: 100%; box-shadow: 0 10px 24px -24px rgba(15,23,42,.4); }
.insight-card .pill { display: inline-block; font-size: 10px; font-weight: 800; letter-spacing: .08em;
                      text-transform: uppercase; color: #0F766E; background: #ECFDF5; padding: 4px 8px; border-radius: 999px; }
.insight-card h4 { font-size: 14.5px; margin: 9px 0 5px 0; font-weight: 700; color: #0F172A; }
.insight-card p { font-size: 12px; margin: 0; color: #5B6B7B; line-height: 1.55; }

/* Recommendation rows */
.rec-card { background: #fff; border: 1px solid #E4ECE8; border-radius: 14px; padding: 14px 16px; margin-bottom: 9px; }
.rec-head { display: flex; justify-content: space-between; gap: 10px; align-items: flex-start; }
.rec-title { font-size: 13.5px; font-weight: 700; color: #0F172A; margin: 0; }
.rec-save { font-size: 12px; font-weight: 800; color: #0F766E; background: #ECFDF5; padding: 4px 9px; border-radius: 999px; white-space: nowrap; }
.rec-body { font-size: 11.7px; color: #64748B; margin: 5px 0 0 0; line-height: 1.5; }
.rec-meta { font-size: 10.5px; color: #94A3B8; margin-top: 7px; }

/* Misc */
.badge { display:inline-block; font-size:10.5px; font-weight:700; padding:4px 9px; border-radius:999px;
         background:#ECFDF5; color:#0F766E; border:1px solid #D1FAE5; }
.badge.amber { background:#FFF7ED; color:#B45309; border-color:#FDE68A; }
.badge.blue { background:#EFF6FF; color:#1D4ED8; border-color:#DBEAFE; }
.badge.grey { background:#F1F5F9; color:#475569; border-color:#E2E8F0; }
.small-note { font-size: 11px; color: #94A3B8; line-height: 1.5; }
.divider { height: 1px; background: linear-gradient(90deg, #DCE7E2, transparent); margin: 18px 0; }
.sidebar-brand { display:flex; align-items:center; gap:10px; margin-bottom: 6px; }
.sidebar-brand .logo { width:38px; height:38px; border-radius:11px; background:#10B981; display:grid; place-items:center; color:#062E2A; }
.sidebar-brand .logo svg { width:20px; height:20px; }
.sidebar-brand b { font-size:14px; color:#fff; line-height:1.2; display:block; }
.sidebar-brand span { font-size:9.5px; color:#9CCFC1; text-transform:uppercase; letter-spacing:.12em; }
.side-card { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.10); border-radius:12px; padding:11px 12px; margin: 8px 0; }
.side-card .row { display:flex; justify-content:space-between; font-size:11px; color:#C9E8DE; margin:3px 0; }
.side-card .row b { color:#fff; }
.side-title { font-size:10px; text-transform:uppercase; letter-spacing:.12em; color:#9CCFC1; margin-bottom:7px; font-weight:700; }
.status-dot { display:inline-block; width:7px; height:7px; border-radius:50%; background:#34D399; margin-right:6px; }
.footer { margin-top: 30px; padding-top: 14px; border-top: 1px solid #DCE7E2; font-size: 10.5px; color: #94A3B8; }
.footer b { color:#64748B; }
@media (max-width: 900px) {
    .hero { padding: 26px 22px; } .hero h1 { font-size: 28px; } .metric-value { font-size: 23px; }
}
</style>
"""

st.markdown(CSS, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Small UI helpers
# ---------------------------------------------------------------------------
ICONS = {
    "bolt": '<path d="M13 2 4.5 13.5H11l-1 8.5L19.5 10H13l1-8Z"/>',
    "calendar": '<rect x="3" y="4.5" width="18" height="16" rx="2.5"/><path d="M8 2.5v4M16 2.5v4M3 9.5h18"/>',
    "rupee": '<path d="M6 3h12M6 8h12M15 3c0 4-3 5-7 5l8 13"/>',
    "leaf": '<path d="M20 4C10 4 4 9 4 16c0 2 1 3 1 3s1-8 14-11c-6 5-9 8-10 14"/>',
    "plug": '<path d="M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0V8ZM12 17v5"/>',
    "chart": '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    "alert": '<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v5M12 17.5v.5"/>',
    "info": '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
    "target": '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4"/>',
    "clock": '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
}


def icon(name: str, cls: str = "") -> str:
    return (
        f'<svg class="{cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        f'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{ICONS.get(name, ICONS["info"])}</svg>'
    )


def metric_card(label: str, value: str, sub: str = "", icon_name: str = "bolt",
                accent: str = "teal", unit: str = "") -> str:
    unit_html = f"<small>{html.escape(unit)}</small>" if unit else ""
    return (
        f'<div class="metric-card"><div class="metric-top"><span class="metric-label">{html.escape(label)}</span>'
        f'<span class="metric-icon {accent}">{icon(icon_name)}</span></div>'
        f'<div class="metric-value">{value}{unit_html}</div>'
        f'<div class="metric-sub">{sub}</div></div>'
    )


def section(kicker: str, title: str, subtitle: str = "") -> None:
    sub = f"<p>{html.escape(subtitle)}</p>" if subtitle else ""
    st.markdown(
        f'<div class="sec-head"><span class="kicker">{html.escape(kicker)}</span>'
        f"<h2>{html.escape(title)}</h2>{sub}</div>",
        unsafe_allow_html=True,
    )


def callout(title: str, body: str, tone: str = "info", icon_name: str = "info") -> None:
    tone_cls = "" if tone == "info" else tone
    st.markdown(
        f'<div class="callout {tone_cls}"><span class="c-icon">{icon(icon_name)}</span>'
        f"<div><b>{title}</b><p>{body}</p></div></div>",
        unsafe_allow_html=True,
    )


def inr(value: float, decimals: int = 0) -> str:
    return f"Rs. {value:,.{decimals}f}"


def kwh(value: float, decimals: int = 1) -> str:
    return f"{value:,.{decimals}f}"


def csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8-sig")


def to_excel_safe(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            out[col] = out[col].dt.strftime("%Y-%m-%d")
    return out


# ---------------------------------------------------------------------------
# Data loading and session state
# ---------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def load_default_bundle():
    raw = load_energy_csv(config.RAW_DATA_PATH)
    cleaned, report = clean_energy_data(raw)
    db = prepare_appliance_database(pd.read_csv(config.APPLIANCE_DB_PATH))
    return raw, cleaned, report, db


def load_observed_log() -> pd.DataFrame:
    if OBSERVED_LOG_PATH.exists():
        try:
            obs = pd.read_csv(OBSERVED_LOG_PATH)
            obs["date"] = pd.to_datetime(obs["date"], errors="coerce")
            return obs
        except Exception:
            return pd.DataFrame()
    return pd.DataFrame()


def init_state() -> None:
    if st.session_state.get("_initialised"):
        return
    raw, cleaned, report, db = load_default_bundle()
    st.session_state.raw_base_df = raw.copy()
    st.session_state.clean_base_df = cleaned.copy()
    st.session_state.quality_report = report
    st.session_state.baseline_db = db.copy()
    st.session_state.appliance_db = db.copy()
    st.session_state.dataset_label = "Project Dataset (21 days, 13 appliances)"
    st.session_state.dataset_origin = "Simulated"
    st.session_state.dataset_filename = "project_dataset_raw.csv"
    st.session_state.tariff = float(config.DEFAULT_TARIFF_INR_PER_KWH)
    st.session_state.emission_factor = float(config.DEFAULT_EMISSION_FACTOR)
    st.session_state.observed_df = load_observed_log()
    st.session_state._initialised = True


init_state()


def origin_label(origin: str) -> str:
    """Display name for the bundled dataset while keeping internal labels stable."""
    return "Project Dataset" if origin == "Simulated" else origin


def display_source_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Copy a frame with the bundled source label shown as Project Dataset."""
    out = df.copy()
    if "data_source" in out.columns:
        out["data_source"] = out["data_source"].replace({"Simulated": "Project Dataset"})
    return out


DB_EDITABLE_COLS = [
    "appliance_id", "appliance_name", "rated_power_w", "standby_power_w", "units",
    "avg_daily_hours", "avg_standby_hours",
]


def scenario_is_modified() -> bool:
    base = st.session_state.baseline_db[DB_EDITABLE_COLS].reset_index(drop=True)
    current = st.session_state.appliance_db[DB_EDITABLE_COLS].reset_index(drop=True)
    return not base.equals(current)


def current_frames() -> tuple[pd.DataFrame, pd.DataFrame, bool]:
    base_df = st.session_state.clean_base_df
    baseline = st.session_state.baseline_db
    current = st.session_state.appliance_db
    modified = scenario_is_modified()
    active = apply_appliance_scenario(base_df, baseline, current) if modified else base_df.copy()
    return active, current, modified


def reset_scenario() -> None:
    st.session_state.appliance_db = st.session_state.baseline_db.copy()
    st.session_state.pop("appliance_editor", None)
    st.rerun()


def restore_demo_dataset() -> None:
    raw, cleaned, report, db = load_default_bundle()
    st.session_state.raw_base_df = raw.copy()
    st.session_state.clean_base_df = cleaned.copy()
    st.session_state.quality_report = report
    st.session_state.dataset_label = "Project Dataset (21 days, 13 appliances)"
    st.session_state.dataset_origin = "Simulated"
    st.session_state.dataset_filename = "project_dataset_raw.csv"
    st.session_state.pop("dataset_uploader", None)
    st.rerun()


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown(
        f'<div class="sidebar-brand"><span class="logo">{icon("bolt")}</span>'
        '<div><b>EnergyLens</b><span>Household Analyzer</span></div></div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        '<div class="small-note" style="color:#9CCFC1;margin-bottom:12px;">'
        "Sustainable Energy Engineering · B.Tech CSE</div>",
        unsafe_allow_html=True,
    )

    page = st.radio(
        "Navigation",
        [
            "Home",
            "Consumption Analysis",
            "Appliance Analysis",
            "Prediction",
            "Sustainability Insights",
            "Data Management",
        ],
        label_visibility="collapsed",
        key="nav_page",
    )

    st.markdown('<div class="divider" style="background:rgba(255,255,255,.12);"></div>', unsafe_allow_html=True)
    st.markdown('<div class="side-title">Tariff & grid assumptions</div>', unsafe_allow_html=True)
    tariff = st.number_input(
        "Electricity tariff (Rs./kWh)",
        min_value=0.50, max_value=40.00,
        value=float(st.session_state.tariff), step=0.25, format="%.2f",
        key="tariff_widget",
        help="Illustrative, editable assumption. Replace with your verified utility slab rate.",
    )
    st.session_state.tariff = float(tariff)

    emission_factor = st.number_input(
        "Grid emission factor (kg CO2e/kWh)",
        min_value=0.0, max_value=1.50,
        value=float(st.session_state.emission_factor), step=0.01, format="%.2f",
        key="ef_widget",
        help="Illustrative default 0.71 kg CO2e/kWh, approximately India's grid factor (CEA).",
    )
    st.session_state.emission_factor = float(emission_factor)
    st.caption("Both values are configurable assumptions, not official verified figures.")

    active_preview, _, scenario_modified = current_frames()
    days = int(active_preview["date"].nunique())
    estimated = int((active_preview["data_source"] == "Estimated").sum())
    observed = int((active_preview["data_source"] == "Observed").sum())
    st.markdown(
        '<div class="side-card"><div class="side-title">Dataset status</div>'
        f'<div class="row"><span><span class="status-dot"></span>{html.escape(origin_label(st.session_state.dataset_origin))}</span><b>{days} days</b></div>'
        f'<div class="row"><span>Records</span><b>{len(active_preview):,}</b></div>'
        f'<div class="row"><span>Imputed / estimated</span><b>{estimated}</b></div>'
        f"<div class=\"row\"><span>Observed records</span><b>{observed}</b></div></div>",
        unsafe_allow_html=True,
    )
    if scenario_modified:
        st.markdown(
            '<div class="small-note" style="color:#FCD34D;">Scenario applied: appliance edits are '
            "propagated through all analytics.</div>",
            unsafe_allow_html=True,
        )
        if st.button("Reset appliance edits", key="sidebar_reset"):
            reset_scenario()
    st.markdown(
        '<div class="small-note" style="color:#8FBFAF;margin-top:10px;">'
        "The bundled Project Dataset is used as supplied. Additional household readings can be entered in "
        "Data Management.</div>",
        unsafe_allow_html=True,
    )

TARIFF = float(st.session_state.tariff)
EMISSION_FACTOR = float(st.session_state.emission_factor)


# ---------------------------------------------------------------------------
# Shared computed context
# ---------------------------------------------------------------------------
active_df, appliance_db, scenario_modified = current_frames()
daily_df = daily_summary(active_df)
weekly_df = weekly_summary(daily_df)
appliance_df = appliance_summary(active_df, appliance_db)
cost_stats = cost_summary(daily_df, TARIFF)
sustain_stats = sustainability_summary(daily_df, EMISSION_FACTOR, TARIFF)
recommendations = generate_recommendations(
    appliance_df, appliance_db, TARIFF, EMISSION_FACTOR, days=len(daily_df)
)
insights = household_insights(appliance_df, daily_df, TARIFF, EMISSION_FACTOR)
appliance_df_cost = emissions_by_appliance(appliance_cost(appliance_df, TARIFF), EMISSION_FACTOR)


def render_footer() -> None:
    st.markdown(
        '<div class="footer"><b>Household Electricity Consumption Analyzer</b> · '
        "Sustainable Energy Engineering project · Demonstrates software-based energy analytics. "
        "The bundled Project Dataset is used as supplied; tariff and grid-emission figures are editable assumptions.</div>",
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# Page: Home
# ---------------------------------------------------------------------------
def render_home() -> None:
    provenance = (
        "PROJECT DATASET" if st.session_state.dataset_origin == "Simulated"
        else origin_label(st.session_state.dataset_origin).upper()
    )
    st.markdown(
        '<div class="hero"><div class="hero-kicker">Sustainable Energy Engineering · B.Tech CSE</div>'
        "<h1>Household Electricity Consumption Analyzer</h1>"
        "<p>Estimate appliance-level energy use, identify inefficient consumption patterns, forecast "
        "monthly expenses and quantify practical savings in cost and CO<sub>2</sub> emissions &mdash; "
        "all from a transparent, software-only workflow.</p>"
        '<div class="hero-badges"><span class="good">● ' + provenance + "</span>"
        f"<span>{len(daily_df)}-day observation window</span>"
        f"<span>{appliance_df['appliance_id'].nunique()} appliances</span>"
        "<span>Python · Pandas · Scikit-learn</span><span>No hardware required</span></div></div>",
        unsafe_allow_html=True,
    )

    if st.session_state.dataset_origin == "Simulated":
        callout(
            "Project Dataset",
            "This dashboard uses the project's <b>21-day, 13-appliance Project Dataset</b> "
            "(273 appliance-day records). Tariff and grid-emission values are editable illustrative "
            "assumptions. Additional primary readings can be entered in Data Management.",
            tone="info",
            icon_name="info",
        )

    c1, c2, c3, c4 = st.columns(4, gap="medium")
    c1.markdown(metric_card("21-day energy", kwh(cost_stats["total_kwh"]), "Across the full observation window",
                            "bolt", "teal", "kWh"), unsafe_allow_html=True)
    c2.markdown(metric_card("Average daily use", kwh(cost_stats["avg_daily_kwh"], 2),
                            f"About <b>{inr(cost_stats['avg_daily_cost_inr'])}</b> per day at the selected tariff",
                            "calendar", "blue", "kWh"), unsafe_allow_html=True)
    c3.markdown(metric_card("Projected monthly use", kwh(cost_stats["monthly_kwh"]),
                            f"30-day average method · <b>{inr(cost_stats['monthly_cost_inr'])}</b> estimated bill",
                            "chart", "amber", "kWh"), unsafe_allow_html=True)
    c4.markdown(metric_card("Estimated monthly CO2e", kwh(sustain_stats["monthly_co2_kg"]),
                            f"At {EMISSION_FACTOR:.2f} kg CO2e/kWh · <b>{sustain_stats['annual_co2_tonnes']:.2f} t/year</b>",
                            "leaf", "teal", "kg"), unsafe_allow_html=True)

    standby_total = float(appliance_df["standby_kwh"].sum())
    standby_share = 100 * standby_total / cost_stats["total_kwh"] if cost_stats["total_kwh"] else 0
    top = appliance_df.iloc[0] if not appliance_df.empty else None
    peak = daily_df.loc[daily_df["total_kwh"].idxmax()] if not daily_df.empty else None
    c5, c6, c7, c8 = st.columns(4, gap="medium")
    c5.markdown(metric_card("Standby energy", kwh(standby_total),
                            f"{standby_share:.1f}% of use · <b>{inr(standby_total * TARIFF)}</b> over the window",
                            "plug", "amber", "kWh"), unsafe_allow_html=True)
    c6.markdown(metric_card("Top appliance", f"{top['share_pct']:.0f}%" if top is not None else "—",
                            f"<b>{html.escape(top['appliance_name'])}</b> · {kwh(top['total_kwh'])} kWh" if top is not None else "",
                            "target", "teal"), unsafe_allow_html=True)
    c7.markdown(metric_card("Peak day", kwh(peak["total_kwh"]) if peak is not None else "—",
                            f"<b>{peak['date'].strftime('%d %b %Y')}</b> · {peak['day_of_week']}" if peak is not None else "",
                            "alert", "rose", "kWh"), unsafe_allow_html=True)
    c8.markdown(metric_card("Annual emissions", f"{sustain_stats['annual_co2_tonnes']:.2f}",
                            f"tonnes CO2e · ≈ {sustain_stats['equivalent_tree_years']:,.0f} mature tree-years",
                            "leaf", "blue", "t"), unsafe_allow_html=True)

    st.write("")
    left, right = st.columns([1.62, 1], gap="medium")
    with left:
        st.plotly_chart(charts.daily_consumption_chart(daily_df), width="stretch",
                        config={"displayModeBar": False})
    with right:
        st.plotly_chart(charts.consumption_donut(appliance_df), width="stretch",
                        config={"displayModeBar": False})

    section("Quick insights", "What the data says",
            "Automatically generated, data-backed observations from the current 21-day window.")
    cols = st.columns(2, gap="medium")
    for i, item in enumerate(insights[:4]):
        with cols[i % 2]:
            st.markdown(
                f'<div class="insight-card"><span class="pill">{html.escape(item["tag"])}</span>'
                f'<h4>{html.escape(item["title"])}</h4><p>{item["body"]}</p></div>',
                unsafe_allow_html=True,
            )
            st.write("")

    section("Recommended actions", "Where the savings are",
            "Indicative monthly impact of the highest-value actions. Details and selectable combinations "
            "are available in Sustainability Insights.")
    rec_cols = st.columns(3, gap="medium")
    for i, rec in enumerate(recommendations[:3]):
        with rec_cols[i]:
            st.markdown(
                f'<div class="rec-card"><div class="rec-head"><p class="rec-title">{html.escape(rec["title"])}</p>'
                f'<span class="rec-save">-{rec["monthly_kwh"]:.1f} kWh/mo</span></div>'
                f'<p class="rec-body">{html.escape(rec["description"])}</p>'
                f'<div class="rec-meta">{rec["category"]} · {inr(rec["monthly_inr"])}/month · '
                f'{rec["monthly_co2_kg"]:.1f} kg CO2e avoided/month</div></div>',
                unsafe_allow_html=True,
            )

    st.write("")
    with st.expander("Method snapshot: how these figures are calculated"):
        st.markdown(
            """
**Operating energy (kWh)** = rated power (W) × operating hours × units ÷ 1000

**Standby energy (kWh)** = standby power (W) × standby hours × units ÷ 1000

**Total energy** = operating energy + standby energy

**Monthly projection** = mean daily energy × 30

**Cost** = energy × editable tariff (default Rs. 8.50/kWh, illustrative)

**CO₂e** = energy × editable grid emission factor (default 0.71 kg/kWh, illustrative)

The 21-day dataset contains 273 appliance-day records for 13 appliances. Five records contain
deliberate data-quality anomalies that are repaired and flagged as *Estimated* during cleaning.
            """
        )
    render_footer()


# ---------------------------------------------------------------------------
# Page: Consumption Analysis
# ---------------------------------------------------------------------------
def render_consumption() -> None:
    section("Consumption analysis", "Daily, weekly and appliance-level patterns",
            "Explore when energy is used, which days peak and how the load is distributed.")

    date_min = active_df["date"].min().date()
    date_max = active_df["date"].max().date()
    f1, f2, f3 = st.columns([1, 1, 1.1], gap="medium")
    with f1:
        start_date = st.date_input("From date", value=date_min, min_value=date_min, max_value=date_max,
                                   key="cons_start")
    with f2:
        end_date = st.date_input("To date", value=date_max, min_value=date_min, max_value=date_max,
                                 key="cons_end")
    with f3:
        day_type = st.selectbox("Day type", ["All days", "Weekdays only", "Weekends only"], key="cons_daytype")
    if start_date > end_date:
        start_date, end_date = end_date, start_date

    filtered = active_df[
        (active_df["date"].dt.date >= start_date) & (active_df["date"].dt.date <= end_date)
    ].copy()
    if day_type == "Weekdays only":
        filtered = filtered[~filtered["is_weekend"]]
    elif day_type == "Weekends only":
        filtered = filtered[filtered["is_weekend"]]

    if filtered.empty:
        st.warning("No records match the selected filters. Widen the date range or choose another day type.")
        return

    f_daily = daily_summary(filtered)
    f_weekly = weekly_summary(f_daily)
    f_appliance = appliance_summary(filtered, appliance_db)

    peak = f_daily.loc[f_daily["total_kwh"].idxmax()]
    low = f_daily.loc[f_daily["total_kwh"].idxmin()]
    total = f_daily["total_kwh"].sum()
    avg = f_daily["total_kwh"].mean()
    weekday_avg = f_daily.loc[~f_daily["is_weekend"], "total_kwh"].mean() if (~f_daily["is_weekend"]).any() else avg
    weekend_avg = f_daily.loc[f_daily["is_weekend"], "total_kwh"].mean() if f_daily["is_weekend"].any() else avg
    diff_pct = (weekend_avg - weekday_avg) / weekday_avg * 100 if weekday_avg else 0

    k1, k2, k3, k4 = st.columns(4, gap="medium")
    k1.markdown(metric_card("Filtered energy", kwh(total), f"{len(f_daily)} day(s) selected",
                            "bolt", "teal", "kWh"), unsafe_allow_html=True)
    k2.markdown(metric_card("Average daily", kwh(avg, 2), f"{inr(avg * TARIFF)}/day at current tariff",
                            "chart", "blue", "kWh"), unsafe_allow_html=True)
    k3.markdown(metric_card("Peak day", kwh(peak["total_kwh"], 2),
                            f"{peak['date'].strftime('%d %b')} · {peak['day_of_week']}",
                            "alert", "rose", "kWh"), unsafe_allow_html=True)
    k4.markdown(metric_card("Weekend vs weekday", f"{diff_pct:+.1f}%",
                            f"Weekend {weekend_avg:.2f} vs weekday {weekday_avg:.2f} kWh/day",
                            "calendar", "amber"), unsafe_allow_html=True)

    callout(
        "Peak consumption identified",
        f"The highest day in the selected window is <b>{peak['date'].strftime('%d %B %Y')}</b> "
        f"({peak['day_of_week']}) at <b>{peak['total_kwh']:.2f} kWh</b> "
        f"({inr(peak['total_kwh'] * TARIFF)} and {peak['total_kwh'] * EMISSION_FACTOR:.2f} kg CO2e). "
        f"The lowest day is {low['date'].strftime('%d %B')} at {low['total_kwh']:.2f} kWh.",
        icon_name="alert",
    )

    st.plotly_chart(charts.daily_consumption_chart(f_daily), width="stretch",
                    config={"displayModeBar": False})

    left, right = st.columns(2, gap="medium")
    with left:
        st.plotly_chart(charts.weekly_consumption_chart(f_weekly), width="stretch",
                        config={"displayModeBar": False})
    with right:
        st.plotly_chart(charts.daily_cost_chart(f_daily, TARIFF), width="stretch",
                        config={"displayModeBar": False})

    st.plotly_chart(charts.appliance_consumption_chart(f_appliance), width="stretch",
                    config={"displayModeBar": False})

    left, right = st.columns([1, 1], gap="medium")
    with left:
        st.plotly_chart(charts.consumption_donut(f_appliance), width="stretch",
                        config={"displayModeBar": False})
    with right:
        st.plotly_chart(charts.operating_vs_standby_chart(f_appliance), width="stretch",
                        config={"displayModeBar": False})

    section("Daily detail", "Processed daily records",
            "Every value is derived from the cleaned appliance-level dataset.")
    display = daily_cost(f_daily, TARIFF)
    display["co2_kg"] = (display["total_kwh"] * EMISSION_FACTOR).round(2)
    display["cost_inr"] = display["cost_inr"].round(2)
    display = display[["date", "day_of_week", "week_number", "is_weekend", "operating_kwh",
                       "standby_kwh", "total_kwh", "cost_inr", "co2_kg"]]
    st.dataframe(
        to_excel_safe(display), width="stretch", hide_index=True,
        column_config={
            "date": st.column_config.DateColumn("Date", format="DD MMM YYYY"),
            "day_of_week": "Day",
            "week_number": st.column_config.NumberColumn("Week", format="%d"),
            "is_weekend": "Weekend",
            "operating_kwh": st.column_config.NumberColumn("Operating (kWh)", format="%.2f"),
            "standby_kwh": st.column_config.NumberColumn("Standby (kWh)", format="%.2f"),
            "total_kwh": st.column_config.NumberColumn("Total (kWh)", format="%.2f"),
            "cost_inr": st.column_config.NumberColumn("Cost (Rs.)", format="%.2f"),
            "co2_kg": st.column_config.NumberColumn("CO2e (kg)", format="%.2f"),
        },
    )
    st.download_button(
        "Download filtered daily summary (CSV)", data=csv_bytes(display),
        file_name="daily_consumption_summary.csv", mime="text/csv", key="dl_daily_filtered",
    )
    render_footer()


# ---------------------------------------------------------------------------
# Page: Appliance Analysis
# ---------------------------------------------------------------------------
def render_appliances() -> None:
    section("Appliance analysis", "Appliance database and what-if scenarios",
            "Edit rated power, standby power, unit counts or operating hours. Changes propagate through "
            "every chart, projection and recommendation.")

    if scenario_modified:
        callout(
            "Scenario mode is active",
            "Your appliance edits are applied to the historical daily profile by proportional scaling, "
            "then energy is recomputed from the fundamental formula. Use “Reset appliance edits” in the "
            "sidebar to return to the baseline database.",
            tone="warn",
            icon_name="alert",
        )

    editable = appliance_db[[
        "appliance_id", "appliance_name", "rated_power_w", "standby_power_w",
        "units", "avg_daily_hours", "avg_standby_hours", "design_daily_kwh",
        "design_monthly_kwh",
    ]].copy()

    edited = st.data_editor(
        editable,
        width="stretch",
        hide_index=True,
        num_rows="fixed",
        key="appliance_editor",
        disabled=["appliance_id", "appliance_name", "design_daily_kwh", "design_monthly_kwh"],
        column_config={
            "appliance_id": st.column_config.TextColumn("ID", width="small"),
            "appliance_name": st.column_config.TextColumn("Appliance", width="medium"),
            "rated_power_w": st.column_config.NumberColumn("Rated power (W)", min_value=0, max_value=10000,
                                                          step=1, format="%.0f"),
            "standby_power_w": st.column_config.NumberColumn("Standby power (W)", min_value=0, max_value=200,
                                                             step=0.1, format="%.1f"),
            "units": st.column_config.NumberColumn("Units", min_value=1, max_value=50, step=1, format="%d"),
            "avg_daily_hours": st.column_config.NumberColumn("Operating (h/day)", min_value=0, max_value=24,
                                                             step=0.1, format="%.2f"),
            "avg_standby_hours": st.column_config.NumberColumn("Standby (h/day)", min_value=0, max_value=24,
                                                               step=0.1, format="%.2f"),
            "design_daily_kwh": st.column_config.NumberColumn("Design kWh/day", format="%.2f"),
            "design_monthly_kwh": st.column_config.NumberColumn("Design kWh/month", format="%.1f"),
        },
    )

    if edited is not None:
        prepared = prepare_appliance_database(edited)
        prepared = prepared.merge(
            st.session_state.baseline_db[["appliance_id", "category", "usage_note"]],
            on="appliance_id", how="left",
        )
        base_cmp = st.session_state.appliance_db[DB_EDITABLE_COLS].reset_index(drop=True)
        edit_cmp = prepared[DB_EDITABLE_COLS].reset_index(drop=True)
        if not base_cmp.equals(edit_cmp):
            st.session_state.appliance_db = prepared
            st.rerun()

    base_design = float(st.session_state.baseline_db["design_daily_kwh"].sum())
    current_design = float(appliance_db["design_daily_kwh"].sum())
    delta = current_design - base_design
    top = appliance_df.iloc[0] if not appliance_df.empty else None
    total_standby = float(appliance_df["standby_kwh"].sum())
    if abs(delta) < 0.005:
        delta_sub = "No change from the baseline database"
    else:
        delta_sub = f"{'Increase' if delta > 0 else 'Saving'} of {inr(abs(delta) * 30 * TARIFF)}/month"

    a1, a2, a3, a4 = st.columns(4, gap="medium")
    a1.markdown(metric_card("Design-day consumption", kwh(current_design, 2),
                            f"{inr(current_design * TARIFF)}/day · {inr(current_design * 30 * TARIFF)}/month",
                            "bolt", "teal", "kWh"), unsafe_allow_html=True)
    a2.markdown(metric_card("Change vs baseline", f"{delta:+.2f}", delta_sub,
                            "chart", "amber" if delta > 0 else "teal", "kWh/day"), unsafe_allow_html=True)
    a3.markdown(metric_card("Largest consumer", f"{top['share_pct']:.0f}%" if top is not None else "—",
                            f"<b>{html.escape(top['appliance_name'])}</b> · {kwh(top['projected_monthly_kwh'])} kWh/month" if top is not None else "",
                            "target", "blue"), unsafe_allow_html=True)
    a4.markdown(metric_card("Standby share", f"{100 * total_standby / cost_stats['total_kwh']:.1f}%" if cost_stats["total_kwh"] else "0%",
                            f"{kwh(total_standby)} kWh in window · {inr(total_standby * TARIFF)}",
                            "plug", "rose"), unsafe_allow_html=True)

    st.write("")
    left, right = st.columns([1.35, 1], gap="medium")
    with left:
        st.plotly_chart(charts.appliance_consumption_chart(appliance_df), width="stretch",
                        config={"displayModeBar": False})
    with right:
        st.plotly_chart(charts.operating_vs_standby_chart(appliance_df), width="stretch",
                        config={"displayModeBar": False})

    section("Appliance economics", "Cost, emissions and usage detail",
            "Monthly values use the observed daily average × 30 and the current tariff assumptions.")
    econ = appliance_df_cost[[
        "appliance_name", "category", "rated_power_w", "units", "avg_operating_hours",
        "total_kwh", "standby_kwh", "share_pct", "projected_monthly_kwh",
        "cost_monthly_inr", "co2_monthly_kg",
    ]].copy()
    econ.columns = [
        "Appliance", "Category", "Rated (W)", "Units", "Avg op. hours/day", "Window kWh",
        "Standby kWh", "Share (%)", "Monthly kWh", "Monthly cost (Rs.)", "Monthly CO2e (kg)",
    ]
    st.dataframe(
        econ, width="stretch", hide_index=True,
        column_config={
            "Rated (W)": st.column_config.NumberColumn(format="%.0f"),
            "Units": st.column_config.NumberColumn(format="%d"),
            "Avg op. hours/day": st.column_config.NumberColumn(format="%.2f"),
            "Window kWh": st.column_config.NumberColumn(format="%.2f"),
            "Standby kWh": st.column_config.NumberColumn(format="%.2f"),
            "Share (%)": st.column_config.NumberColumn(format="%.1f"),
            "Monthly kWh": st.column_config.NumberColumn(format="%.1f"),
            "Monthly cost (Rs.)": st.column_config.NumberColumn(format="%.0f"),
            "Monthly CO2e (kg)": st.column_config.NumberColumn(format="%.1f"),
        },
    )
    st.download_button(
        "Download appliance analysis (CSV)", data=csv_bytes(econ),
        file_name="appliance_analysis.csv", mime="text/csv", key="dl_appliance_econ",
    )

    st.markdown(
        '<p class="small-note">Design-day values combine nameplate power, unit count and typical hours. '
        "Actual 21-day totals differ because the supplied observations include weekday/weekend and "
        "day-to-day variation. Editing a parameter scales the observed profile proportionally; it does "
        "not overwrite the underlying measured history.</p>",
        unsafe_allow_html=True,
    )
    render_footer()


# ---------------------------------------------------------------------------
# Page: Prediction
# ---------------------------------------------------------------------------
def render_prediction() -> None:
    section("Predictive analytics", "Forecast consumption and monthly expense",
            "A regularised linear regression captures trend and weekly seasonality; a naive baseline is "
            "evaluated on the same holdout.")

    callout(
        "Model validity statement",
        "The model is trained on the project's <b>Project Dataset</b>. Its metrics demonstrate that the "
        "modelling pipeline works; they are <b>not verified real-world predictive accuracy</b>. With a "
        "genuine 21-day observation file, the same model can be re-evaluated, but a longer history would "
        "be needed before operational use.",
        tone="warn",
        icon_name="alert",
    )

    try:
        result = fit_and_forecast(daily_df, horizon=config.FORECAST_DAYS)
    except PredictionError as exc:
        st.error(f"Prediction unavailable: {exc}")
        return

    m = result["metrics"]
    p1, p2, p3, p4 = st.columns(4, gap="medium")
    p1.markdown(metric_card("Holdout MAE", f"{m['mae']:.2f}", "kWh per day (last 7 days held out)",
                            "target", "teal", "kWh"), unsafe_allow_html=True)
    p2.markdown(metric_card("Holdout RMSE", f"{m['rmse']:.2f}", "Root mean squared error",
                            "chart", "blue", "kWh"), unsafe_allow_html=True)
    p3.markdown(metric_card("Holdout MAPE", f"{m['mape']:.1f}", f"R² = {m['r2']:.2f} on the holdout",
                            "calendar", "amber", "%"), unsafe_allow_html=True)
    p4.markdown(metric_card("30-day forecast", kwh(result["monthly_forecast_kwh"]),
                            f"≈ {inr(result['monthly_forecast_kwh'] * TARIFF)} at Rs. {TARIFF:.2f}/kWh",
                            "bolt", "teal", "kWh"), unsafe_allow_html=True)

    st.plotly_chart(charts.prediction_chart(result), width="stretch",
                    config={"displayModeBar": False})

    left, right = st.columns([1.15, 1], gap="medium")
    with left:
        st.plotly_chart(charts.forecast_bar_chart(result), width="stretch",
                        config={"displayModeBar": False})
    with right:
        plan = cost_stats["monthly_kwh"]
        diff = result["monthly_forecast_kwh"] - plan
        st.markdown(
            f'<div class="insight-card"><span class="pill">Monthly outlook</span>'
            f"<h4>Model forecast vs simple average</h4>"
            f'<p>{prediction_insight(result, TARIFF)}</p></div>',
            unsafe_allow_html=True,
        )
        st.write("")
        o1, o2 = st.columns(2)
        o1.markdown(metric_card("Model 30-day cost", inr(result["monthly_forecast_kwh"] * TARIFF),
                                "Model-based expense", "rupee", "amber"), unsafe_allow_html=True)
        o2.markdown(metric_card("Average method", inr(plan * TARIFF),
                                f"{kwh(plan)} kWh · 30-day mean", "chart", "blue"), unsafe_allow_html=True)
        st.markdown(
            f'<p class="small-note">The model forecast is {diff:+.1f} kWh '
            f"({diff / plan * 100:+.1f}%) versus the simple 30-day average. The average method is used "
            "for the headline home-dashboard bill because it is more robust for a short 21-day history; "
            "the model provides an independent, trend-aware cross-check.</p>",
            unsafe_allow_html=True,
        )

    section("Model evaluation", "Transparent comparison",
            "Chronological holdout: the first 14 days train the model; the last 7 days test it.")
    compare = model_comparison_table(result)
    st.dataframe(
        compare, width="stretch", hide_index=True,
        column_config={
            "MAE (kWh/day)": st.column_config.NumberColumn(format="%.2f"),
            "RMSE (kWh/day)": st.column_config.NumberColumn(format="%.2f"),
            "MAPE (%)": st.column_config.NumberColumn(format="%.1f"),
            "R2": st.column_config.NumberColumn("R²", format="%.3f"),
        },
    )
    best = "Ridge regression" if m["rmse"] <= result["baseline_metrics"]["rmse"] else "the naive baseline"
    st.markdown(
        f'<p class="small-note">On this holdout, <b>{best}</b> has the lower RMSE. '
        f"The regression reduces MAE from {result['baseline_metrics']['mae']:.2f} to {m['mae']:.2f} kWh/day. "
        "Results vary with the dataset and the holdout window.</p>",
        unsafe_allow_html=True,
    )

    with st.expander("How the model works"):
        st.markdown(
            f"""
**Features:** linear day index, weekend indicator, and sine/cosine terms for the 7-day cycle.

**Model:** Ridge regression (L2-regularised linear regression), alpha = {result['alpha']}.

**Training:** first {result['train_size']} days. **Testing:** last {result['test_size']} days (chronological, no shuffling).

**Forecast:** the model is refitted on all {result['train_size'] + result['test_size']} days and projected
{result['forecast_days']} days ahead. The shaded band is an approximate 95% interval of ±{result['interval_half_width']:.2f} kWh/day,
based on holdout RMSE.

**Fitted coefficients:** intercept {result['coefficients']['level'] if 'level' in result['coefficients'] else result['model_equation_terms']['intercept']:.3f},
trend {result['coefficients']['trend']:+.3f} kWh/day, weekend effect {result['coefficients']['is_weekend']:+.3f} kWh/day.
The trend is a statistical association in a short series, not a causal projection.
            """
        )

    section("Forecast detail", "Next 30 days",
            "Download the complete forecast for reporting or further analysis.")
    forecast_display = result["forecast_frame"].copy()
    forecast_display["date"] = pd.to_datetime(forecast_display["date"])
    st.dataframe(
        to_excel_safe(forecast_display.head(14)), width="stretch", hide_index=True,
        column_config={
            "date": st.column_config.DateColumn("Date", format="DD MMM YYYY"),
            "predicted_kwh": st.column_config.NumberColumn("Predicted (kWh)", format="%.2f"),
            "lower_kwh": st.column_config.NumberColumn("Lower 95% (kWh)", format="%.2f"),
            "upper_kwh": st.column_config.NumberColumn("Upper 95% (kWh)", format="%.2f"),
            "day_of_week": "Day",
            "is_weekend": "Weekend",
        },
    )
    d1, d2 = st.columns(2)
    with d1:
        st.download_button(
            "Download 30-day forecast (CSV)", data=csv_bytes(to_excel_safe(forecast_display)),
            file_name="consumption_forecast_30_days.csv", mime="text/csv", key="dl_forecast",
        )
    with d2:
        st.download_button(
            "Download holdout evaluation (CSV)", data=csv_bytes(to_excel_safe(result["test_frame"])),
            file_name="model_holdout_evaluation.csv", mime="text/csv", key="dl_holdout",
        )
    render_footer()


# ---------------------------------------------------------------------------
# Page: Sustainability Insights
# ---------------------------------------------------------------------------
def render_sustainability() -> None:
    section("Sustainability insights", "Emissions, waste and quantified savings",
            "Translate electricity into environmental impact and choose a package of practical actions.")

    s1, s2, s3, s4 = st.columns(4, gap="medium")
    s1.markdown(metric_card("Monthly CO2e", kwh(sustain_stats["monthly_co2_kg"]),
                            f"At {EMISSION_FACTOR:.2f} kg CO2e/kWh", "leaf", "teal", "kg"), unsafe_allow_html=True)
    s2.markdown(metric_card("Annual CO2e", f"{sustain_stats['annual_co2_tonnes']:.2f}",
                            f"{inr(sustain_stats['annual_cost_inr'])} annual electricity cost", "leaf", "blue", "t"),
                unsafe_allow_html=True)
    s3.markdown(metric_card("Standby waste", kwh(float(appliance_df['standby_kwh'].sum())),
                            f"{inr(float(appliance_df['standby_kwh'].sum()) * TARIFF)} over 21 days · "
                            f"{float(appliance_df['standby_kwh'].sum()) * EMISSION_FACTOR:.1f} kg CO2e",
                            "plug", "amber", "kWh"), unsafe_allow_html=True)
    s4.markdown(metric_card("Equivalent car travel", f"{sustain_stats['equivalent_car_km']:,.0f}",
                            "km/year at 0.171 kg CO2e/km (illustrative)", "target", "rose", "km"),
                unsafe_allow_html=True)

    left, right = st.columns([1.4, 1], gap="medium")
    with left:
        st.plotly_chart(charts.co2_chart(appliance_df, EMISSION_FACTOR), width="stretch",
                        config={"displayModeBar": False})
    with right:
        st.markdown(
            f'<div class="insight-card"><span class="pill">Annual perspective</span>'
            f"<h4>{sustain_stats['annual_kwh']:,.0f} kWh and {sustain_stats['annual_co2_kg']:,.0f} kg CO2e per year</h4>"
            f"<p>The current consumption profile implies about <b>{sustain_stats['annual_co2_tonnes']:.2f} tonnes</b> "
            f"of CO2e annually, equivalent to the annual absorption of roughly "
            f"<b>{sustain_stats['equivalent_tree_years']:,.0f} mature trees</b> or driving "
            f"<b>{sustain_stats['equivalent_car_km']:,.0f} km</b>. These equivalences are illustrative, not offsets.</p></div>",
            unsafe_allow_html=True,
        )
        st.write("")
        top3 = appliance_df.head(3)
        st.markdown(
            '<div class="insight-card"><span class="pill">Concentration</span>'
            "<h4>Three appliances dominate the load</h4><p>"
            + "".join(
                f"<b>{html.escape(row['appliance_name'])}</b> — {row['share_pct']:.1f}%<br>"
                for _, row in top3.iterrows()
            )
            + "Together they account for "
            + f"{top3['share_pct'].sum():.1f}% of observed electricity. Targeting these end uses first "
            "gives the largest impact per unit of effort.</p></div>",
            unsafe_allow_html=True,
        )

    section("Action planner", "Build a personalised savings package",
            "Select one or more actions. Savings are additive because each action targets a distinct end use.")
    options = [r["id"] for r in recommendations]
    labels = {r["id"]: r["title"] for r in recommendations}
    stored = st.session_state.get("selected_actions", options)
    st.session_state.selected_actions = [x for x in stored if x in options]
    selected = st.multiselect(
        "Recommended actions",
        options=options,
        format_func=lambda x: labels.get(x, x),
        key="selected_actions",
    )
    combo = combined_savings(recommendations, selected, cost_stats["monthly_kwh"])

    c1, c2, c3, c4 = st.columns(4, gap="medium")
    c1.markdown(metric_card("Monthly energy saving", kwh(combo["monthly_kwh"]),
                            f"{combo['pct_of_monthly']:.1f}% of projected monthly use", "bolt", "teal", "kWh"),
                unsafe_allow_html=True)
    c2.markdown(metric_card("Monthly bill saving", inr(combo["monthly_inr"]),
                            f"At Rs. {TARIFF:.2f}/kWh", "rupee", "amber"), unsafe_allow_html=True)
    c3.markdown(metric_card("Monthly CO2e avoided", kwh(combo["monthly_co2_kg"]),
                            "Using the editable grid factor", "leaf", "blue", "kg"), unsafe_allow_html=True)
    c4.markdown(metric_card("Annual value", inr(combo["annual_inr"]),
                            f"{kwh(combo['annual_kwh'])} kWh · {kwh(combo['annual_co2_kg'])} kg CO2e avoided",
                            "calendar", "teal"), unsafe_allow_html=True)

    if selected:
        st.plotly_chart(
            charts.savings_waterfall(cost_stats["monthly_kwh"], combo["monthly_kwh"]),
            width="stretch", config={"displayModeBar": False},
        )
    else:
        st.info("Select at least one action to see the combined impact.")

    section("Recommendation detail", "Transparent assumptions",
            "Every saving is calculated from the appliance database or the observed consumption profile.")
    rec_table = recommendations_table(recommendations)
    st.dataframe(
        rec_table, width="stretch", hide_index=True,
        column_config={
            "Saving (kWh/month)": st.column_config.NumberColumn(format="%.2f"),
            "Saving (Rs./month)": st.column_config.NumberColumn(format="%.0f"),
            "CO2 avoided (kg/month)": st.column_config.NumberColumn(format="%.1f"),
            "Annual saving (Rs.)": st.column_config.NumberColumn(format="%.0f"),
        },
    )
    st.download_button(
        "Download recommendations and savings (CSV)", data=csv_bytes(rec_table),
        file_name="energy_saving_recommendations.csv", mime="text/csv", key="dl_recs",
    )

    with st.expander("Saving calculation assumptions"):
        st.markdown(
            f"""
- **Standby:** {config.RECOMMENDATION_ASSUMPTIONS['standby_elimination_fraction']*100:.0f}% of observed standby energy is avoidable.
- **Fan:** 1.0 operating hour/day avoided for all fan units.
- **Lighting:** each remaining CFL is replaced by a 9 W LED with identical operating hours.
- **Geyser:** 20 minutes/day less heating at rated power.
- **Washing machine:** 25% reduction in operating energy through full loads.
- **Air conditioner:** 25% reduction in operating energy through scheduling and a 26 °C set-point.

These are planning estimates for one household. Actual savings depend on behaviour, appliance condition,
climate and tariff structure. The selected actions are not claimed to be cost-free unless stated.
            """
        )
    render_footer()


# ---------------------------------------------------------------------------
# Page: Data Management
# ---------------------------------------------------------------------------
def dataset_overview_tab() -> None:
    report = st.session_state.quality_report
    k1, k2, k3, k4 = st.columns(4, gap="medium")
    k1.markdown(metric_card("Rows in cleaned data", f"{report.get('rows_out', len(active_df)):,}",
                            f"{report.get('rows_in', len(active_df)):,} raw rows received", "chart", "teal"),
                unsafe_allow_html=True)
    k2.markdown(metric_card("Observation days", f"{report.get('days', active_df['date'].nunique())}",
                            f"{report.get('date_start', '')} to {report.get('date_end', '')}",
                            "calendar", "blue"), unsafe_allow_html=True)
    k3.markdown(metric_card("Values imputed", f"{report.get('missing_values_imputed', 0)}",
                            "Missing/invalid values repaired and flagged", "alert", "amber"),
                unsafe_allow_html=True)
    k4.markdown(metric_card("Estimated records", f"{report.get('estimated_records', 0)}",
                            "Marked as Estimated, never silently mixed", "info", "teal"),
                unsafe_allow_html=True)

    callout(
        "Data provenance is preserved",
        "The <code>data_source</code> column records whether a row belongs to the supplied "
        "<b>Project Dataset</b>, was <b>Estimated</b> during cleaning, or came from <b>Observed</b> "
        "primary readings. Cleaning never relabels supplied data as observed. Five anomalies in the "
        "supplied file demonstrate missing-value handling and validation.",
        icon_name="info",
    )

    left, right = st.columns([1.35, 1], gap="medium")
    with left:
        st.markdown("**Cleaned dataset preview**")
        preview = active_df[[
            "date", "appliance_name", "operating_hours", "standby_hours",
            "operating_kwh", "standby_kwh", "total_kwh", "data_source", "quality_flag",
        ]].head(80).copy()
        preview = display_source_frame(preview)
        st.dataframe(
            to_excel_safe(preview), width="stretch", hide_index=True, height=330,
            column_config={
                "date": st.column_config.DateColumn("Date", format="DD MMM"),
                "appliance_name": st.column_config.TextColumn("Appliance"),
                "operating_hours": st.column_config.NumberColumn("Op. h", format="%.2f"),
                "standby_hours": st.column_config.NumberColumn("SB h", format="%.2f"),
                "operating_kwh": st.column_config.NumberColumn("Op. kWh", format="%.3f"),
                "standby_kwh": st.column_config.NumberColumn("SB kWh", format="%.3f"),
                "total_kwh": st.column_config.NumberColumn("Total kWh", format="%.3f"),
                "data_source": st.column_config.TextColumn("Source"),
                "quality_flag": st.column_config.TextColumn("Quality"),
            },
        )
    with right:
        st.markdown("**Record provenance**")
        prov = active_df.groupby("data_source", as_index=False).agg(
            Records=("appliance_id", "size"), Energy_kWh=("total_kwh", "sum")
        )
        prov["data_source"] = prov["data_source"].replace({"Simulated": "Project Dataset"})
        prov["Energy_kWh"] = prov["Energy_kWh"].round(2)
        st.dataframe(prov, width="stretch", hide_index=True)
        st.markdown(
            f'<p class="small-note">Scenario edits: <b>{"active" if scenario_modified else "none"}</b>. '
            "When scenario mode is active, hours are scaled to the edited design values and flagged "
            "<code>scenario_adjusted</code> in the processed data.</p>",
            unsafe_allow_html=True,
        )

    st.markdown("**Data-quality issues resolved during cleaning**")
    issues = active_df[active_df["quality_flag"].isin(
        ["imputed_missing_value", "corrected_or_imputed", "injected_missing_value", "injected_invalid_value"]
    )][["date", "appliance_name", "operating_hours", "standby_hours", "total_kwh",
        "quality_flag", "data_source"]]
    issues = display_source_frame(issues)
    if issues.empty:
        st.success("No imputed or corrected records in the current dataset.")
    else:
        st.dataframe(
            to_excel_safe(issues), width="stretch", hide_index=True,
            column_config={
                "date": st.column_config.DateColumn("Date", format="DD MMM YYYY"),
                "operating_hours": st.column_config.NumberColumn("Op. h", format="%.2f"),
                "standby_hours": st.column_config.NumberColumn("SB h", format="%.2f"),
                "total_kwh": st.column_config.NumberColumn("Total kWh", format="%.4f"),
            },
        )


def upload_tab() -> None:
    st.markdown("**Upload a household dataset**")
    st.markdown(
        '<p class="small-note">Required columns: date, appliance_id, appliance_name, rated_power_w, '
        "standby_power_w, units, operating_hours, standby_hours, data_source. Energy columns are "
        "recomputed from the fundamental formula, so they are optional on upload.</p>",
        unsafe_allow_html=True,
    )
    uploaded = st.file_uploader("Choose a CSV file", type=["csv"], key="dataset_uploader")
    if uploaded is not None:
        try:
            df = load_energy_csv(uploaded)
        except Exception as exc:
            st.error(f"Could not read the CSV: {exc}")
            return
        st.markdown(f"**Preview** · {len(df):,} rows × {len(df.columns)} columns")
        st.dataframe(to_excel_safe(df.head(50)), width="stretch", hide_index=True)
        ok, errors, warnings = validate_schema(df)
        for err in errors:
            st.error(err)
        for warn in warnings:
            st.warning(warn)
        if ok:
            if st.button("Clean and use this dataset", type="primary", key="apply_upload"):
                cleaned, report = clean_energy_data(df)
                st.session_state.clean_base_df = cleaned
                st.session_state.raw_base_df = df.copy()
                st.session_state.quality_report = report
                st.session_state.dataset_label = f"Uploaded dataset: {uploaded.name}"
                sources = set(cleaned["data_source"].dropna().astype(str).unique())
                st.session_state.dataset_origin = (
                    "Observed" if sources == {"Observed"} else
                    "Estimated" if sources == {"Estimated"} else
                    "Mixed" if len(sources) > 1 else "Simulated"
                )
                st.session_state.dataset_filename = uploaded.name
                st.success(f"Dataset applied: {report['rows_out']} cleaned records over {report['days']} days.")
                st.rerun()

    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown("**Templates**")
    template_bytes = config.PRIMARY_TEMPLATE_PATH.read_bytes() if config.PRIMARY_TEMPLATE_PATH.exists() else b""
    st.download_button(
        "Download 21-day primary observation template (CSV)", data=template_bytes,
        file_name="primary_observation_template.csv", mime="text/csv", key="dl_template_upload_tab",
        type="primary",
    )
    st.markdown(
        '<p class="small-note">The template pre-fills dates, appliances and nameplate power for 273 '
        "appliance-day records. Enter only genuine readings in <code>operating_hours</code> and "
        "<code>standby_hours</code>; leave rows blank where an appliance was not observed. Do not "
        "present template or estimated values as measurements.</p>",
        unsafe_allow_html=True,
    )


def save_observed_log(df: pd.DataFrame) -> tuple[bool, str]:
    try:
        OBSERVED_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        export = df.copy()
        if "date" in export:
            export["date"] = pd.to_datetime(export["date"]).dt.strftime("%Y-%m-%d")
        export.to_csv(OBSERVED_LOG_PATH, index=False)
        return True, ""
    except Exception as exc:
        return False, str(exc)


def primary_tab() -> None:
    st.markdown("**Primary observation log**")
    callout(
        "This section is for primary household observations",
        "The assignment requires 21 days of primary observation. Use the template or the manual form "
        "below to record readings. Records entered here are labelled <b>Observed</b> and stored in "
        "<code>data/primary_observations_entered.csv</code>. They are kept separate from the "
        "Project Dataset.",
        icon_name="info",
    )

    obs = st.session_state.observed_df.copy()
    n_rows = len(obs)
    covered_days = obs["date"].dt.date.nunique() if n_rows and "date" in obs else 0
    appliances = obs["appliance_id"].nunique() if n_rows and "appliance_id" in obs else 0
    o1, o2, o3 = st.columns(3, gap="medium")
    o1.markdown(metric_card("Observed records", f"{n_rows:,}", "Genuine entries in the log",
                            "chart", "teal"), unsafe_allow_html=True)
    o2.markdown(metric_card("Days covered", f"{covered_days}/21", "Target: 21 continuous days",
                            "calendar", "amber"), unsafe_allow_html=True)
    o3.markdown(metric_card("Appliances covered", f"{appliances}", "Distinct appliance IDs",
                            "target", "blue"), unsafe_allow_html=True)

    st.progress(min(n_rows / 273.0, 1.0), text=f"Observation completeness: {n_rows}/273 appliance-day records")

    tab_form, tab_upload, tab_log = st.tabs(["Manual entry", "Upload completed template", "Observation log"])

    with tab_form:
        with st.form("manual_observation_form", clear_on_submit=True):
            f1, f2, f3, f4 = st.columns([1, 1.3, 1, 1])
            with f1:
                obs_date = st.date_input("Observation date", value=date.today(), key="obs_date")
            with f2:
                names = appliance_db.set_index("appliance_id")["appliance_name"].to_dict()
                obs_app = st.selectbox("Appliance", options=list(names.keys()),
                                       format_func=lambda x: f"{x} · {names[x]}", key="obs_app")
            with f3:
                obs_hours = st.number_input("Operating hours", min_value=0.0, max_value=24.0,
                                            value=0.0, step=0.25, key="obs_hours")
            with f4:
                obs_sb_hours = st.number_input("Standby hours", min_value=0.0, max_value=24.0,
                                               value=0.0, step=0.5, key="obs_sb_hours")
            obs_notes = st.text_input("Notes (optional)", key="obs_notes",
                                      placeholder="e.g., measured with plug-in energy meter")
            submitted = st.form_submit_button("Add observed record", type="primary")
        if submitted:
            if obs_hours + obs_sb_hours > 24:
                st.error("Operating hours + standby hours cannot exceed 24.")
            else:
                row = appliance_db[appliance_db["appliance_id"] == obs_app].iloc[0]
                op_kwh = energy_kwh(row["rated_power_w"], obs_hours, int(row["units"]))
                sb_kwh = standby_energy_kwh(row["standby_power_w"], obs_sb_hours, int(row["units"]))
                entry = {
                    "date": pd.Timestamp(obs_date),
                    "appliance_id": obs_app,
                    "appliance_name": row["appliance_name"],
                    "rated_power_w": row["rated_power_w"],
                    "standby_power_w": row["standby_power_w"],
                    "units": int(row["units"]),
                    "operating_hours": float(obs_hours),
                    "standby_hours": float(obs_sb_hours),
                    "operating_kwh": round(op_kwh, 4),
                    "standby_kwh": round(sb_kwh, 4),
                    "total_kwh": round(op_kwh + sb_kwh, 4),
                    "data_source": "Observed",
                    "quality_flag": "primary_observation",
                    "notes": obs_notes or "Entered manually",
                }
                st.session_state.observed_df = pd.concat(
                    [st.session_state.observed_df, pd.DataFrame([entry])], ignore_index=True
                )
                saved, message = save_observed_log(st.session_state.observed_df)
                if saved:
                    st.success("Observed record added and saved to the primary observation log.")
                else:
                    st.warning(f"Record added for this session but could not be saved to disk: {message}")
                st.rerun()

    with tab_upload:
        st.markdown(
            "Download the blank template, complete it with genuine readings, then upload it here. "
            "Only rows with a numeric operating-hours value are imported."
        )
        if config.PRIMARY_TEMPLATE_PATH.exists():
            st.download_button(
                "Download blank 21-day template", data=config.PRIMARY_TEMPLATE_PATH.read_bytes(),
                file_name="primary_observation_template.csv", mime="text/csv", key="dl_template_primary",
            )
        primary_file = st.file_uploader("Upload completed observation template", type=["csv"],
                                        key="primary_uploader")
        if primary_file is not None:
            try:
                df = load_energy_csv(primary_file)
            except Exception as exc:
                st.error(f"Could not read file: {exc}")
                return
            ok, errors, warnings = validate_schema(df)
            for err in errors:
                st.error(err)
            for warn in warnings:
                st.warning(warn)
            hours_numeric = pd.to_numeric(df.get("operating_hours"), errors="coerce")
            completed = df[hours_numeric.notna()].copy()
            st.info(f"{len(completed)} completed row(s) detected out of {len(df)} template rows.")
            if not completed.empty:
                st.dataframe(to_excel_safe(completed.head(30)), width="stretch", hide_index=True)
                if st.button("Append completed observations to log", type="primary", key="append_obs"):
                    completed["standby_hours"] = pd.to_numeric(
                        completed.get("standby_hours", 0), errors="coerce"
                    ).fillna(0)
                    completed["operating_hours"] = pd.to_numeric(completed["operating_hours"], errors="coerce")
                    completed = completed[completed["operating_hours"].notna()].copy()
                    completed["date"] = pd.to_datetime(completed["date"], errors="coerce")
                    completed = completed.dropna(subset=["date"])
                    completed["operating_kwh"] = (
                        pd.to_numeric(completed["rated_power_w"], errors="coerce")
                        * completed["operating_hours"]
                        * pd.to_numeric(completed["units"], errors="coerce") / 1000
                    ).round(4)
                    completed["standby_kwh"] = (
                        pd.to_numeric(completed["standby_power_w"], errors="coerce")
                        * completed["standby_hours"]
                        * pd.to_numeric(completed["units"], errors="coerce") / 1000
                    ).round(4)
                    completed["total_kwh"] = (completed["operating_kwh"] + completed["standby_kwh"]).round(4)
                    completed["data_source"] = "Observed"
                    completed["quality_flag"] = "primary_observation"
                    cols = [
                        "date", "appliance_id", "appliance_name", "rated_power_w", "standby_power_w",
                        "units", "operating_hours", "standby_hours", "operating_kwh", "standby_kwh",
                        "total_kwh", "data_source", "quality_flag", "notes",
                    ]
                    for col in cols:
                        if col not in completed.columns:
                            completed[col] = ""
                    st.session_state.observed_df = pd.concat(
                        [st.session_state.observed_df, completed[cols]], ignore_index=True
                    )
                    saved, message = save_observed_log(st.session_state.observed_df)
                    if saved:
                        st.success(f"Appended {len(completed)} observation(s) to the primary log.")
                    else:
                        st.warning(f"Appended for this session; disk save failed: {message}")
                    st.rerun()

    with tab_log:
        obs = st.session_state.observed_df.copy()
        if obs.empty:
            st.info("No primary observations have been entered yet. The existing analysis uses "
                    "the Project Dataset.")
        else:
            display_obs = obs.copy()
            if "date" in display_obs:
                display_obs["date"] = pd.to_datetime(display_obs["date"])
            st.dataframe(
                to_excel_safe(display_obs), width="stretch", hide_index=True, height=320,
                column_config={
                    "date": st.column_config.DateColumn("Date", format="DD MMM YYYY"),
                    "operating_hours": st.column_config.NumberColumn("Op. h", format="%.2f"),
                    "standby_hours": st.column_config.NumberColumn("SB h", format="%.2f"),
                    "total_kwh": st.column_config.NumberColumn("Total kWh", format="%.4f"),
                },
            )
            d1, d2 = st.columns(2)
            with d1:
                st.download_button(
                    "Download observation log (CSV)", data=csv_bytes(to_excel_safe(obs)),
                    file_name="primary_observations_completed.csv", mime="text/csv", key="dl_obs_log",
                )
            with d2:
                if st.button("Clear observation log", key="clear_obs"):
                    st.session_state.observed_df = pd.DataFrame()
                    if OBSERVED_LOG_PATH.exists():
                        try:
                            OBSERVED_LOG_PATH.unlink()
                        except OSError:
                            pass
                    st.rerun()
            total_obs = float(obs["total_kwh"].sum()) if "total_kwh" in obs else 0.0
            st.markdown(
                f'<p class="small-note">Observed energy in the log: <b>{total_obs:.2f} kWh</b> across '
                f"<b>{obs['date'].dt.date.nunique()}</b> day(s). This log is kept separate from the "
                "the Project Dataset; it is evidence of primary data collection, not a replacement for "
                "the full 21-day analysis until complete.</p>",
                unsafe_allow_html=True,
            )


def downloads_tab() -> None:
    st.markdown("**Download analysis outputs**")
    daily_export = daily_cost(daily_df, TARIFF)
    daily_export["co2_kg"] = (daily_export["total_kwh"] * EMISSION_FACTOR).round(3)
    app_export = appliance_df_cost.copy()
    rec_export = recommendations_table(recommendations)
    prov_export = active_df.groupby("data_source", as_index=False).agg(
        Records=("appliance_id", "size"), Energy_kWh=("total_kwh", "sum")
    )
    d1, d2, d3 = st.columns(3)
    with d1:
        st.download_button("Cleaned appliance-level data", data=csv_bytes(to_excel_safe(active_df)),
                           file_name="project_dataset_cleaned.csv", mime="text/csv", key="dl_clean",
                           type="primary")
    with d2:
        st.download_button("Daily summary with cost & CO2e", data=csv_bytes(to_excel_safe(daily_export)),
                           file_name="daily_summary.csv", mime="text/csv", key="dl_daily")
    with d3:
        st.download_button("Appliance analysis", data=csv_bytes(to_excel_safe(app_export)),
                           file_name="appliance_analysis_full.csv", mime="text/csv", key="dl_app_full")
    d4, d5, d6 = st.columns(3)
    with d4:
        st.download_button("Recommendations", data=csv_bytes(to_excel_safe(rec_export)),
                           file_name="recommendations.csv", mime="text/csv", key="dl_rec_full")
    with d5:
        st.download_button("Data provenance summary", data=csv_bytes(prov_export),
                           file_name="data_provenance.csv", mime="text/csv", key="dl_prov")
    with d6:
        st.download_button("Primary observation template", data=config.PRIMARY_TEMPLATE_PATH.read_bytes(),
                           file_name="primary_observation_template.csv", mime="text/csv",
                           key="dl_template_downloads")

    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown("**Bundle all analysis outputs**")
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("project_dataset_cleaned.csv", csv_bytes(to_excel_safe(active_df)))
        zf.writestr("daily_summary.csv", csv_bytes(to_excel_safe(daily_export)))
        zf.writestr("appliance_analysis_full.csv", csv_bytes(to_excel_safe(app_export)))
        zf.writestr("recommendations.csv", csv_bytes(to_excel_safe(rec_export)))
        zf.writestr("data_provenance.csv", csv_bytes(prov_export))
        zf.writestr("scenario_appliance_database.csv", csv_bytes(appliance_db))
        zf.writestr(
            "README_RESULTS.txt",
            "Household Electricity Consumption Analyzer - analysis bundle\n"
            f"Dataset: {st.session_state.dataset_label}\n"
            f"Tariff: Rs. {TARIFF:.2f}/kWh (illustrative assumption)\n"
            f"Emission factor: {EMISSION_FACTOR:.2f} kg CO2e/kWh (illustrative assumption)\n"
            "All analysis figures are derived from the cleaned dataset. Estimated values are not "
            "physical measurements.\n",
        )
    st.download_button("Download complete analysis bundle (ZIP)", data=buffer.getvalue(),
                       file_name="household_energy_analysis_outputs.zip", mime="application/zip",
                       key="dl_bundle", type="primary")

    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown("**Project documents**")
    doc_cols = st.columns(3)
    report_path = config.REPORT_DIR / "Project_Report.pdf"
    slides_path = config.REPORT_DIR / "Project_Presentation.pptx"
    problem_path = config.DOCS_DIR / "Problem_Statement.pdf"
    with doc_cols[0]:
        if report_path.exists():
            st.download_button("Academic project report (PDF)", data=report_path.read_bytes(),
                               file_name=report_path.name, mime="application/pdf", key="dl_report")
        else:
            st.caption("Report will appear here after generation.")
    with doc_cols[1]:
        if slides_path.exists():
            st.download_button("Five-slide presentation (PPTX)", data=slides_path.read_bytes(),
                               file_name=slides_path.name,
                               mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                               key="dl_slides")
        else:
            st.caption("Presentation will appear here after generation.")
    with doc_cols[2]:
        if problem_path.exists():
            st.download_button("Problem statement (PDF)", data=problem_path.read_bytes(),
                               file_name=problem_path.name, mime="application/pdf", key="dl_problem")
        else:
            st.caption("Problem statement will appear here after generation.")


def dictionary_tab() -> None:
    st.markdown(
        """
**Dataset columns**

| Column | Meaning |
|---|---|
| `date` | Calendar date of the record (YYYY-MM-DD) |
| `day_of_week`, `week_number` | Derived calendar fields |
| `appliance_id`, `appliance_name` | Appliance identity |
| `rated_power_w` | Nameplate operating power (W) |
| `standby_power_w` | Power drawn while plugged in but idle (W) |
| `units` | Number of identical units |
| `operating_hours` | Hours of active operation in the day |
| `standby_hours` | Hours in standby mode |
| `operating_kwh`, `standby_kwh`, `total_kwh` | Recomputed energy values (kWh) |
| `data_source` | Source label for each row (supplied, estimated or observed); the bundled file is shown as Project Dataset |
| `quality_flag` | Validation / imputation / scenario status |
| `notes` | Provenance or handling note |

**Cleaning rules**

1. Dates are parsed; rows without a valid date are removed.
2. Duplicate date–appliance pairs are removed (last record retained).
3. Operating and standby hours outside 0–24 are treated as missing.
4. Missing or invalid values are imputed with the appliance median, then the global median.
5. Operating, standby and total energy are recomputed from the fundamental formula.
6. Every touched record is marked `Estimated`, with a `quality_flag`, so provenance is never lost.

**Calculation assumptions**

- Monthly projection uses a 30-day month.
- Annual projections use 365 days.
- Default tariff: Rs. 8.50/kWh (illustrative, editable).
- Default grid emission factor: 0.71 kg CO2e/kWh (rounded approximation of India's CEA grid factor; editable).
- Standby elimination savings assume 90% of observed standby energy is avoidable.

**Data integrity**

The bundled `project_dataset_raw.csv` is the Project Dataset used throughout this analysis.
The `primary_observation_template.csv` is the correct instrument for additional 21-day
primary data collection.
        """
    )


def render_data_management() -> None:
    section("Data management", "Datasets, primary observations and downloads",
            "Upload, validate, inspect and export every result. Observed data is kept separate from "
            "the Project Dataset.")

    st.markdown(
        f'<span class="badge blue">'
        f'Active: {html.escape(origin_label(st.session_state.dataset_origin))}</span>&nbsp; '
        f'<span class="badge grey">{html.escape(st.session_state.dataset_filename)}</span>&nbsp; '
        f'<span class="badge grey">{len(active_df):,} records · {daily_df["date"].nunique()} days</span>',
        unsafe_allow_html=True,
    )
    st.write("")

    top1, top2, top3 = st.columns([1, 1, 1])
    with top1:
        st.download_button("Download active cleaned dataset", data=csv_bytes(to_excel_safe(active_df)),
                           file_name="project_dataset_cleaned.csv", mime="text/csv", key="dl_top_clean")
    with top2:
        if st.button("Restore Project Dataset", key="restore_demo"):
            restore_demo_dataset()
    with top3:
        st.caption(f"Tariff Rs. {TARIFF:.2f}/kWh · emission factor {EMISSION_FACTOR:.2f} kg/kWh")

    tabs = st.tabs(["Dataset overview", "Upload dataset", "Primary observations", "Downloads", "Data dictionary"])
    with tabs[0]:
        dataset_overview_tab()
    with tabs[1]:
        upload_tab()
    with tabs[2]:
        primary_tab()
    with tabs[3]:
        downloads_tab()
    with tabs[4]:
        dictionary_tab()
    render_footer()


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------
if page == "Home":
    render_home()
elif page == "Consumption Analysis":
    render_consumption()
elif page == "Appliance Analysis":
    render_appliances()
elif page == "Prediction":
    render_prediction()
elif page == "Sustainability Insights":
    render_sustainability()
elif page == "Data Management":
    render_data_management()
