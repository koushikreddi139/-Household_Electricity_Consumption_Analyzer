"""
Electricity tariff and cost calculations.

The tariff is always supplied by the caller. The application exposes it as an
editable assumption; no official utility tariff is claimed.
"""

from __future__ import annotations

import pandas as pd

from . import config


def energy_cost(kwh: float, tariff_inr_per_kwh: float, fixed_charge_inr: float = 0.0) -> float:
    """Cost of a given energy quantity (INR)."""
    if kwh < 0:
        raise ValueError("kwh must be non-negative.")
    if tariff_inr_per_kwh < 0:
        raise ValueError("tariff must be non-negative.")
    if fixed_charge_inr < 0:
        raise ValueError("fixed charge must be non-negative.")
    return float(kwh) * float(tariff_inr_per_kwh) + float(fixed_charge_inr)


def daily_cost(daily_df: pd.DataFrame, tariff_inr_per_kwh: float) -> pd.DataFrame:
    """Add a cost column to a daily summary."""
    out = daily_df.copy()
    out["cost_inr"] = (out["total_kwh"] * tariff_inr_per_kwh).round(2)
    return out


def appliance_cost(appliance_df: pd.DataFrame, tariff_inr_per_kwh: float) -> pd.DataFrame:
    """Add window, monthly and annual cost columns to an appliance summary."""
    out = appliance_df.copy()
    out["cost_window_inr"] = (out["total_kwh"] * tariff_inr_per_kwh).round(2)
    out["cost_monthly_inr"] = (out["projected_monthly_kwh"] * tariff_inr_per_kwh).round(2)
    out["cost_annual_inr"] = (out["cost_monthly_inr"] * 12).round(2)
    return out


def cost_summary(
    daily_df: pd.DataFrame,
    tariff_inr_per_kwh: float,
    fixed_charge_inr: float = config.DEFAULT_FIXED_CHARGE_INR,
) -> dict[str, float]:
    """Headline electricity cost figures for the observation window."""
    total_kwh = float(daily_df["total_kwh"].sum())
    days = max(int(len(daily_df)), 1)
    avg_daily = total_kwh / days
    monthly_kwh = avg_daily * config.PROJECTION_DAYS
    return {
        "total_kwh": round(total_kwh, 3),
        "window_cost_inr": round(total_kwh * tariff_inr_per_kwh, 2),
        "avg_daily_kwh": round(avg_daily, 3),
        "avg_daily_cost_inr": round(avg_daily * tariff_inr_per_kwh, 2),
        "weekly_kwh": round(avg_daily * 7, 3),
        "weekly_cost_inr": round(avg_daily * 7 * tariff_inr_per_kwh, 2),
        "monthly_kwh": round(monthly_kwh, 3),
        "monthly_cost_inr": round(monthly_kwh * tariff_inr_per_kwh + fixed_charge_inr, 2),
        "annual_kwh": round(avg_daily * 365, 3),
        "annual_cost_inr": round(avg_daily * 365 * tariff_inr_per_kwh + fixed_charge_inr * 12, 2),
        "tariff_inr_per_kwh": float(tariff_inr_per_kwh),
        "fixed_charge_inr": float(fixed_charge_inr),
    }


def savings_value(kwh_per_month: float, tariff_inr_per_kwh: float) -> dict[str, float]:
    """Monthly and annual financial value of an energy saving."""
    monthly = float(kwh_per_month) * float(tariff_inr_per_kwh)
    return {
        "monthly_kwh": round(float(kwh_per_month), 3),
        "monthly_inr": round(monthly, 2),
        "annual_kwh": round(float(kwh_per_month) / 30.0 * 365.0, 3),
        "annual_inr": round(monthly / 30.0 * 365.0, 2),
    }
