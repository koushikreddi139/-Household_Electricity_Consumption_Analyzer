"""Generate the five-slide project presentation (16:9)."""

from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image as PILImage
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import config
from src.team import GUIDE, TEAM_MEMBERS, TEAM_NUMBER
from src.cost_analysis import cost_summary
from src.data_processing import (
    appliance_summary, clean_energy_data, daily_summary, load_energy_csv,
)
from src.prediction import fit_and_forecast
from src.recommendations import combined_savings, generate_recommendations
from src.sustainability import sustainability_summary

OUT = ROOT / "reports" / "Project_Presentation.pptx"
TARIFF = config.DEFAULT_TARIFF_INR_PER_KWH
EF = config.DEFAULT_EMISSION_FACTOR

# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------
raw = load_energy_csv(config.RAW_DATA_PATH)
clean, quality = clean_energy_data(raw)
db = load_energy_csv(config.APPLIANCE_DB_PATH)
daily = daily_summary(clean)
appl = appliance_summary(clean, db)
cost = cost_summary(daily, TARIFF)
sust = sustainability_summary(daily, EF, TARIFF)
pred = fit_and_forecast(daily)
recs = generate_recommendations(appl, db, TARIFF, EF)
combined = combined_savings(recs, [r["id"] for r in recs], cost["monthly_kwh"])

# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------
DEEP = RGBColor(0x0B, 0x3B, 0x36)
PRIMARY = RGBColor(0x0F, 0x76, 0x6E)
EMERALD = RGBColor(0x10, 0xB9, 0x81)
MINT = RGBColor(0x6E, 0xE7, 0xB7)
LIGHT = RGBColor(0xD1, 0xFA, 0xE5)
BG = RGBColor(0xF5, 0xF8, 0xF6)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
INK = RGBColor(0x0F, 0x17, 0x2A)
MUTED = RGBColor(0x64, 0x74, 0x8B)
GRID = RGBColor(0xE2, 0xE8, 0xF0)
AMBER = RGBColor(0xD9, 0x77, 0x06)
SOFT = RGBColor(0xE8, 0xF3, 0xEF)

FONT = "Segoe UI"
W, H = 13.333, 7.5

prs = Presentation()
prs.slide_width = Inches(W)
prs.slide_height = Inches(H)
blank = prs.slide_layouts[6]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def add_slide():
    return prs.slides.add_slide(blank)


def rect(slide, x, y, w, h, fill, line=None, shape=MSO_SHAPE.RECTANGLE, radius=None):
    shp = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    shp.fill.solid()
    shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line
        shp.line.width = Pt(0.8)
    shp.shadow.inherit = False
    if radius is not None and shape == MSO_SHAPE.ROUNDED_RECTANGLE:
        shp.adjustments[0] = radius
    return shp


def tx(slide, x, y, w, h, text, size=14, bold=False, color=INK, align=PP_ALIGN.LEFT,
       anchor=MSO_ANCHOR.TOP, spacing=1.0, italic=False, margins=(0, 0, 0, 0)):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(margins[0])
    tf.margin_right = Inches(margins[1])
    tf.margin_top = Inches(margins[2])
    tf.margin_bottom = Inches(margins[3])
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    p.alignment = align
    p.line_spacing = spacing
    run = p.add_run()
    run.text = text
    run.font.name = FONT
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    return box


def tx_lines(slide, x, y, w, h, lines, size=13, color=INK, spacing=1.25,
             space_after=6, bold_lead=False):
    """lines: list of (text, bold) or str."""
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.margin_left = 0
    tf.margin_right = 0
    tf.margin_top = 0
    tf.margin_bottom = 0
    first = True
    for item in lines:
        text, bold = (item, bold_lead) if isinstance(item, str) else item
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.line_spacing = spacing
        p.space_after = Pt(space_after)
        run = p.add_run()
        run.text = text
        run.font.name = FONT
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.color.rgb = color
    return box


def image_contain(slide, path, x, y, w, h):
    im_w, im_h = PILImage.open(path).size
    scale = min(w / im_w, h / im_h)
    width, height = im_w * scale, im_h * scale
    left = x + (w - width) / 2
    top = y + (h - height) / 2
    return slide.shapes.add_picture(str(path), Inches(left), Inches(top),
                                    Inches(width), Inches(height))


def slide_base(number, eyebrow, title, subtitle=None):
    s = add_slide()
    rect(s, 0, 0, W, H, BG)
    rect(s, 0, 0, 0.32, H, DEEP)
    tx(s, 0.62, 0.34, 9.0, 0.3, eyebrow.upper(), 10.5, True, PRIMARY)
    tx(s, 0.62, 0.63, 11.6, 0.62, title, 30, True, DEEP)
    rect(s, 0.64, 1.33, 0.9, 0.055, EMERALD)
    if subtitle:
        tx(s, 0.62, 1.47, 11.8, 0.4, subtitle, 12.5, False, MUTED)
    tx(s, W - 1.55, H - 0.42, 1.0, 0.24, f"{number:02d} / 05", 9.5, True, MUTED,
       align=PP_ALIGN.RIGHT)
    tx(s, 0.62, H - 0.42, 7.8, 0.24, "Household Electricity Consumption Analyzer", 9, False, MUTED)
    return s


def kpi(slide, x, y, w, value, label, accent=PRIMARY):
    rect(slide, x, y, w, 0.92, WHITE, GRID, MSO_SHAPE.ROUNDED_RECTANGLE, 0.10)
    tx(slide, x + 0.18, y + 0.12, w - 0.3, 0.42, value, 21, True, accent)
    tx(slide, x + 0.18, y + 0.57, w - 0.3, 0.24, label.upper(), 8, False, MUTED)


def notes(slide, text):
    slide.notes_slide.notes_text_frame.text = text


# ---------------------------------------------------------------------------
# Slide 1 - Title
# ---------------------------------------------------------------------------
s = add_slide()
rect(s, 0, 0, W, H, DEEP)
rect(s, W - 2.6, -1.4, 5.6, 5.6, RGBColor(0x12, 0x52, 0x4A), shape=MSO_SHAPE.OVAL)
rect(s, W - 3.7, 3.9, 5.0, 5.0, RGBColor(0x0E, 0x4A, 0x43), shape=MSO_SHAPE.OVAL)

pill = rect(s, 0.85, 0.72, 4.75, 0.36, RGBColor(0x14, 0x5C, 0x53),
            shape=MSO_SHAPE.ROUNDED_RECTANGLE, radius=0.5)
tx(s, 1.02, 0.79, 4.5, 0.22,
   "SUSTAINABLE ENERGY ENGINEERING  ·  B.TECH CSE", 9, True, MINT)

tx(s, 0.85, 1.55, 9.7, 0.5, "Project Presentation", 13, True, MINT)
tx(s, 0.85, 1.95, 10.0, 1.9,
   "Household Electricity\nConsumption Analyzer", 40, True, WHITE, spacing=0.98)
tx(s, 0.85, 3.78, 9.3, 0.5,
   "Appliance-level energy, cost, forecast and carbon analysis", 17, False, MINT)
tx(s, 0.85, 4.38, 8.6, 0.7,
   "A software-only dashboard that turns 21 days of operating-hour records into transparent, "
   "editable estimates — with every data source labelled.", 12.5, False, LIGHT, spacing=1.15)

stats = [("21 days", "observation window"), ("13", "appliances modelled"),
         ("273", "appliance-day records"), ("6", "dashboard modules")]
for i, (value, label) in enumerate(stats):
    x = 0.85 + i * 2.55
    rect(s, x, 5.28, 2.35, 0.86, RGBColor(0x10, 0x48, 0x42), RGBColor(0x1E, 0x6B, 0x60),
         MSO_SHAPE.ROUNDED_RECTANGLE, 0.10)
    tx(s, x + 0.16, 5.37, 2.0, 0.36, value, 19, True, WHITE)
    tx(s, x + 0.16, 5.76, 2.0, 0.24, label, 8.5, False, MINT)

tx(s, 0.85, 6.30, 9.2, 0.26,
   "Project Dataset  ·  21 days  ·  13 appliances  ·  273 appliance-day records", 9.5, True, MINT)
tx(s, 0.85, 6.55, 11.6, 0.24,
   f"TEAM NO. {TEAM_NUMBER}   ·   {TEAM_MEMBERS[0][0]} — {TEAM_MEMBERS[0][1]}   ·   "
   f"{TEAM_MEMBERS[1][0]} — {TEAM_MEMBERS[1][1]}", 8.6, False, LIGHT)
tx(s, 0.85, 6.80, 11.6, 0.24,
   f"{TEAM_MEMBERS[2][0]} — {TEAM_MEMBERS[2][1]}   ·   "
   f"{TEAM_MEMBERS[3][0]} — {TEAM_MEMBERS[3][1]}", 8.6, False, LIGHT)
tx(s, 0.85, 7.05, 7.2, 0.24, f"Under the guidance of {GUIDE}", 8.6, False, MINT)
tx(s, 8.5, 7.05, 4.2, 0.24, "Python · Pandas · Scikit-learn · Streamlit", 8.6, False, LIGHT,
   align=PP_ALIGN.RIGHT)
notes(s, "Opening: this is a software-only analyzer built on the project's 21-day appliance-level "
         "Project Dataset. Every figure shown is reproducible from the included source and tests.")

# ---------------------------------------------------------------------------
# Slide 2 - Problem & pipeline
# ---------------------------------------------------------------------------
s = slide_base(2, "Problem and approach", "One bill hides every end use",
               "A household can see the total, not the appliance, the standby draw, or the carbon.")
tx(s, 0.62, 2.05, 6.0, 0.3, "THE GAP", 10, True, PRIMARY)
problems = [
    ("No attribution", "One monthly number cannot tell which appliance drives the bill."),
    ("Invisible standby", "Idle electronics draw power that is never itemised."),
    ("Messy manual records", "Gaps, negatives and duplicates break naive analysis."),
    ("Unverifiable claims", "Savings and carbon estimates often hide their assumptions."),
]
y = 2.45
for head, text in problems:
    rect(s, 0.66, y + 0.09, 0.11, 0.11, EMERALD)
    tx(s, 0.92, y, 5.55, 0.28, head, 13.5, True, DEEP)
    tx(s, 0.92, y + 0.27, 5.55, 0.5, text, 11.2, False, MUTED, spacing=1.05)
    y += 0.87

# Pipeline on the right
rect(s, 7.15, 1.95, 5.55, 4.55, WHITE, GRID, MSO_SHAPE.ROUNDED_RECTANGLE, 0.04)
tx(s, 7.45, 2.12, 4.9, 0.28, "THE PIPELINE", 10, True, PRIMARY)
steps = [
    ("1  COLLECT", "21-day appliance log or CSV upload", SOFT, DEEP),
    ("2  CLEAN", "validate · impute · label provenance", LIGHT, DEEP),
    ("3  COMPUTE", "energy · cost · CO₂e · forecast", SOFT, DEEP),
    ("4  DECIDE", "rank actions · track savings", LIGHT, DEEP),
]
y = 2.5
for label, detail, fill, color in steps:
    rect(s, 7.45, y, 4.95, 0.73, fill, None, MSO_SHAPE.ROUNDED_RECTANGLE, 0.12)
    tx(s, 7.62, y + 0.08, 4.6, 0.24, label, 9.5, True, PRIMARY)
    tx(s, 7.62, y + 0.34, 4.6, 0.26, detail, 10.5, False, color)
    y += 0.94

tx(s, 0.62, 6.48, 11.9, 0.34,
   "Provenance rule:  Project Dataset  ·  Estimated  ·  Observed — a repaired record can never become observed.",
   10.5, True, PRIMARY)
notes(s, "Frame the problem as missing attribution, not missing data. The pipeline keeps provenance "
         "explicit at every step: cleaning can only label a repaired record as Estimated.")

# ---------------------------------------------------------------------------
# Slide 3 - Consumption results
# ---------------------------------------------------------------------------
s = slide_base(3, "Consumption results", "Where the energy goes",
               "21 winter days, 13 appliances, 273 records — cleaned and labelled.")
kpis = [
    (f"{quality['total_kwh']:.1f} kWh", "21-day energy"),
    (f"{cost['avg_daily_kwh']:.2f} kWh", "average per day"),
    (f"{cost['monthly_kwh']:.1f} kWh", "projected month"),
    (f"Rs. {cost['monthly_cost_inr']:,.0f}", "monthly bill"),
]
for i, (value, label) in enumerate(kpis):
    kpi(s, 0.62 + i * 3.02, 1.93, 2.85, value, label)

image_contain(s, config.VIS_DIR / "daily_consumption.png", 0.55, 3.02, 7.85, 3.28)
tx(s, 0.62, 6.38, 7.8, 0.26,
   "Daily use is stable at 10–13 kWh; the final Sunday peaks at 15.0 kWh.", 9.5, False, MUTED)

# Right: top appliance shares
tx(s, 8.8, 3.02, 3.9, 0.28, "SHARE OF 21-DAY ENERGY", 10, True, PRIMARY)
shares = [(row.appliance_name.replace(" (Geyser)", ""), row.share_pct)
          for row in appl.head(3).itertuples()]
shares.append(("All other appliances", float(appl.iloc[3:]["share_pct"].sum())))
bar_x, bar_w = 8.8, 2.85
y = 3.38
for name, share in shares:
    tx(s, bar_x, y, 2.7, 0.24, name, 9.5, False, INK)
    tx(s, 12.05, y, 0.75, 0.24, f"{share:.0f}%", 9.5, True, PRIMARY, align=PP_ALIGN.RIGHT)
    rect(s, bar_x, y + 0.27, bar_w, 0.11, GRID, None, MSO_SHAPE.ROUNDED_RECTANGLE, 0.5)
    rect(s, bar_x, y + 0.27, max(bar_w * share / 100, 0.04), 0.11, EMERALD if share > 15 else PRIMARY,
         None, MSO_SHAPE.ROUNDED_RECTANGLE, 0.5)
    y += 0.58

rect(s, 8.8, 5.86, 3.95, 0.78, DEEP, None, MSO_SHAPE.ROUNDED_RECTANGLE, 0.08)
tx(s, 8.97, 5.94, 3.6, 0.3, "63.3% in three appliances", 12.5, True, WHITE)
tx(s, 8.97, 6.25, 3.6, 0.28, "Geyser, refrigerator and AC. Start there.", 9.5, False, MINT)
notes(s, "Headline results: 240.4 kWh over 21 days, 11.45 kWh/day, 343.4 kWh projected month, "
         "Rs. 2,919 at the editable tariff. The geyser alone is 34% of consumption.")

# ---------------------------------------------------------------------------
# Slide 4 - Forecast and carbon
# ---------------------------------------------------------------------------
s = slide_base(4, "Forecast and sustainability", "A modest forecast, a measurable footprint",
               "Interpretable model, honest holdout, editable grid factor.")
image_contain(s, config.VIS_DIR / "consumption_prediction.png", 0.55, 2.0, 8.0, 3.9)
tx(s, 0.62, 6.02, 7.9, 0.62,
   f"7-day holdout: MAE {pred['metrics']['mae']:.2f} kWh/day vs {pred['baseline_metrics']['mae']:.2f} "
   f"for a naive baseline. R² {pred['metrics']['r2']:.2f} — useful, but not over-claimed.",
   10, False, MUTED, spacing=1.1)

tx(s, 8.9, 2.02, 3.8, 0.28, "30-DAY MODEL FORECAST", 9.5, True, PRIMARY)
tx(s, 8.9, 2.3, 3.8, 0.5, f"{pred['monthly_forecast_kwh']:.1f} kWh", 25, True, DEEP)
tx(s, 8.9, 2.82, 3.8, 0.28, f"≈ Rs. {pred['monthly_forecast_kwh'] * TARIFF:,.0f} at the selected tariff",
   10, False, MUTED)

tx(s, 8.9, 3.35, 3.8, 0.28, "CARBON FOOTPRINT", 9.5, True, PRIMARY)
tx(s, 8.9, 3.63, 3.8, 0.5, f"{sust['monthly_co2_kg']:.1f} kg", 25, True, DEEP)
tx(s, 8.9, 4.15, 3.8, 0.28, f"CO₂e per month  ·  {sust['annual_co2_tonnes']:.2f} t per year",
   10, False, MUTED)

tx(s, 8.9, 4.7, 3.8, 0.28, "STANDBY WASTE", 9.5, True, PRIMARY)
tx(s, 8.9, 4.98, 3.8, 0.5, f"{quality['standby_kwh']:.1f} kWh", 25, True, DEEP)
tx(s, 8.9, 5.5, 3.8, 0.28,
   f"{quality['standby_kwh'] / quality['total_kwh'] * 100:.1f}% of use — a zero-cost target",
   10, False, MUTED)

rect(s, 8.9, 5.95, 3.8, 0.62, LIGHT, None, MSO_SHAPE.ROUNDED_RECTANGLE, 0.10)
tx(s, 9.06, 6.04, 3.5, 0.44,
   "Model forecast and mean-based bill are reported separately — different questions.",
   8.8, False, DEEP, spacing=1.05)
notes(s, "The model beats the naive baseline on the 7-day holdout (MAE 1.12 vs 1.48) but R-squared is "
         "only 0.40. Say this plainly. The 30-day forecast is 362.7 kWh, deliberately kept separate "
         "from the 343.4 kWh mean-based bill.")

# ---------------------------------------------------------------------------
# Slide 5 - Actions and conclusion
# ---------------------------------------------------------------------------
s = slide_base(5, "Recommendations and conclusion", "Six actions, one measurable saving",
               "Ranked by monthly energy saving, with explicit assumptions.")
tx(s, 0.62, 1.98, 7.4, 0.28, "ACTION", 9, True, MUTED)
tx(s, 5.42, 1.98, 1.0, 0.28, "kWh/mo", 9, True, MUTED, align=PP_ALIGN.RIGHT)
tx(s, 6.55, 1.98, 1.0, 0.28, "Rs./mo", 9, True, MUTED, align=PP_ALIGN.RIGHT)

short = {
    "geyser": "Geyser: cut 20 min/day",
    "standby": "Switch idle appliances off at the plug",
    "ac": "AC: timer and 26 °C set-point",
    "fan": "Fans: trim 1 hour/day",
    "cfl": "Replace CFLs with 9 W LEDs",
    "washing": "Wash full loads only",
}
y = 2.3
for rec in recs:
    rect(s, 0.62, y, 7.15, 0.55, WHITE, GRID, MSO_SHAPE.ROUNDED_RECTANGLE, 0.12)
    rect(s, 0.62, y, 0.07, 0.55, EMERALD if rec["rank"] <= 3 else PRIMARY)
    tx(s, 0.82, y + 0.13, 4.7, 0.28, short.get(rec["id"], rec["title"]), 10.5, False, INK)
    tx(s, 5.42, y + 0.13, 1.0, 0.28, f"{rec['monthly_kwh']:.1f}", 10.5, True, PRIMARY, align=PP_ALIGN.RIGHT)
    tx(s, 6.55, y + 0.13, 1.0, 0.28, f"{rec['monthly_inr']:.0f}", 10.5, True, PRIMARY, align=PP_ALIGN.RIGHT)
    y += 0.63

tx(s, 0.62, 6.12, 7.2, 0.3,
   "Top three actions deliver 42.2 kWh/month — 83% of the total package.", 9.5, False, MUTED)

# Combined panel
rect(s, 8.25, 1.98, 4.5, 4.55, DEEP, None, MSO_SHAPE.ROUNDED_RECTANGLE, 0.06)
tx(s, 8.5, 2.14, 4.0, 0.28, "ALL SIX ACTIONS TOGETHER", 9.5, True, MINT)
tx(s, 8.5, 2.42, 3.9, 0.6, f"{combined['monthly_kwh']:.1f} kWh", 30, True, WHITE)
tx(s, 8.5, 3.02, 3.9, 0.28, f"Rs. {combined['monthly_inr']:,.0f}  ·  {combined['monthly_co2_kg']:.1f} kg CO₂e",
   12, True, MINT)
tx(s, 8.5, 3.34, 3.9, 0.26, "saved per month", 9.5, False, LIGHT)

rect(s, 8.5, 3.72, 3.95, 0.055, RGBColor(0x1E, 0x6B, 0x60))
tx(s, 8.5, 3.94, 3.95, 0.4,
   f"{combined['pct_of_monthly']:.1f}% of projected use\nRs. {combined['annual_inr']:,.0f} per year",
   11.5, True, WHITE, spacing=1.15)
tx(s, 8.5, 4.62, 3.95, 0.4,
   f"{combined['annual_co2_kg']:.1f} kg CO₂e avoided per year", 10, False, MINT)

tx(s, 8.5, 5.18, 3.95, 0.7,
   "Estimates assume independent actions and stated adherence. Not guaranteed outcomes.",
   8.8, False, LIGHT, spacing=1.08)

tx(s, 8.5, 5.95, 3.95, 0.4, "NEXT: APPLY TO NEW OBSERVATIONS", 8.5, True, MINT)
tx(s, 8.5, 6.18, 3.95, 0.34, "Complete 21 days of real readings in the template.", 8.8, False, WHITE,
   spacing=1.0)
notes(s, "The six actions save 50.6 kWh, Rs. 430 and 35.9 kg CO2e per month, 14.7% of projected use. "
         "The geyser and standby actions are zero-cost. The next step is genuine observation, not "
         "more modelling.")

# ---------------------------------------------------------------------------
OUT.parent.mkdir(parents=True, exist_ok=True)
prs.save(str(OUT))
print(f"Wrote {OUT}")
print(f"Slides: {len(prs.slides)}")
