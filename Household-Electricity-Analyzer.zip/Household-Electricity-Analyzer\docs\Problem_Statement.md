# Problem Statement

**Project:** Household Electricity Consumption Analyzer
**Programme:** B.Tech Computer Science and Engineering (Sustainable Energy Engineering)
**Nature of work:** Software-only analysis, forecasting and reporting — no hardware or sensors

## Team No. 1

| Member | Registration number |
|---|---|
| R Koushik | RA2311003050036 |
| K Rakesh | RA2311003050012 |
| M Pushkal | RA2311003050013 |
| P Nitin | RA2311003050064 |

**Under the Guidance of** Asst. Prof. Logudurai

---

## 1. Context

A household receives one consolidated electricity bill at the end of a billing cycle. The bill
reports units consumed and the amount payable, but it does not reveal which appliance produced the
consumption, when the energy was used, how much was drawn while equipment was idle, or what the
environmental consequence was. This information gap is a barrier to energy efficiency: a household
cannot manage what it cannot see.

India's residential demand is growing, and space heating, water heating, refrigeration and cooling
are major end uses. Efficiency programmes and star labels exist, but their benefit depends on how a
particular household actually operates its appliances. A low-cost method is needed to convert a
short period of manual observation into defensible estimates of energy, cost, demand and emissions.

## 2. Problem definition

The core problem is to design and build a transparent software workflow that accepts
appliance-level operating-hour observations for a 21-day period and produces consistent estimates
of electricity consumption, monthly cost, next-month demand, standby waste and CO₂e emissions. The
workflow must remain honest about data provenance: values that are provided, imputed or estimated
must never be presented as physically measured.

- Manual meter reading is slow, error-prone and rarely stored in a structured, analysable form.
- A single monthly total cannot attribute consumption to appliances or identify standby waste.
- Without a documented assumption set, cost and carbon estimates are difficult to reproduce or audit.
- Short observation windows and imperfect records require explicit cleaning and provenance rules.
- Forecasts and savings claims are easily overstated when uncertainty and method are hidden.

## 3. Proposed solution

The project implements a Python and Streamlit application with six modules: Home, Consumption
Analysis, Appliance Analysis, Prediction, Sustainability Insights and Data Management. A normalised
CSV schema records appliance identity, rated and standby power, unit count, operating and standby
hours, and a provenance label. A cleaning pipeline validates the schema, repairs out-of-range
values, imputes missing values with appliance medians and marks every affected record as Estimated.
Energy is recomputed from the fundamental relationship `E = P × t / 1000`, then aggregated daily,
weekly and monthly.

An editable tariff and grid emission factor convert energy into cost and CO₂e. A Ridge regression
with trend, weekend and weekly-cycle features produces a 30-day forecast, evaluated chronologically
against a naive seven-day moving-average baseline. Six practical actions are quantified in kWh,
rupees and kilograms of CO₂e per month. A blank 21-day observation template supports additional
primary data collection, and the dashboard clearly separates provided, **Estimated** and
**Observed** records.

## 4. Objectives

1. Define a clear, documented schema for 21 days of appliance-level observations.
2. Implement a validation and cleaning pipeline that preserves data provenance.
3. Compute energy, cost and emissions from transparent, editable assumptions.
4. Analyse daily, weekly and appliance-level consumption patterns.
5. Forecast the next 30 days and benchmark the model against a naive baseline.
6. Quantify practical saving actions in energy, money and carbon terms.
7. Deliver an interactive dashboard, reproducible figures, tests, a report and a presentation.

## 5. Scope and boundaries

**In scope:** a single household, 13 common appliances, a 21-day winter observation window,
appliance-level energy and standby analysis, tariff and emission calculations, a regression
forecast, quantified recommendations, an interactive dashboard, static charts, automated tests and
academic documentation.

**Out of scope:** hardware sensors, Arduino/ESP32 devices, smart meters, real-time data acquisition,
weather modelling, time-of-use tariff optimisation, multi-household benchmarking, authentication
and cloud deployment. The Project Dataset provides the working analysis for this submission.

## 6. Data provenance and ethics

> **Data provenance**
>
> The 21-day Project Dataset supplied with this project is the dataset used throughout this analysis.
> Its measurement provenance is not independently verified here; results demonstrate that the
> software works end to end. A blank primary-observation template is included so that additional
> readings can be analysed without changing the analysis code.

No personal data are collected. Tariffs and emission factors are illustrative and editable; no
official utility tariff or verified grid factor is claimed. Savings are engineering estimates, not
guaranteed outcomes.

## 7. Expected deliverables

| Deliverable | Purpose |
|---|---|
| Working Streamlit dashboard | Six-module interactive analysis with editable assumptions |
| Project Dataset (21 days) | Supplied appliance-level dataset used throughout the analysis |
| Blank observation template | Supports additional 21-day primary data collection |
| Cleaning and analysis modules | Validated, reusable and unit-tested calculation core |
| Forecast and recommendations | Transparent model with baseline and quantified actions |
| Static figures and screenshots | Report, presentation and archive evidence |
| Project report (10 pages) | Academic documentation of method, results and limitations |
| Five-slide presentation | Concise project defence and walkthrough |
| Automated tests | Regression protection for all core calculations |

## 8. Expected outcome

A submission-ready, reproducible prototype that turns structured manual observations into a coherent
efficiency assessment, with every assumption visible and every data source labelled. The project is
successful if a reader can trace any headline number back to a formula, an input record and a stated
assumption — and if the same software can accept real observations without modification.
