"""
Data ingestion, validation, cleaning and aggregation.

The cleaning pipeline is deliberately explicit: every imputation or correction
is counted, flagged and reflected in the ``data_source`` column so that
supplied, estimated and observed records can never be confused.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from . import config
from .energy_calculator import add_energy_columns


class DataValidationError(ValueError):
    """Raised when a dataset does not satisfy the minimum schema."""


# ---------------------------------------------------------------------------
# Loading and schema validation
# ---------------------------------------------------------------------------
def load_energy_csv(source: str | Any) -> pd.DataFrame:
    """Read a CSV file or uploaded file object into a dataframe."""
    df = pd.read_csv(source)
    df.columns = [str(c).strip() for c in df.columns]
    return df


def validate_schema(df: pd.DataFrame) -> tuple[bool, list[str], list[str]]:
    """Return (is_valid, errors, warnings) for an uploaded dataframe."""
    errors: list[str] = []
    warnings: list[str] = []

    missing = [c for c in config.REQUIRED_DATA_COLUMNS if c not in df.columns]
    if missing:
        errors.append("Missing required column(s): " + ", ".join(missing))
        return False, errors, warnings

    parsed = pd.to_datetime(df["date"], errors="coerce")
    bad_dates = int(parsed.isna().sum())
    if bad_dates:
        errors.append(f"{bad_dates} row(s) have an invalid date.")
    elif parsed.notna().any():
        unique_days = parsed.dt.normalize().nunique()
        if unique_days < 21:
            warnings.append(
                f"Only {unique_days} distinct calendar day(s) found; the assignment "
                "requires at least 21 continuous days of primary observation."
            )
        expected = pd.date_range(parsed.min(), parsed.max(), freq="D")
        if len(expected) != unique_days:
            warnings.append("The date sequence has gaps; results should be interpreted cautiously.")

    for col in ["rated_power_w", "standby_power_w", "units", "operating_hours", "standby_hours"]:
        numeric = pd.to_numeric(df[col], errors="coerce")
        if numeric.isna().all():
            errors.append(f"Column '{col}' contains no numeric values.")
        elif numeric.isna().any():
            warnings.append(f"Column '{col}' has {int(numeric.isna().sum())} missing/invalid value(s) that will be imputed.")
    hours_values = pd.to_numeric(df["operating_hours"], errors="coerce")
    if hours_values.notna().sum() == 0:
        errors.append(
            "No completed operating-hour values were found. If this is the blank primary "
            "observation template, enter genuine readings first."
        )

    sources = set(df["data_source"].dropna().astype(str).str.strip().unique())
    unknown = sources - config.VALID_DATA_SOURCES
    if unknown:
        warnings.append(
            "Unrecognised data_source value(s): " + ", ".join(sorted(unknown)) +
            ". Allowed values: Simulated (supplied), Estimated, Observed."
        )
    if not df.empty and sources and sources <= {"Simulated"}:
        warnings.append(
            "This file contains only the supplied Project Dataset records. Add primary "
            "observations for additional evidence."
        )
    if df.empty:
        errors.append("The dataset is empty.")
    return len(errors) == 0, errors, warnings


# ---------------------------------------------------------------------------
# Cleaning
# ---------------------------------------------------------------------------
def clean_energy_data(df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Clean and validate appliance-level energy records.

    Steps
    -----
    1. Parse dates and coerce numeric columns.
    2. Remove rows without a usable date or appliance identity.
    3. Remove duplicate date/appliance records.
    4. Treat out-of-range hours (negative or >24) as missing.
    5. Impute missing/invalid values with the appliance median (then global median).
    6. Recompute energy from the fundamental formula.
    7. Mark imputed records as ``Estimated`` and flag their quality status.
    """
    out = df.copy()
    out.columns = [str(c).strip() for c in out.columns]
    rows_in = len(out)

    for col in config.REQUIRED_DATA_COLUMNS:
        if col not in out.columns:
            raise DataValidationError(f"Required column missing: {col}")

    out["date"] = pd.to_datetime(out["date"], errors="coerce").dt.normalize()
    out["appliance_id"] = out["appliance_id"].astype(str).str.strip()
    out["appliance_name"] = out["appliance_name"].astype(str).str.strip()
    out["data_source"] = out["data_source"].fillna("Estimated").astype(str).str.strip()
    out["data_source"] = out["data_source"].where(
        out["data_source"].isin(config.VALID_DATA_SOURCES), "Estimated"
    )
    if "quality_flag" not in out.columns:
        out["quality_flag"] = "validated"
    else:
        out["quality_flag"] = out["quality_flag"].fillna("validated").astype(str)

    for col in config.NUMERIC_DATA_COLUMNS:
        if col not in out.columns:
            out[col] = np.nan
        out[col] = pd.to_numeric(out[col], errors="coerce")

    # Remove unusable identity rows
    before_drop = len(out)
    out = out.dropna(subset=["date"])
    out = out[out["appliance_name"].ne("") & out["appliance_name"].ne("nan")]
    identity_dropped = before_drop - len(out)

    # Duplicate protection
    before_dup = len(out)
    out = out.drop_duplicates(subset=["date", "appliance_id"], keep="last")
    duplicates = before_dup - len(out)

    flags = pd.Series(False, index=out.index)
    invalid_hours_found = 0

    for col in ["operating_hours", "standby_hours"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
        invalid = out[col].notna() & ((out[col] < 0) | (out[col] > 24))
        invalid_hours_found += int(invalid.sum())
        out.loc[invalid, col] = np.nan

    if "rated_power_w" in out:
        out.loc[out["rated_power_w"].notna() & (out["rated_power_w"] <= 0), "rated_power_w"] = np.nan
    if "standby_power_w" in out:
        out.loc[out["standby_power_w"].notna() & (out["standby_power_w"] < 0), "standby_power_w"] = np.nan
    if "units" in out:
        out.loc[out["units"].notna() & (out["units"] <= 0), "units"] = np.nan

    missing_mask = out[["operating_hours", "standby_hours", "rated_power_w", "standby_power_w", "units"]].isna()
    flags = missing_mask.any(axis=1)

    # Appliance-level median imputation, falling back to the global median.
    for col in ["operating_hours", "standby_hours", "rated_power_w", "standby_power_w", "units"]:
        if out[col].notna().any():
            appliance_medians = out.groupby("appliance_id")[col].transform("median")
            out[col] = out[col].fillna(appliance_medians)
            out[col] = out[col].fillna(out[col].median())

    out["units"] = out["units"].round().clip(lower=1).astype(int)
    out["operating_hours"] = out["operating_hours"].clip(lower=0, upper=24).round(3)
    out["standby_hours"] = out["standby_hours"].clip(lower=0, upper=24).round(3)
    out["rated_power_w"] = out["rated_power_w"].clip(lower=0).round(2)
    out["standby_power_w"] = out["standby_power_w"].clip(lower=0).round(2)

    out = add_energy_columns(out)
    out["operating_kwh"] = out["operating_kwh"].round(4)
    out["standby_kwh"] = out["standby_kwh"].round(4)
    out["total_kwh"] = out["total_kwh"].round(4)

    out["day_of_week"] = out["date"].dt.day_name()
    out["is_weekend"] = out["date"].dt.day_of_week >= 5
    start = out["date"].min()
    out["week_number"] = ((out["date"] - start).dt.days // 7 + 1).astype(int)

    flagged = flags.fillna(False).astype(bool)
    if flagged.any():
        label = "corrected_or_imputed" if invalid_hours_found > 0 else "imputed_missing_value"
        out.loc[flagged, "quality_flag"] = label
        out.loc[flagged, "data_source"] = "Estimated"
    else:
        out.loc[out["quality_flag"].eq("validated"), "quality_flag"] = "validated"

    out = out.sort_values(["date", "appliance_id"]).reset_index(drop=True)

    quality_report: dict[str, Any] = {
        "rows_in": int(rows_in),
        "rows_out": int(len(out)),
        "identity_rows_dropped": int(identity_dropped),
        "duplicates_removed": int(duplicates),
        "invalid_hours_corrected": int(invalid_hours_found),
        "missing_values_imputed": int(flagged.sum()),
        "estimated_records": int((out["data_source"] == "Estimated").sum()),
        "simulated_records": int((out["data_source"] == "Simulated").sum()),
        "observed_records": int((out["data_source"] == "Observed").sum()),
        "days": int(out["date"].nunique()),
        "appliances": int(out["appliance_id"].nunique()),
        "date_start": out["date"].min().strftime("%Y-%m-%d") if len(out) else "",
        "date_end": out["date"].max().strftime("%Y-%m-%d") if len(out) else "",
        "total_kwh": round(float(out["total_kwh"].sum()), 3),
        "operating_kwh": round(float(out["operating_kwh"].sum()), 3),
        "standby_kwh": round(float(out["standby_kwh"].sum()), 3),
        "missing_value_count": int(flags.sum()),
    }
    return out, quality_report


# ---------------------------------------------------------------------------
# Aggregations
# ---------------------------------------------------------------------------
def daily_summary(clean_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate records to one row per calendar day."""
    grouped = (
        clean_df.groupby("date", as_index=False)
        .agg(
            operating_kwh=("operating_kwh", "sum"),
            standby_kwh=("standby_kwh", "sum"),
            total_kwh=("total_kwh", "sum"),
            records=("appliance_id", "nunique"),
        )
        .sort_values("date")
        .reset_index(drop=True)
    )
    grouped["day_of_week"] = grouped["date"].dt.day_name()
    grouped["is_weekend"] = grouped["date"].dt.day_of_week >= 5
    start = grouped["date"].min()
    grouped["week_number"] = ((grouped["date"] - start).dt.days // 7 + 1).astype(int)
    grouped["operating_kwh"] = grouped["operating_kwh"].round(3)
    grouped["standby_kwh"] = grouped["standby_kwh"].round(3)
    grouped["total_kwh"] = grouped["total_kwh"].round(3)
    return grouped


def weekly_summary(daily_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate daily totals into study weeks."""
    rows = []
    for week, frame in daily_df.groupby("week_number", sort=True):
        rows.append(
            {
                "week_number": int(week),
                "start_date": frame["date"].min(),
                "end_date": frame["date"].max(),
                "days": int(len(frame)),
                "total_kwh": round(float(frame["total_kwh"].sum()), 3),
                "avg_daily_kwh": round(float(frame["total_kwh"].mean()), 3),
                "operating_kwh": round(float(frame["operating_kwh"].sum()), 3),
                "standby_kwh": round(float(frame["standby_kwh"].sum()), 3),
                "peak_day_kwh": round(float(frame["total_kwh"].max()), 3),
            }
        )
    return pd.DataFrame(rows)


def appliance_summary(clean_df: pd.DataFrame, db: pd.DataFrame | None = None) -> pd.DataFrame:
    """Appliance-wise consumption summary for the observation window."""
    grouped = (
        clean_df.groupby(["appliance_id", "appliance_name"], as_index=False)
        .agg(
            operating_kwh=("operating_kwh", "sum"),
            standby_kwh=("standby_kwh", "sum"),
            total_kwh=("total_kwh", "sum"),
            avg_operating_hours=("operating_hours", "mean"),
            avg_standby_hours=("standby_hours", "mean"),
            rated_power_w=("rated_power_w", "max"),
            standby_power_w=("standby_power_w", "max"),
            units=("units", "max"),
            records=("date", "nunique"),
        )
    )
    grouped["daily_avg_kwh"] = grouped["total_kwh"] / grouped["records"].clip(lower=1)
    grouped["projected_monthly_kwh"] = grouped["daily_avg_kwh"] * config.PROJECTION_DAYS
    total = grouped["total_kwh"].sum()
    grouped["share_pct"] = np.where(total > 0, grouped["total_kwh"] / total * 100, 0.0)
    grouped["standby_share_pct"] = np.where(
        grouped["total_kwh"] > 0,
        grouped["standby_kwh"] / grouped["total_kwh"] * 100,
        0.0,
    )
    if db is not None and not db.empty:
        lookup = db.set_index("appliance_id")
        grouped["category"] = grouped["appliance_id"].map(lookup["category"]).fillna("Other")
    else:
        grouped["category"] = "Other"
    numeric_cols = [
        "operating_kwh", "standby_kwh", "total_kwh", "avg_operating_hours",
        "avg_standby_hours", "daily_avg_kwh", "projected_monthly_kwh",
        "share_pct", "standby_share_pct",
    ]
    grouped[numeric_cols] = grouped[numeric_cols].round(3)
    return grouped.sort_values("total_kwh", ascending=False).reset_index(drop=True)


def peak_consumption_day(daily_df: pd.DataFrame) -> pd.Series | None:
    """Return the row for the highest-consumption day."""
    if daily_df.empty:
        return None
    return daily_df.loc[daily_df["total_kwh"].idxmax()]


def lowest_consumption_day(daily_df: pd.DataFrame) -> pd.Series | None:
    """Return the row for the lowest-consumption day."""
    if daily_df.empty:
        return None
    return daily_df.loc[daily_df["total_kwh"].idxmin()]


def build_quality_table(clean_df: pd.DataFrame) -> pd.DataFrame:
    """Small table describing provenance of every record."""
    rows = []
    for source, frame in clean_df.groupby("data_source"):
        rows.append(
            {
                "data_source": source,
                "records": int(len(frame)),
                "days": int(frame["date"].nunique()),
                "appliances": int(frame["appliance_id"].nunique()),
                "energy_kwh": round(float(frame["total_kwh"].sum()), 3),
            }
        )
    return pd.DataFrame(rows).sort_values("data_source").reset_index(drop=True)


# ---------------------------------------------------------------------------
# Appliance database and scenario editing
# ---------------------------------------------------------------------------
def prepare_appliance_database(db: pd.DataFrame, projection_days: int = config.PROJECTION_DAYS) -> pd.DataFrame:
    """Normalise an appliance database and add design-day energy columns."""
    out = db.copy()
    for col in ["rated_power_w", "standby_power_w", "units", "avg_daily_hours", "avg_standby_hours"]:
        out[col] = pd.to_numeric(out[col], errors="coerce").fillna(0.0)
    out["units"] = out["units"].round().clip(lower=1).astype(int)
    out["rated_power_w"] = out["rated_power_w"].clip(lower=0)
    out["standby_power_w"] = out["standby_power_w"].clip(lower=0)
    out["avg_daily_hours"] = out["avg_daily_hours"].clip(lower=0, upper=24)
    out["avg_standby_hours"] = out["avg_standby_hours"].clip(lower=0, upper=24)
    out["design_operating_kwh"] = (
        out["rated_power_w"] * out["units"] * out["avg_daily_hours"] / 1000
    ).round(4)
    out["design_standby_kwh"] = (
        out["standby_power_w"] * out["units"] * out["avg_standby_hours"] / 1000
    ).round(4)
    out["design_daily_kwh"] = (out["design_operating_kwh"] + out["design_standby_kwh"]).round(4)
    out["design_monthly_kwh"] = (out["design_daily_kwh"] * projection_days).round(3)
    return out


def apply_appliance_scenario(
    clean_df: pd.DataFrame,
    baseline_db: pd.DataFrame,
    scenario_db: pd.DataFrame,
) -> pd.DataFrame:
    """Propagate appliance parameter edits to every daily record.

    Operating and standby hours are scaled in proportion to the change in the
    design average, then energy is recomputed from the fundamental formula. This
    keeps the historical shape (weekday/weekend variation) while reflecting the
    edited appliance assumptions.
    """
    base = baseline_db.set_index("appliance_id")
    new = scenario_db.set_index("appliance_id")
    out = clean_df.copy()

    for appliance_id in out["appliance_id"].unique():
        if appliance_id not in base.index or appliance_id not in new.index:
            continue
        b = base.loc[appliance_id]
        n = new.loc[appliance_id]
        mask = out["appliance_id"] == appliance_id

        base_op = float(b["rated_power_w"]) * float(b["units"]) * float(b["avg_daily_hours"])
        new_op = float(n["rated_power_w"]) * float(n["units"]) * float(n["avg_daily_hours"])
        op_factor = new_op / base_op if base_op > 0 else 0.0
        base_sb = float(b["standby_power_w"]) * float(b["units"]) * float(b["avg_standby_hours"])
        new_sb = float(n["standby_power_w"]) * float(n["units"]) * float(n["avg_standby_hours"])
        sb_factor = new_sb / base_sb if base_sb > 0 else 0.0

        out.loc[mask, "operating_hours"] = (
            out.loc[mask, "operating_hours"] * op_factor
        ).clip(lower=0, upper=24)
        out.loc[mask, "standby_hours"] = (
            out.loc[mask, "standby_hours"] * sb_factor
        ).clip(lower=0, upper=24)
        out.loc[mask, "rated_power_w"] = float(n["rated_power_w"])
        out.loc[mask, "standby_power_w"] = float(n["standby_power_w"])
        out.loc[mask, "units"] = int(n["units"])
        out.loc[mask, "quality_flag"] = "scenario_adjusted"

    out = add_energy_columns(out)
    out["operating_kwh"] = out["operating_kwh"].round(4)
    out["standby_kwh"] = out["standby_kwh"].round(4)
    out["total_kwh"] = out["total_kwh"].round(4)
    return out


def database_diff(baseline_db: pd.DataFrame, scenario_db: pd.DataFrame) -> pd.DataFrame:
    """Return appliances whose editable parameters have changed."""
    cols = ["appliance_id", "appliance_name", "rated_power_w", "standby_power_w", "units",
            "avg_daily_hours", "avg_standby_hours"]
    base = baseline_db[cols].set_index("appliance_id")
    new = scenario_db[cols].set_index("appliance_id")
    common = base.index.intersection(new.index)
    diff_rows = []
    for appliance_id in common:
        if not base.loc[appliance_id].equals(new.loc[appliance_id]):
            diff_rows.append(
                {
                    "appliance_id": appliance_id,
                    "appliance_name": new.loc[appliance_id, "appliance_name"],
                    "parameter": "edited",
                    "baseline": ", ".join(str(base.loc[appliance_id, c]) for c in cols[2:]),
                    "scenario": ", ".join(str(new.loc[appliance_id, c]) for c in cols[2:]),
                }
            )
    return pd.DataFrame(diff_rows)
