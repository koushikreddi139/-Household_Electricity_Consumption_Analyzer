"""
Unit and integration tests for the core calculation and analytics modules.

Run from the project root:
    python -m unittest discover -s tests -v
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import config  # noqa: E402
from src.cost_analysis import cost_summary, energy_cost, savings_value  # noqa: E402
from src.data_processing import (  # noqa: E402
    appliance_summary,
    apply_appliance_scenario,
    clean_energy_data,
    daily_summary,
    load_energy_csv,
    prepare_appliance_database,
    validate_schema,
    weekly_summary,
)
from src.energy_calculator import (  # noqa: E402
    add_energy_columns,
    energy_kwh,
    monthly_projection,
    standby_energy_kwh,
    total_energy_kwh,
)
from src.prediction import PredictionError, fit_and_forecast  # noqa: E402
from src.recommendations import combined_savings, generate_recommendations  # noqa: E402
from src.sustainability import co2_kg, sustainability_summary  # noqa: E402


def sample_records() -> pd.DataFrame:
    """Small hand-checkable dataset with one missing and one invalid value."""
    rows = [
        # date, appliance, power, standby power, units, op hours, standby hours
        ("2026-01-01", "A1", "Fan", 100, 0, 1, 2.0, 0.0),
        ("2026-01-02", "A1", "Fan", 100, 0, 1, 4.0, 0.0),
        ("2026-01-03", "A1", "Fan", 100, 0, 1, 3.0, 0.0),
        ("2026-01-04", "A1", "Fan", 100, 0, 1, -1.0, 0.0),   # invalid negative
        ("2026-01-01", "A2", "TV", 100, 10, 1, 2.0, 2.0),
        ("2026-01-02", "A2", "TV", 100, 10, 1, np.nan, 22.0),  # missing
        ("2026-01-03", "A2", "TV", 100, 10, 1, 2.0, 22.0),
        ("2026-01-04", "A2", "TV", 100, 10, 1, 2.0, 22.0),
    ]
    return pd.DataFrame(
        rows,
        columns=[
            "date", "appliance_id", "appliance_name", "rated_power_w",
            "standby_power_w", "units", "operating_hours", "standby_hours",
        ],
    ).assign(data_source="Simulated")


class EnergyFormulaTests(unittest.TestCase):
    def test_operating_energy(self):
        self.assertAlmostEqual(energy_kwh(1000, 2, 1), 2.0)
        self.assertAlmostEqual(energy_kwh(75, 6.2, 2), 0.93)

    def test_standby_energy(self):
        self.assertAlmostEqual(standby_energy_kwh(5, 22, 1), 0.11)
        self.assertAlmostEqual(standby_energy_kwh(6, 18, 1), 0.108)

    def test_total_energy(self):
        self.assertAlmostEqual(total_energy_kwh(2000, 1.5, 5, 22, 1), 3.11)

    def test_invalid_inputs_rejected(self):
        with self.assertRaises(ValueError):
            energy_kwh(-10, 2)
        with self.assertRaises(ValueError):
            energy_kwh(100, 25)
        with self.assertRaises(ValueError):
            total_energy_kwh(100, 20, 5, 5)

    def test_projections(self):
        self.assertAlmostEqual(monthly_projection(10, 30), 300)
        self.assertAlmostEqual(sustainability_summary(
            pd.DataFrame({"total_kwh": [10.0] * 30}), 0.5, 10
        )["annual_kwh"], 3650, places=2)

    def test_add_energy_columns(self):
        df = pd.DataFrame(
            {"rated_power_w": [100], "standby_power_w": [5], "units": [2],
             "operating_hours": [4], "standby_hours": [20]}
        )
        out = add_energy_columns(df)
        self.assertAlmostEqual(out.loc[0, "operating_kwh"], 0.8)
        self.assertAlmostEqual(out.loc[0, "standby_kwh"], 0.2)
        self.assertAlmostEqual(out.loc[0, "total_kwh"], 1.0)


class CleaningTests(unittest.TestCase):
    def test_missing_and_invalid_values_are_imputed_and_flagged(self):
        clean, report = clean_energy_data(sample_records())
        self.assertEqual(len(clean), 8)
        self.assertEqual(report["missing_values_imputed"], 2)
        self.assertEqual(report["estimated_records"], 2)
        fan = clean[(clean["date"] == "2026-01-04") & (clean["appliance_id"] == "A1")].iloc[0]
        self.assertAlmostEqual(fan["operating_hours"], 3.0)  # median of 2, 3, 4
        self.assertEqual(fan["data_source"], "Estimated")
        tv = clean[(clean["date"] == "2026-01-02") & (clean["appliance_id"] == "A2")].iloc[0]
        self.assertAlmostEqual(tv["operating_hours"], 2.0)
        self.assertEqual(tv["data_source"], "Estimated")

    def test_energy_is_recomputed_from_formula(self):
        df = sample_records()
        df["operating_kwh"] = 999
        df["total_kwh"] = 999
        clean, _ = clean_energy_data(df)
        row = clean[(clean["date"] == "2026-01-01") & (clean["appliance_id"] == "A1")].iloc[0]
        self.assertAlmostEqual(row["total_kwh"], 0.2)

    def test_duplicates_removed(self):
        df = pd.concat([sample_records(), sample_records().iloc[[0]]], ignore_index=True)
        clean, report = clean_energy_data(df)
        self.assertEqual(report["duplicates_removed"], 1)
        self.assertEqual(len(clean), 8)

    def test_schema_validation(self):
        ok, errors, warnings = validate_schema(sample_records())
        self.assertTrue(ok, errors)
        broken = sample_records().drop(columns=["data_source"])
        ok, errors, _ = validate_schema(broken)
        self.assertFalse(ok)
        self.assertTrue(any("data_source" in e for e in errors))

    def test_blank_template_rejected_as_dataset(self):
        template = load_energy_csv(config.PRIMARY_TEMPLATE_PATH)
        ok, errors, _ = validate_schema(template)
        self.assertFalse(ok)
        self.assertTrue(any("operating-hour" in e for e in errors))


class DatasetIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw = load_energy_csv(config.RAW_DATA_PATH)
        cls.clean, cls.report = clean_energy_data(raw)
        cls.daily = daily_summary(cls.clean)
        cls.db = prepare_appliance_database(pd.read_csv(config.APPLIANCE_DB_PATH))

    def test_observation_window(self):
        self.assertEqual(self.report["days"], 21)
        self.assertEqual(self.report["appliances"], 13)
        self.assertEqual(len(self.clean), 273)
        self.assertEqual(self.report["date_start"], "2026-01-05")
        self.assertEqual(self.report["date_end"], "2026-01-25")

    def test_known_total_is_reproducible(self):
        self.assertAlmostEqual(float(self.clean["total_kwh"].sum()), 240.398, places=2)
        self.assertEqual(len(self.daily), 21)

    def test_provenance_is_preserved(self):
        sources = set(self.clean["data_source"].unique())
        self.assertTrue(sources.issubset({"Simulated", "Estimated", "Observed"}))
        self.assertEqual(int((self.clean["data_source"] == "Estimated").sum()), 5)
        self.assertFalse(
            ((self.clean["data_source"] == "Observed") & (self.clean["notes"].str.contains("Simulated"))).any()
        )

    def test_weekly_and_appliance_summaries(self):
        weekly = weekly_summary(self.daily)
        self.assertEqual(len(weekly), 3)
        self.assertAlmostEqual(weekly["total_kwh"].sum(), self.daily["total_kwh"].sum(), places=2)
        apps = appliance_summary(self.clean, self.db)
        self.assertEqual(len(apps), 13)
        self.assertAlmostEqual(apps["share_pct"].sum(), 100.0, places=1)

    def test_cost_and_emissions_consistency(self):
        stats = cost_summary(self.daily, 8.5)
        self.assertAlmostEqual(stats["monthly_kwh"], self.daily["total_kwh"].mean() * 30, places=2)
        self.assertAlmostEqual(stats["window_cost_inr"], self.daily["total_kwh"].sum() * 8.5, places=1)
        self.assertAlmostEqual(co2_kg(100, 0.71), 71.0, places=3)
        sustain = sustainability_summary(self.daily, 0.71, 8.5)
        self.assertAlmostEqual(sustain["annual_co2_kg"] / sustain["annual_kwh"], 0.71, places=3)

    def test_scenario_scaling(self):
        baseline = self.db.copy()
        scenario = baseline.copy()
        idx = scenario.index[scenario["appliance_id"] == "A11"][0]
        scenario.loc[idx, "avg_daily_hours"] = baseline.loc[idx, "avg_daily_hours"] / 2
        adjusted = apply_appliance_scenario(self.clean, baseline, scenario)
        base_energy = self.clean[self.clean["appliance_id"] == "A11"]["operating_kwh"].sum()
        new_energy = adjusted[adjusted["appliance_id"] == "A11"]["operating_kwh"].sum()
        self.assertAlmostEqual(new_energy / base_energy, 0.5, places=2)
        other_base = self.clean[self.clean["appliance_id"] == "A05"]["total_kwh"].sum()
        other_new = adjusted[adjusted["appliance_id"] == "A05"]["total_kwh"].sum()
        self.assertAlmostEqual(other_base, other_new, places=4)


class PredictionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        clean, _ = clean_energy_data(load_energy_csv(config.RAW_DATA_PATH))
        cls.daily = daily_summary(clean)

    def test_forecast_structure(self):
        result = fit_and_forecast(self.daily, horizon=30)
        self.assertEqual(len(result["forecast_frame"]), 30)
        self.assertEqual(result["train_size"], 14)
        self.assertEqual(result["test_size"], 7)
        self.assertTrue(all(result["forecast_frame"]["predicted_kwh"] >= 0))
        self.assertGreater(result["monthly_forecast_kwh"], 0)
        for key in ["mae", "rmse", "mape", "r2"]:
            self.assertIn(key, result["metrics"])

    def test_insufficient_data_raises(self):
        with self.assertRaises(PredictionError):
            fit_and_forecast(self.daily.head(8))


class RecommendationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        clean, _ = clean_energy_data(load_energy_csv(config.RAW_DATA_PATH))
        cls.clean = clean
        cls.daily = daily_summary(clean)
        cls.db = prepare_appliance_database(pd.read_csv(config.APPLIANCE_DB_PATH))
        cls.apps = appliance_summary(clean, cls.db)

    def test_recommendations_are_quantified(self):
        recs = generate_recommendations(self.apps, self.db, 8.5, 0.71)
        self.assertGreaterEqual(len(recs), 3)
        for rec in recs:
            self.assertGreater(rec["monthly_kwh"], 0)
            self.assertAlmostEqual(
                rec["monthly_inr"], rec["monthly_kwh"] * 8.5, delta=0.02
            )
            self.assertAlmostEqual(
                rec["monthly_co2_kg"], rec["monthly_kwh"] * 0.71, delta=0.02
            )

    def test_combined_savings(self):
        recs = generate_recommendations(self.apps, self.db, 8.5, 0.71)
        combo = combined_savings(recs, [r["id"] for r in recs], self.daily["total_kwh"].mean() * 30)
        self.assertGreater(combo["monthly_kwh"], 0)
        self.assertGreater(combo["annual_inr"], combo["monthly_inr"])
        self.assertLess(combo["monthly_kwh"], self.daily["total_kwh"].mean() * 30)

    def test_savings_value(self):
        result = savings_value(30, 8.5)
        self.assertAlmostEqual(result["monthly_inr"], 255.0)
        self.assertGreater(result["annual_inr"], result["monthly_inr"] * 12)


if __name__ == "__main__":
    unittest.main(verbosity=2)
