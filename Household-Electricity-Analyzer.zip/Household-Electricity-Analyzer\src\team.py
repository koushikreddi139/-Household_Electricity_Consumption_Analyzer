"""Team and submission metadata shared by the project generators."""

from __future__ import annotations

TEAM_NUMBER = "1"
TEAM_MEMBERS: tuple[tuple[str, str], ...] = (
    ("R Koushik", "RA2311003050036"),
    ("K Rakesh", "RA2311003050012"),
    ("M Pushkal", "RA2311003050013"),
    ("P Nitin", "RA2311003050064"),
)
GUIDE = "Asst. Prof. Logudurai"
PROGRAMME = "B.Tech Computer Science and Engineering"
DEPARTMENT = "Department of Computer Science and Engineering"
ACADEMIC_YEAR = "2025 - 26"
PROJECT_TITLE = "Household Electricity Consumption Analyzer"
PROJECT_SUBTITLE = "Appliance-level energy, cost, forecast and carbon analysis"
DATASET_NAME = "Project Dataset"


def member_label(name: str, roll: str, separator: str = " — ") -> str:
    """Return a single display line for one team member."""
    return f"{name}{separator}{roll}"
