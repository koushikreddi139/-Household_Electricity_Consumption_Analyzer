"""Generate docs/Problem_Statement.pdf and docs/Problem_Statement.md."""

from __future__ import annotations

import sys
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import (
    BaseDocTemplate, Frame, HRFlowable, KeepTogether, PageBreak, PageTemplate,
    Paragraph, Spacer, Table, TableStyle,
)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
DOCS = ROOT / "docs"
DOCS.mkdir(parents=True, exist_ok=True)

from src.team import GUIDE, TEAM_MEMBERS, TEAM_NUMBER

FONT_DIR = Path("C:/Windows/Fonts")
pdfmetrics.registerFont(TTFont("SegoeUI", str(FONT_DIR / "segoeui.ttf")))
pdfmetrics.registerFont(TTFont("SegoeUI-Bold", str(FONT_DIR / "segoeuib.ttf")))
pdfmetrics.registerFont(TTFont("SegoeUI-Italic", str(FONT_DIR / "segoeuii.ttf")))
pdfmetrics.registerFontFamily("SegoeUI", normal="SegoeUI", bold="SegoeUI-Bold",
                              italic="SegoeUI-Italic", boldItalic="SegoeUI-Bold")

DEEP = colors.HexColor("#0B3B36")
PRIMARY = colors.HexColor("#0F766E")
EMERALD = colors.HexColor("#10B981")
MINT = colors.HexColor("#6EE7B7")
LIGHT = colors.HexColor("#D1FAE5")
SAND = colors.HexColor("#F4F1E8")
INK = colors.HexColor("#0F172A")
MUTED = colors.HexColor("#64748B")
GRID = colors.HexColor("#E2E8F0")
SURFACE = colors.white
BG = colors.HexColor("#F5F8F6")
AMBER = colors.HexColor("#D97706")

body = ParagraphStyle("body", fontName="SegoeUI", fontSize=9.6, leading=14.0,
                      textColor=INK, alignment=TA_JUSTIFY, spaceAfter=5)
small = ParagraphStyle("small", parent=body, fontSize=8.4, leading=11.6, textColor=MUTED)
h1 = ParagraphStyle("h1", fontName="SegoeUI-Bold", fontSize=15, leading=18,
                    textColor=DEEP, spaceBefore=2, spaceAfter=2)
h2 = ParagraphStyle("h2", fontName="SegoeUI-Bold", fontSize=10.8, leading=13.5,
                    textColor=PRIMARY, spaceBefore=9, spaceAfter=3)
bullet = ParagraphStyle("bullet", parent=body, leftIndent=12, bulletIndent=1, spaceAfter=3.5)
callout_title = ParagraphStyle("ct", fontName="SegoeUI-Bold", fontSize=9.2, leading=12,
                               textColor=DEEP, spaceAfter=2)
team_label = ParagraphStyle("team_label", fontName="SegoeUI-Bold", fontSize=7.0, leading=9.2,
                            textColor=PRIMARY)
team_cell = ParagraphStyle("team_cell", fontName="SegoeUI", fontSize=8.2, leading=10.8,
                           textColor=INK)
team_guide = ParagraphStyle("team_guide", fontName="SegoeUI", fontSize=8.2, leading=10.6,
                            textColor=INK)


def P(text, style=body):
    return Paragraph(text, style)


def rule():
    return HRFlowable(width="100%", thickness=0.9, color=EMERALD, spaceBefore=1, spaceAfter=6)


def section(title):
    return [P(title, h1), rule()]


def box(title, text, fill=SAND, bar=AMBER):
    inner = Table([[
        [P(title, callout_title), P(text, ParagraphStyle("bt", parent=body, fontSize=8.9, leading=12.6))]
    ]], colWidths=[16.4 * cm])
    inner.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), fill),
        ("LINEBEFORE", (0, 0), (0, -1), 3, bar),
        ("BOX", (0, 0), (-1, -1), 0.4, GRID),
        ("LEFTPADDING", (0, 0), (-1, -1), 9),
        ("RIGHTPADDING", (0, 0), (-1, -1), 9),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    return inner


def draw_page(c, doc):
    W, H = A4
    c.saveState()
    c.setFillColor(DEEP)
    c.rect(0, H - 1.0 * cm, W, 1.0 * cm, stroke=0, fill=1)
    if doc.page > 1:
        c.setFont("SegoeUI", 7.4)
        c.setFillColor(MUTED)
        c.drawString(2.3 * cm, H - 1.7 * cm, "Problem Statement  ·  Household Electricity Consumption Analyzer  ·  Team No. 1")
        c.drawRightString(W - 2.3 * cm, 1.15 * cm, f"Page {doc.page}")
    c.restoreState()


story = []
story += section("Problem Statement")

team_rows = [
    [Paragraph(f"TEAM NO. {TEAM_NUMBER}", team_label), "", "", ""],
    [Paragraph(f"<b>{name}</b><br/><font size=7.4 color='#64748B'>{roll}</font>", team_cell)
     for name, roll in TEAM_MEMBERS],
    [Paragraph(f"<b>Under the Guidance of</b> &nbsp; {GUIDE}", team_guide), "", "", ""],
]
team_table = Table(team_rows, colWidths=[4.1 * cm] * 4)
team_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, -1), SURFACE),
    ("BOX", (0, 0), (-1, -1), 0.4, GRID),
    ("LINEBELOW", (0, 0), (-1, 0), 0.4, GRID),
    ("LINEABOVE", (0, 2), (-1, 2), 0.4, GRID),
    ("INNERGRID", (0, 1), (-1, 1), 0.3, GRID),
    ("SPAN", (0, 0), (-1, 0)),
    ("SPAN", (0, 2), (-1, 2)),
    ("LEFTPADDING", (0, 0), (-1, -1), 6),
    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ("TOPPADDING", (0, 0), (-1, -1), 3),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
]))
story.append(team_table)
story.append(Spacer(1, 6))

story.append(P(
    "<b>Project:</b> Household Electricity Consumption Analyzer<br/>"
    "<b>Programme:</b> B.Tech Computer Science and Engineering (Sustainable Energy Engineering)<br/>"
    "<b>Nature of work:</b> Software-only analysis, forecasting and reporting &mdash; no hardware or sensors",
    ParagraphStyle("meta", parent=body, fontSize=9.0, leading=13.5),
))
story.append(Spacer(1, 6))

story.append(P("1.  Context", h2))
story.append(P(
    "A household receives one consolidated electricity bill at the end of a billing cycle. The bill "
    "reports units consumed and the amount payable, but it does not reveal which appliance produced "
    "the consumption, when the energy was used, how much was drawn while equipment was idle, or what "
    "the environmental consequence was. This information gap is a barrier to energy efficiency: a "
    "household cannot manage what it cannot see."
))
story.append(P(
    "India's residential demand is growing, and space heating, water heating, refrigeration and "
    "cooling are major end uses. Efficiency programmes and star labels exist, but their benefit "
    "depends on how a particular household actually operates its appliances. A low-cost method is "
    "needed to convert a short period of manual observation into defensible estimates of energy, "
    "cost, demand and emissions."
))

story.append(P("2.  Problem definition", h2))
story.append(P(
    "The core problem is to design and build a transparent software workflow that accepts "
    "appliance-level operating-hour observations for a 21-day period and produces consistent "
    "estimates of electricity consumption, monthly cost, next-month demand, standby waste and "
    "CO<sub>2</sub>e emissions. The workflow must remain honest about data provenance: values that "
    "are provided, imputed or estimated must never be presented as physically measured."
))
for text in [
    "Manual meter reading is slow, error-prone and rarely stored in a structured, analysable form.",
    "A single monthly total cannot attribute consumption to appliances or identify standby waste.",
    "Without a documented assumption set, cost and carbon estimates are difficult to reproduce or audit.",
    "Short observation windows and imperfect records require explicit cleaning and provenance rules.",
    "Forecasts and savings claims are easily overstated when uncertainty and method are hidden.",
]:
    story.append(Paragraph(text, bullet, bulletText="•"))

story.append(P("3.  Proposed solution", h2))
story.append(P(
    "The project implements a Python and Streamlit application with six modules: Home, Consumption "
    "Analysis, Appliance Analysis, Prediction, Sustainability Insights and Data Management. A "
    "normalised CSV schema records appliance identity, rated and standby power, unit count, "
    "operating and standby hours, and a provenance label. A cleaning pipeline validates the schema, "
    "repairs out-of-range values, imputes missing values with appliance medians and marks every "
    "affected record as Estimated. Energy is recomputed from the fundamental relationship "
    "E = P × t / 1000, then aggregated daily, weekly and monthly."
))
story.append(P(
    "An editable tariff and grid emission factor convert energy into cost and CO<sub>2</sub>e. A "
    "Ridge regression with trend, weekend and weekly-cycle features produces a 30-day forecast, "
    "evaluated chronologically against a naive seven-day moving-average baseline. Six practical "
    "actions are quantified in kWh, rupees and kilograms of CO<sub>2</sub>e per month. A blank "
    "21-day observation template supports additional primary data collection, and the dashboard clearly "
    "separates provided, Estimated and Observed records."
))

story.append(Spacer(1, 3))
objectives = [
    "Define a clear, documented schema for 21 days of appliance-level observations.",
    "Implement a validation and cleaning pipeline that preserves data provenance.",
    "Compute energy, cost and emissions from transparent, editable assumptions.",
    "Analyse daily, weekly and appliance-level consumption patterns.",
    "Forecast the next 30 days and benchmark the model against a naive baseline.",
    "Quantify practical saving actions in energy, money and carbon terms.",
    "Deliver an interactive dashboard, reproducible figures, tests, a report and a presentation.",
]
objective_style = ParagraphStyle(
    "obj", parent=body, leftIndent=14, firstLineIndent=-14, spaceAfter=3.5)
story.append(KeepTogether([
    P("4.  Objectives", h2),
    Paragraph(f"<b>1.</b> {objectives[0]}", objective_style),
]))
for i, text in enumerate(objectives[1:], start=2):
    story.append(Paragraph(f"<b>{i}.</b> {text}", objective_style))

story.append(P("5.  Scope and boundaries", h2))
story.append(P(
    "<b>In scope:</b> a single household, 13 common appliances, a 21-day winter observation window, "
    "appliance-level energy and standby analysis, tariff and emission calculations, a regression "
    "forecast, quantified recommendations, an interactive dashboard, static charts, automated tests "
    "and academic documentation."
))
story.append(P(
    "<b>Out of scope:</b> hardware sensors, Arduino/ESP32 devices, smart meters, real-time data "
    "acquisition, weather modelling, time-of-use tariff optimisation, multi-household benchmarking, "
    "authentication and cloud deployment. The Project Dataset provides the working analysis for "
    "this submission."
))

story.append(P("6.  Data provenance and ethics", h2))
story.append(box(
    "Data provenance",
    "The 21-day Project Dataset supplied with this project is the dataset used throughout this "
    "analysis. Its measurement provenance is not independently verified here; results demonstrate "
    "that the software works end to end. A blank primary-observation template is included so that "
    "additional readings can be analysed without changing the analysis code.",
    fill=colors.HexColor("#FFF7ED"), bar=AMBER,
))
story.append(Spacer(1, 5))
story.append(P(
    "No personal data are collected. Tariffs and emission factors are illustrative and editable; no "
    "official utility tariff or verified grid factor is claimed. Savings are engineering estimates, "
    "not guaranteed outcomes.", small,
))

story.append(P("7.  Expected deliverables", h2))
deliverables = [
    ["Deliverable", "Purpose"],
    ["Working Streamlit dashboard", "Six-module interactive analysis with editable assumptions"],
    ["Project Dataset (21 days)", "Supplied appliance-level dataset used throughout the analysis"],
    ["Blank observation template", "Supports additional 21-day primary data collection"],
    ["Cleaning and analysis modules", "Validated, reusable and unit-tested calculation core"],
    ["Forecast and recommendations", "Transparent model with baseline and quantified actions"],
    ["Static figures and screenshots", "Report, presentation and archive evidence"],
    ["Project report (10 pages)", "Academic documentation of method, results and limitations"],
    ["Five-slide presentation", "Concise project defence and walkthrough"],
    ["Automated tests", "Regression protection for all core calculations"],
]
table = Table([[Paragraph(c, ParagraphStyle("th", fontName="SegoeUI-Bold", fontSize=8.2,
                                             textColor=colors.white)) if r == 0 else
                Paragraph(c, ParagraphStyle("td", fontName="SegoeUI", fontSize=8.2, leading=11.2,
                                             textColor=INK))
                for c in row] for r, row in enumerate(deliverables)],
              colWidths=[6.4 * cm, 10.0 * cm])
table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), DEEP),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [SURFACE, BG]),
    ("GRID", (0, 0), (-1, -1), 0.35, GRID),
    ("LEFTPADDING", (0, 0), (-1, -1), 5),
    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
    ("TOPPADDING", (0, 0), (-1, -1), 3.5),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
]))
story.append(table)

story.append(P("8.  Expected outcome", h2))
story.append(P(
    "A submission-ready, reproducible prototype that turns structured manual observations into a "
    "coherent efficiency assessment, with every assumption visible and every data source labelled. "
    "The project is successful if a reader can trace any headline number back to a formula, an input "
    "record and a stated assumption &mdash; and if the same software can accept real observations "
    "without modification.", small,
))

# ---------------------------------------------------------------------------
doc = BaseDocTemplate(
    str(DOCS / "Problem_Statement.pdf"), pagesize=A4,
    leftMargin=2.3 * cm, rightMargin=2.3 * cm, topMargin=2.1 * cm, bottomMargin=2.0 * cm,
    title="Problem Statement - Household Electricity Consumption Analyzer",
    author="Team No. 1 - R Koushik, K Rakesh, M Pushkal, P Nitin",
    subject="Problem statement and scope",
)
frame = Frame(2.3 * cm, 2.0 * cm, A4[0] - 4.6 * cm, A4[1] - 4.1 * cm, id="body")
doc.addPageTemplates([PageTemplate(id="body", frames=[frame], onPage=draw_page)])
doc.build(story)
print(f"Wrote {DOCS / 'Problem_Statement.pdf'}")
