"""
Core energy calculation functions.

All energy values are expressed in kilowatt-hours (kWh). The implementation
follows the formulae stated in the project brief:

    Operating energy (kWh) = rated power (W) x hours x units / 1000
    Standby energy (kWh)   = standby power (W) x standby hours x units / 1000
"""

from __future__ import annotations

import math
from typing import Iterable

import pandas as pd


def _require_non_negative(value: float, name: str) -> float:
    value = float(value)
    if math.isnan(value) or value < 0:
        raise ValueError(f"{name} must be a non-negative number (received {value!r}).")
    return value


def energy_kwh(rated_power_w: float, operating_hours: float, units: int = 1) -> float:
    """Operating energy consumption in kWh."""
    power = _require_non_negative(rated_power_w, "rated_power_w")
    hours = _require_non_negative(operating_hours, "operating_hours")
    count = _require_non_negative(units, "units")
    if hours > 24:
        raise ValueError("operating_hours cannot exceed 24 hours per day.")
    return power * hours * count / 1000.0


def standby_energy_kwh(standby_power_w: float, standby_hours: float, units: int = 1) -> float:
    """Standby energy consumption in kWh."""
    power = _require_non_negative(standby_power_w, "standby_power_w")
    hours = _require_non_negative(standby_hours, "standby_hours")
    count = _require_non_negative(units, "units")
    if hours > 24:
        raise ValueError("standby_hours cannot exceed 24 hours per day.")
    return power * hours * count / 1000.0


def total_energy_kwh(
    rated_power_w: float,
    operating_hours: float,
    standby_power_w: float = 0.0,
    standby_hours: float = 0.0,
    units: int = 1,
) -> float:
    """Total daily energy = operating energy + standby energy (kWh)."""
    if operating_hours + standby_hours > 24:
        # Different appliances can overlap conceptually, but for a single
        # appliance the two states cannot occupy more than a day.
        raise ValueError("operating_hours + standby_hours cannot exceed 24 hours.")
    return energy_kwh(rated_power_w, operating_hours, units) + standby_energy_kwh(
        standby_power_w, standby_hours, units
    )


def monthly_projection(daily_kwh: float, days: int = 30) -> float:
    """Project a daily average to a billing month."""
    if days <= 0:
        raise ValueError("days must be positive.")
    return _require_non_negative(daily_kwh, "daily_kwh") * days


def annual_projection(daily_kwh: float, days: int = 365) -> float:
    """Project a daily average to a year."""
    return monthly_projection(daily_kwh, days)


def energy_share(part_kwh: float, total_kwh: float) -> float:
    """Percentage share of a component in total energy (0 when total is zero)."""
    if total_kwh <= 0:
        return 0.0
    return 100.0 * part_kwh / total_kwh


def add_energy_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Recompute operating, standby and total kWh from appliance parameters."""
    out = df.copy()
    for col in ["rated_power_w", "standby_power_w", "units", "operating_hours", "standby_hours"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out["operating_kwh"] = (
        out["rated_power_w"] * out["operating_hours"] * out["units"] / 1000.0
    )
    out["standby_kwh"] = (
        out["standby_power_w"] * out["standby_hours"] * out["units"] / 1000.0
    )
    out["total_kwh"] = out["operating_kwh"] + out["standby_kwh"]
    return out


def aggregate_energy(series: Iterable[float]) -> float:
    """Convenience helper for summing an iterable of kWh values."""
    return float(sum(float(x) for x in series if pd.notna(x)))
