# Data directory

All CSV files are UTF-8, comma-separated and use a header row.

| File | Rows | Status | Purpose |
|---|---:|---|---|
| `project_dataset_raw.csv` | 273 | **Project Dataset** (5 rows become Estimated after cleaning) | Supplied appliance-level dataset: 13 appliances × 21 days |
| `project_dataset_cleaned.csv` | 273 | Project Dataset + Estimated | Output of the cleaning pipeline; used for analysis |
| `appliance_database.csv` | 13 | Design assumptions | Nameplate power, standby power, units, design hours |
| `primary_observation_template.csv` | 273 | **Observed** (blank) | Blank 21-day template for additional readings |

## Source labels

- **Project Dataset** — the 273 supplied appliance-day records used throughout the dashboard,
  report and presentation. The raw CSV retains the project schema labels for pipeline
  compatibility; the dashboard presents the supplied rows as the Project Dataset.
- **Estimated** — imputed, repaired or scenario-adjusted by the pipeline. Includes appliance-median
  imputation and the five anomalies in the supplied file.
- **Observed** — entered by a household from its own records. The blank template starts with this
  label but contains no hours until a user fills it in.

A repaired record can only ever become **Estimated**. The cleaning code never promotes a value to
**Observed**.

## Data-quality anomalies

The raw file contains five defects:

| Appliance | Date | Defect | Result |
|---|---|---|---|
| A05 Refrigerator | 2026-01-09 | missing operating hours | median imputed, Estimated |
| A04 Television | 2026-01-14 | missing operating hours | median imputed, Estimated |
| A01 Ceiling Fan | 2026-01-16 | negative operating hours (−0.5) | reset to missing, median imputed, Estimated |
| A11 Water heater | 2026-01-20 | missing operating hours | median imputed, Estimated |
| A12 Microwave | 2026-01-23 | operating hours > 24 (26.0) | reset to missing, median imputed, Estimated |

After cleaning: 268 Project Dataset records, 5 Estimated records, 0 Observed records.

## Appliance master data

`appliance_database.csv` is the single source of nameplate ratings, standby draw, unit counts and
design hours. The dashboard's **Appliance Analysis** page can adjust these values as a scenario;
the baseline file itself is not overwritten unless you export or edit it deliberately.

## Collecting additional observations

1. Copy `primary_observation_template.csv` to a working file (do not edit the original).
2. Keep one row per appliance per day for 21 consecutive days.
3. Enter `operating_hours` and `standby_hours`; use `notes` to record the method.
4. Set `data_source = Observed`.
5. Upload in the dashboard: **Data Management → Upload dataset**.
6. Review the quality table and provenance log before quoting results.

The validator requires the nine schema columns, parseable dates and at least one completed
operating-hour value. It warns when there are fewer than 21 distinct days or when the date sequence
has gaps.
